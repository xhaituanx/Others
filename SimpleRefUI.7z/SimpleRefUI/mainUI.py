import sys
from UI.UIMapping import UIExecute
from PyQt5 import QtWidgets

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    interface = UIExecute()
    interface.show()
    sys.exit(app.exec_())   #application's event loop


