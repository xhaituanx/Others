import os
import win32com.client as win32


class ExcelApp:
    def __init__(self):
        self.oldCalculation = None
        self.oldEnableEvents = None
        self.oldDisplayAlerts = None
        self.oldScreenUpdating = None
        
        self.excel_app = None
        try:
            self.excel_app = win32.gencache.EnsureDispatch("Excel.Application")
        except Exception as e:
            print("Cannot EnsureDispatch, trying Dispatch ...")
            try:
                self.excel_app = win32.Dispatch("Excel.Application")
            except Exception as e:
                print("Cannot Dispatch, exit Excel...")
                self.excel_app = None

    def ExcelAppQuit(self):
        if self.excel_app:
            self.excel_app.Quit()
            self.excel_app = None

    # def SetDefaultSheetNum(self, numSheets):
    #     self.excel_app.SheetsInNewWorkbook = numSheets

    def changeNewSetting(self):
        self.oldScreenUpdating = self.excel_app.ScreenUpdating
        self.oldDisplayAlerts = self.excel_app.DisplayAlerts
        self.oldEnableEvents = self.excel_app.EnableEvents
        self.oldCalculation = self.excel_app.Calculation
        self.excel_app.ScreenUpdating = False
        self.excel_app.DisplayAlerts = False
        self.excel_app.EnableEvents = False
        # self.excel_app.Calculation = xlCalculationManual


    def changeToOldSetting(self):
        self.excel_app.ScreenUpdating = self.oldScreenUpdating
        self.excel_app.DisplayAlerts = self.oldDisplayAlerts
        self.excel_app.EnableEvents = self.oldEnableEvents
        self.excel_app.Calculation = self.oldCalculation


    def Open_Workbook(self, filename):
        # filename = PureWindowsPath(filename)
        # print('Open Workbook {} {}'.format(filename, type(filename)))
        if os.path.isfile(filename):
            try:
                # Fixed issue cannot write more than 256 column for *.xls default saved format
                excel_workbook = self.excel_app.Workbooks.Open(filename)
                # self.excel_app.Visible = False
            except:
                print("Cannot open file {}".format(filename))
                return None

            return excel_workbook
        else:
            print("Cannot open filename {}".format(filename))
            return None


    def Open_Sheet(self, w_book, sh_name):
        try:
            new_ws = w_book.Worksheets(sh_name)
        except Exception as e:
            print("Cannot open sheetname {}".format(sh_name))
            new_ws = None
        return new_ws

