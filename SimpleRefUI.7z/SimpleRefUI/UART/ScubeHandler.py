from UART.UARTController import UARTController
from UART import UARTConfig
from UART.UARTUtil import XORChecksum
from UART.ScubeConfig import *

# sentPackage = None

def ScubePreparePack(cluster='', buffData=[], isReadFcn=1):
    scubeLength = SCUBE_BASE_LENGTH
    scubeLength += len(buffData)
    scubeBufferPrepare = [0]*scubeLength

    scubeBufferPrepare[0] = SCUBE_STX
    scubeBufferPrepare[1] = SCUBE_PRFID
    scubeBufferPrepare[2] = SCUBE_VER
    scubeBufferPrepare[3] = scubeLength - 4  # calculate LEN
    scubeBufferPrepare[9] = 0x01  # FrameID

    clID = ClusterDict.get(cluster, None)
    if clID:
        scubeBufferPrepare[10] = clID[0]
        scubeBufferPrepare[11] = clID[1]
    else:
        print('Unknown cluster:', cluster)
        return

    # Command byte. Read:0x02, Write:0x04
    if isReadFcn == 1:
        scubeBufferPrepare[12] = 0x02
    else:
        scubeBufferPrepare[12] = 0x04

    scubeBufferPrepare[13] = len(buffData)  # attribute length

    # merge data
    for i in range(0, len(buffData)):
        scubeBufferPrepare[14+i] = buffData[i]

    scubeBufferPrepare[scubeLength - 2] = XORChecksum(bytearray(scubeBufferPrepare))
    scubeBufferPrepare[scubeLength - 1] = SCUBE_ETX

    return scubeBufferPrepare



def Normal_Scube_Pack(clusterName, attID, isReadFcn=1, value=0):
    bufferPrepare = list()
    bufferPrepare.append(attID)
    if isReadFcn == 1:  # Read package preparation
        bufferPrepare.append(0x00)
    else:   # Write pakage preparation
        bufferPrepare.append(0x01)
        bufferPrepare.append(int(value))

    return ScubePreparePack(clusterName, bufferPrepare, isReadFcn)

#########################SCUBE block function##########################################
def Scube_FDoorStatus(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)

def Scube_RDoorStatus(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)

def RDoorLamp(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


# this function read current RNotch + 40(Freezer RR7000), or write Count - 40 to current Notch
def RRoomSettingNotch(clusterName, attID, isReadFcn=1, Count=0):
    Count += 40     #compensate for calculation of REF SW
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)

# this function return minimum RNotch of current model + 40(Freezer RR7000)
def RRoomMinNotch(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


# this function return maximum RNotch of current model + 40(Freezer RR7000)
def RRoomMaxNotch(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def RRoomTemp(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


# this function read current FNotch + 40(Freezer RR7000), or write Count - 40 to current Notch
def FRoomSettingNotch(clusterName, attID, isReadFcn=1, Count=0):
    Count += 40  # compensate for calculation of REF SW
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


# this function return minimum FNotch of current model + 40(Freezer RR7000)
def FRoomMinNotch(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


# this function return maximum FNotch of current model + 40(Freezer RR7000)
def FRoomMaxNotch(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def CVRoomSettingTemp(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


# this function make the package to read or write power freezer status
# default value is 240(0xF0: off)
def powerFreezSetting(clusterName, attID, isReadFcn=1, Count=240):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


# this function make the package to read or write power refrige status
# default value is 240(0xF0: off)
def powerRefrigeSetting(clusterName, attID, isReadFcn=1, Count=240):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def tempUnit(clusterName, attID, isReadFcn=1, Count=0):
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def vacationFuntion(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def sabbathFuntion(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def WaterFilter(clusterName, attID, isReadFcn=1, Count=10):  # default value is 10(0xAA is reset filter, 10 to make sure not send 0xAA as default)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def DoorAlarmKey(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def DemoMode(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def Lock(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def IceOff(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    # write-only
    return Normal_Scube_Pack(clusterName, attID, 0, Count)


def selfCheckFunction(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def DeoFilter(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def iceMakingStatus(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def IDSupport(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def KeySupport(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def IceName(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def RefAbnormalStatus(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def FreAbnormalStatus(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def CVAbnormalStatus(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def RefrigeratorError(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)

def DoorOpenStatus(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def FreezerConvertStatus(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def PanelCommError(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def CVName(clusterName, attID, isReadFcn=1, Count=0):
    # read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


#######################################################################################

#########################SCUBE block Network###########################################
def JoinNetwork(clusterName, attID, isReadFcn=1, Count=0):  # default value is 0(0xEA: network_fail, 0xee: network_timeout, 0xEF: network_compleated)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def ConnectionStatus(clusterName, attID, isReadFcn=1, Count=10):  # default value is 10(0x4A: INTERNET_CONNECTED, 0x2A: AP_CONNECTED, 0x00: NO_NETWORK)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def WifiApStatus(clusterName, attID, isReadFcn=1,
        Count=10):  # default value is 10(0x22: CONFIRM_START, 0x2A: CONFIRM_COMPLETE, 0x40: CONNECT_SUCCESS, 0x50: CONNECT_FAIL)
    # Write pakage preparation
    return Normal_Scube_Pack(clusterName, attID, 0, Count)


def WifiFactoryRescueAttr(clusterName, attID, isReadFcn=1, Count=10):  # default value is 10(0x10: WIFI_INIT_SUCCESS_VALUE)
    # Write pakage preparation
    return Normal_Scube_Pack(clusterName, attID, 0, Count)


def APScanStatus(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240(0xF0: off)
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def MACAddress(clusterName, attID, isReadFcn=1, Count=''):
    bufferPrepare = list()
    bufferPrepare.append(attID)
    if isReadFcn == 1:  # Read package preparation
        bufferPrepare.append(0x00)
    else:   # Write package preparation
        bufferPrepare.append(0x06)
        addrLst = Count.split(' ')
        if len(addrLst) == 6:
            bufferPrepare.append(int(addrLst[0]))
            bufferPrepare.append(int(addrLst[1]))
            bufferPrepare.append(int(addrLst[2]))
            bufferPrepare.append(int(addrLst[3]))
            bufferPrepare.append(int(addrLst[4]))
            bufferPrepare.append(int(addrLst[5]))
        else:
            print('MAC address include 6 integers separated by whitespace')

    return ScubePreparePack(clusterName, bufferPrepare, isReadFcn)


def FirmwareVersion(clusterName, attID, isReadFcn=1, Count=''):
    bufferPrepare = list()
    bufferPrepare.append(attID)
    if isReadFcn == 1:  # Read package preparation
        bufferPrepare.append(0x00)
    else:   # Write package preparation
        bufferPrepare.append(0x04)
        firmwareLst = Count.split(' ')
        if len(firmwareLst) == 4:
            bufferPrepare.append(int(firmwareLst[0]))
            bufferPrepare.append(int(firmwareLst[1]))
            bufferPrepare.append(int(firmwareLst[2]))
            bufferPrepare.append(int(firmwareLst[3]))
        else:
            print('Firmware Version include 4 integers separated by whitespace')

    return ScubePreparePack(clusterName, bufferPrepare, isReadFcn)


#######################################################################################

#########################SCUBE block Info##############################################
def ProductInfoDetection(clusterName, attID, isReadFcn=1, Count=240):
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def ManufactNameInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def ModelIDInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def DeviceTypeInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def SaleLocationInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def IDSetInfo(clusterName, attID, isReadFcn=1, Count=''):
    bufferPrepare = list()
    bufferPrepare.append(attID)
    if isReadFcn == 1:  # Read package preparation
        bufferPrepare.append(0x00)
    else:   # Write pcakage preparation
        bufferPrepare.append(0x02)
        IDLst = Count.split(' ')
        if len(IDLst) == 2:
            bufferPrepare.append(int(IDLst[0]))
            bufferPrepare.append(int(IDLst[1]))
        else:
            print('SET ID include 2 integers separated by whitespace')

    return ScubePreparePack(clusterName, bufferPrepare, isReadFcn)


def SetAsciiInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def OTNVerInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def ModelClassificationInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def SerialNumInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def MNIDInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def SetupIDInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def SSIDTypeInfo(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


#######################################################################################

#########################SCUBE block DRLC##############################################
def DRLCLevel(clusterName, attID, isReadFcn=1, Count=5):  # default value is 5:not supported
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def DRLCOverride(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240:Disable
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def DelayDefrost(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240:Disable
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def DRLCRealSaving(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)


def DRLCStartTime(clusterName, attID, isReadFcn=1, Count=''):
    bufferPrepare = list()
    bufferPrepare.append(attID)
    if isReadFcn == 1:  # Read package preparation
        bufferPrepare.append(0x00)
    else:   # Write package preparation
        bufferPrepare.append(0x04)
        strtTimeLst = Count.split(' ')
        if len(strtTimeLst) == 4:
            bufferPrepare.append(int(strtTimeLst[0]))
            bufferPrepare.append(int(strtTimeLst[1]))
            bufferPrepare.append(int(strtTimeLst[2]))
            bufferPrepare.append(int(strtTimeLst[3]))
        else:
            print('DRLC start time include 4 integers separated by whitespace')

    return ScubePreparePack(clusterName, bufferPrepare, 0)


def DRLCDuration(clusterName, attID, isReadFcn=1, Count=0):
    bufferPrepare = list()
    bufferPrepare.append(attID)
    if isReadFcn == 1:  # Read package preparation
        bufferPrepare.append(0x00)
    else:   # Write package preparation
        bufferPrepare.append(0x02)
        durationLst = Count.split(' ')
        if len(durationLst) == 2:
            bufferPrepare.append(int(durationLst[0]))
            bufferPrepare.append(int(durationLst[1]))
        else:
            print('DRLC Duration include 2 integers separated by whitespace')

    return ScubePreparePack(clusterName, bufferPrepare, 0)

#######################################################################################

#########################SCUBE block PowerConsumption##################################
def ZigbeeCommonEnable(clusterName, attID, isReadFcn=1, Count=240):  # default value is 240:Disable
    return Normal_Scube_Pack(clusterName, attID, isReadFcn, Count)


def PowerConsumption(clusterName, attID, isReadFcn=1, Count=0):
    # Read-only
    return Normal_Scube_Pack(clusterName, attID, 1, Count)

#######################################################################################

#########################SCUBE block FactoryMode#######################################

#######################################################################################

# Update final package for sending
# def SCUBESendService(cluster='', buffData=[], isReadFcn=1):
#     global sentPackage
#
#     scubeLength = SCUBE_BASE_LENGTH
#     scubeLength += len(buffData)
#     scubeBufferPrepare = [0]*scubeLength
#
#     scubeBufferPrepare[0] = SCUBE_STX
#     scubeBufferPrepare[1] = SCUBE_PRFID
#     scubeBufferPrepare[2] = SCUBE_VER
#     scubeBufferPrepare[3] = scubeLength - 4  # calculate LEN
#     scubeBufferPrepare[9] = 0x01  # FrameID
#
#     clID = ClusterDict.get(cluster, None)
#     if clID:
#         scubeBufferPrepare[10] = clID[0]
#         scubeBufferPrepare[11] = clID[1]
#     else:
#         print('Unknown cluster:', cluster)
#         return
#
#     # Command byte. Read:0x02, Write:0x04
#     if isReadFcn == 1:
#         scubeBufferPrepare[12] = 0x02
#     else:
#         scubeBufferPrepare[12] = 0x04
#
#     scubeBufferPrepare[13] = len(buffData)  # attribute length
#
#     # merge data
#     for i in range(0, len(buffData)):
#         scubeBufferPrepare[14+i] = buffData[i]
#
#     scubeBufferPrepare[scubeLength - 2] = XORChecksum(bytearray(scubeBufferPrepare))
#     scubeBufferPrepare[scubeLength - 1] = SCUBE_ETX
#
#     # update sent package for displaying
#     sentPackage = scubeBufferPrepare[:]
#
#     count = UARTController().WriteCompPort(bytearray(scubeBufferPrepare))  # Send entry command)
#     if count == 0:
#         print('Cannot write data', scubeBufferPrepare)


if __name__ == '__main__':
    comport = UARTController()
    ret = comport.OpenComPort(UARTConfig.COM_PORT, UARTConfig.BAUD_RATE)
    if ret:
        while (True):
            scubeLength = SCUBE_BASE_LENGTH  # reset length of package base before calculation
            isReadFcn = int(input("Read(1) or Write(0): "))
            # RDoorStatus(56)
            # FDoorStatus(12)
            # RDoorLamp()
            # FRoomSettingNotch(60)
            # RRoomSettingNotch()
            # tempUnit()
            # vacationFuntion()
            # selfCheckFunction()
            # iceMakingStatus()
            # CVRoomSettingTemp()
            # powerFreezSetting()
            # powerRefrigeSetting()
            # RRoomMinNotch()
            # RRoomMaxNotch()
            # FRoomMaxNotch()
            FRoomMinNotch()
            # SCUBESendService()
