from UART.PCBConfig import *

def PreparePack(typePack) -> list:
    arr = [0]*31
    arr[0] = TEST_START1
    if typePack == TEST_START2_A5:
        arr[1] = TEST_START2_A5
    elif typePack == TEST_START2_A6:
        arr[1] = TEST_START2_A6
    elif typePack == TEST_START2_A7:
        arr[1] = TEST_START2_A7
    else:
        print('Unknown type {}'.format(typePack))

    arr[27] = 0xF0
    arr[28] = 0x01
    return arr

def PCBFDoorStatus(isWrite = 0,OpenClose = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x14
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x0B
        if OpenClose == 0:
            pass
        else:
            arr[3] = 0x01
            arr[4] = 0x01

    return arr

def PCBRDoorStatus(isWrite = 0,OpenClose = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x14
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x0B
        if OpenClose == 0:
            pass
        else:
            arr[5] = 0x01
            arr[6] = 0x01
    return arr

def PCBFRoomTemp(isWrite = 0, Count = 0, issensor10bit = 1):
    sensor10bit = int(issensor10bit)
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x11
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x01
        if sensor10bit == 1:
            arr[3] = int(Count / 4)
            arr[4] = int(Count % 4) + 8
        else:
            arr[3] = Count
            arr[4] = 0x08
    return arr

def PCBFDefTemp(isWrite = 0, Count = 0, issensor10bit = 1):
    sensor10bit = int(issensor10bit)
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x11
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x01
        if sensor10bit == 1:
            arr[7] = int(Count / 4)
            arr[8] = int(Count % 4) + 8
        else:
            arr[7] = Count
            arr[8] = 0x08
    return arr

def PCBRRoomTemp(isWrite = 0, Count = 0, issensor10bit = 1):
    sensor10bit = int(issensor10bit)
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x11
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x01
        if sensor10bit == 1:
            arr[5] = int(Count / 4)
            arr[6] = int(Count % 4) + 8
        else:
            arr[5] = Count
            arr[6] = 0x08
    return arr

def PCBRDefTemp(isWrite = 0, Count = 0, issensor10bit = 1):
    sensor10bit = int(issensor10bit)
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x11
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x01
        if sensor10bit == 1:
            arr[9] = int(Count / 4)
            arr[10] = int(Count % 4) + 8
        else:
            arr[9] = Count
            arr[10] = 0x08
    return arr

def PCBExtTemp(isWrite = 0, Count = 0, issensor10bit = 1):
    sensor10bit = int(issensor10bit)
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x11
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x01
        if sensor10bit == 1:
            arr[11] = int(Count / 4)
            arr[12] = int(Count % 4) + 8
        else:
            arr[11] = Count
            arr[12] = 0x08
    return arr

def PCBHumidity(isWrite = 0, Count = 0, issensor10bit = 1):
    sensor10bit = int(issensor10bit)
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x11
    else:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x01
        if sensor10bit == 1:
            arr[25] = int(Count / 4)
            arr[26] = int(Count % 4) + 8
        else:
            arr[25] = Count
            arr[26] = 0x08
    return arr
  
def PCBExtMode(isWrite = 0, val = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x61
        return arr
    else:
        return 0

def PCBFanStatusRead(isWrite = 0, val = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A6)
        arr[2] = 0x02
        return arr
    else:
        return 0

def PCBFDefHeaterStatus(isWrite = 0, OnOff = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A6)
        arr[2] = 0x02
    else:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x10
        if OnOff == 0:
            pass
        else:
            arr[3] = 0x01
    return arr

def PCBRDefHeaterStatus(isWrite = 0, OnOff = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A6)
        arr[2] = 0x02
    else:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x10
        if OnOff == 0:
            pass
        else:
            arr[3] = 0x02
    return arr

def PCBEnterTestMode():
    arr = PreparePack(TEST_START2_A5)
    arr[2] = 0xFF
    arr[3] = 0xFF
    return arr

def PCBExitTestMode(isResetMicom = 0):
    arr = PreparePack(TEST_START2_A5)
    arr[2] = 0xFE
    if isResetMicom == 0:
        arr[3] = 0x01
    return arr

def PCBE2PDiodeOpRead():
    arr = PreparePack(TEST_START2_A5)
    arr[2] = 0x34
    arr[3] = 0x74
    arr[5] = 0x76  
    arr[7] = 0x78
    return arr

def PCBE2PDiodeOpWrite(diode):
    arr = PreparePack(TEST_START2_A5)
    arr[2] = 0x51
    arr[3] = diode + 1
    return arr

def PCBWriteEEPROM(addr = 0, val = 0):
    arr = PreparePack(TEST_START2_A5)
    arr[2] = 0x33
    arr[3] = addr
    arr[4] = val
    return arr

def PCBReadEEPROM(addr = 0):
    arr = PreparePack(TEST_START2_A5)
    arr[2] = 0x34
    arr[3] = addr
    return arr

def PCBSelfCheck(isWrite = 0, val = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x44
        return arr
    else:
        return 0

def PCBIceStatus(isWrite = 0, OnOff = 0):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x08
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        if OnOff == 0:
            arr[4] = 0x02
        else:
            arr[4] = 0x01
    return arr

def PCBEnergySaveStatus(isWrite = 0, OnOff = 0):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x08
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        if OnOff == 0:
            arr[5] = 0x02
        else:
            arr[5] = 0x01
    return arr

def PCBDemoModeStatus(isWrite = 0, OnOff = 0):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x08
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        if OnOff == 0:
            arr[10] = 0x02
        else:
            arr[10] = 0x01
    return arr

def PCBVacationStatus(isWrite = 0, OnOff = 0):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x08
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        if OnOff == 0:
            arr[11] = 0x02
        else:
            arr[11] = 0x01
    return arr

def PCBDoorAlarmStatus(isWrite = 0, OnOff = 0):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x08
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        if OnOff == 0:
            arr[13] = 0x02
        else:
            arr[13] = 0x01
    return arr

def PCBLockStatus(isWrite = 0, OnOff = 0):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x08
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        if OnOff == 0:
            arr[14] = 0x02
        else:
            arr[14] = 0x01
    return arr

def PCBFastMode(isWrite = 0, OnOff = 0):
    if isWrite == 1:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x09
        if OnOff == 0:
            pass
        else:
            arr[3] = 0x01
        return arr
    else:
        return 0

def PCBCompRPMRead(isWrite = 0, val = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A6)
        arr[2] = 0x12
        return arr
    else:
        return 0
 
def PCBOptionRead():
    arr = PreparePack(TEST_START2_A6)
    arr[2] = 0x06
    return arr
 
def PCBForceRunWrite(OnOff = 0):
    arr = PreparePack(TEST_START2_A6)
    arr[2] = 0x01
    if OnOff == 0:
        pass
    else:
        arr[3] = 0x01
    return arr

def PCBForceDefWrite(OnOff = 0):
    arr = PreparePack(TEST_START2_A6)
    arr[2] = 0x01
    if OnOff == 0:
        pass
    else:
        arr[3] = 0xF1
    return arr

def PCBOptionWrite(arr, option = 0, value = 0):
    # arr = PreparePack(TEST_START2_A6)
    arr[2] = 0x05
    if option % 2 == 0:
        arr[int(option / 2) + 3] &= 0xf0
        arr[int(option / 2) + 3] |= int(value) & 0x0F
    else:
        arr[int(option / 2) + 3] &= 0x0f
        arr[int(option / 2) + 3] |= int(value) << 4 & 0xF0
    arr[27] = 0xF0
    arr[28] = 0x01
    arr[MAX_LENGTH_PCBTEXT - 2] = 0x00
    return arr

def PCBOptionInit():
    arr = PreparePack(TEST_START2_A6)
    arr[2] = 0x05
    return arr

def PCBRNotchSetting(isWrite = 0, notch = 0, typeSetting = 1):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x04
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        arr[4] = typeSetting
        arr[5] = notch
    return arr

def PCBFNotchSetting(isWrite = 0, notch = 0, typeSetting = 1):
    arr = PreparePack(TEST_START2_A7)
    arr[2] = 0x03
    if isWrite == 0:
        arr[3] = 0x11
    else:
        arr[3] = 0x88
        arr[4] = typeSetting
        if typeSetting == 0:
            if notch < -2:
                arr[5] = 256 + notch
            elif notch < 0:
                arr[5] = 0xFF
            else:
                arr[5] = notch + 1
        elif typeSetting == 1:
            arr[5] = 256 + notch
    return arr

def PCBFDoorLamp(isWrite = 0, OnOff = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A6)
        arr[2] = 0x02
    else:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x13
        arr[5] = OnOff << 3
    return arr

def PCBRDoorLamp(isWrite = 0, OnOff = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A6)
        arr[2] = 0x02
    else:
        arr = PreparePack(TEST_START2_A5)
        arr[2] = 0x13
        arr[5] = OnOff << 2
    return arr

def PCBFanRPMRead(isWrite = 0, val = 0):
    if isWrite == 0:
        arr = PreparePack(TEST_START2_A7)
        arr[2] = 0x0D
        return arr
    else:
        return 0
