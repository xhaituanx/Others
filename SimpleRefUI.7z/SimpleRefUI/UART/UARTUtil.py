# from Common.DataConfig import *
# from robot.api import logger
# from Common.FunName import *

def XORChecksum(bArrData: list):
    # print("in checksum {}".format(bArrData))
    chSum = 0
    for i in range(0, len(bArrData)):
        chSum ^= bArrData[i]
        # chSum ^= ord(el)
    return chSum

