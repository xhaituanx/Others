import serial
#from robot.api import logger
import time
from UART import UARTConfig
from UART.PCBConfig import *
# from Common.FunName import *

from UART.UARTUtil import XORChecksum
from UART.ScubeConfig import *

class UARTController:
    __instance = None

    @staticmethod
    def get_instance():
        """ Static access method. """
        #logger.console("UARTController: get_instance {}".format(UARTController.__instance))
        if not UARTController.__instance:
            UARTController()
        return UARTController.__instance

    # def __new__(cls, *args, **kwargs):
    #     if not UARTController.__instance:
    #         UARTController.__instance = object.__new__(cls)
    #     return UARTController.__instance

    def __init__(self):
        if UARTController.__instance:
            pass
            # logger.console("UARTController: instance is exist {}".format(UARTController.__instance))
        else:
            self._ser_stt = None
            UARTController.__instance = self
            # logger.console("UARTController: create new instance ")
            # logger.console("UARTController: create new instance {}".format(UARTController.__instance))


    # wait until existing data in serial buffer
    # check first and second byte
    # def ReadData(self):
    #     if UARTController.__instance._ser_stt.inWaiting():
    #         tmpbyte = UARTController.__instance._ser_stt.read(2)
    #         if TEST_START1 == tmpbyte[0] and any([
    #                                                     TEST_START2_A5 == tmpbyte[1],
    #                                                     TEST_START2_A6 == tmpbyte[1],
    #                                                     TEST_START2_A7 == tmpbyte[1]
    #                                                 ]):
    #                 time.sleep(UARTConfig.DELAY_INTR_REV_FULL_DATA)
    #                 strOut = tmpbyte + UARTController.__instance._ser_stt.read(MAX_LENGTH_PCBTEXT - 2)
    #                 return strOut                    # UARTController.__instance._ser_stt.reset_input_buffer()
    #
    #         elif SCUBE_STX == tmpbyte[0] and SCUBE_PRFID == tmpbyte[1]:
    #             verlen = UARTController.__instance._ser_stt.read(2)
    #             time.sleep(UARTConfig.DELAY_INTR_REV_FULL_DATA)
    #             strOut = tmpbyte + verlen + UARTController.__instance._ser_stt.read(verlen[1])
    #             return strOut
    #         else:
    #             print("fault ",tmpbyte[0],tmpbyte[1])
    #             return ''
    #     else:
    #         return ''
    def ReadData(self):
        if UARTController.__instance._ser_stt.inWaiting():
            tmpbyte = UARTController.__instance._ser_stt.read(1)
            # print(" data", hex(tmpbyte[0]))
            if TEST_START1 == tmpbyte[0] or tmpbyte[0] == SCUBE_STX:
                if TEST_START1 == tmpbyte[0]:
                    time.sleep(UARTConfig.DELAY_INTR_REV_FULL_DATA)
                    strOut = tmpbyte + UARTController.__instance._ser_stt.read(MAX_LENGTH_PCBTEXT - 1)
                    return strOut                    # UARTController.__instance._ser_stt.reset_input_buffer()
                elif tmpbyte[0] == SCUBE_STX:
                    verlen = UARTController.__instance._ser_stt.read(3)
                    time.sleep(UARTConfig.DELAY_INTR_REV_FULL_DATA)
                    strOut = tmpbyte + verlen + UARTController.__instance._ser_stt.read(verlen[2])
                    return strOut
            else:
                # print("fault data",hex(tmpbyte[0]))
                return ''
        else:
            return ''


    def OpenComPort(self, portx=UARTConfig.COM_PORT, bps=UARTConfig.BAUD_RATE, testuart=False, tmout=0.5):
        # logger.console("{} Try to open com {} with type {}".format(fun_name(), portx, type(portx)))
        ret = False
        try:
            UARTController.__instance._ser_stt = serial.Serial(port=portx, baudrate=bps, timeout=tmout)

            if UARTController.__instance._ser_stt.isOpen():
                UARTController.__instance._ser_stt.flushInput()
                # threading.Thread(target=UARTController.__instance.ReadData).start()
                print("Open Com port successful with {}".format(UARTController.__instance._ser_stt))
                ret = True
        except Exception as e:
            self.ui.openComPort.setChecked(0)
            pass
            # if not testuart:
            #     raise AssertionError("{}: Cannot open Com port {0} with error {1}".format(fun_name(), portx, e))

        return ret

    # close the serial port
    def ColseCompPort(self):

        if UARTController.__instance._ser_stt is not None:
            print("Close Com port {}".format(UARTController.__instance._ser_stt))
            UARTController.__instance._ser_stt.close()
            UARTController.__instance._ser_stt = None

    # send data to PBA and return number of byte sending
    def WriteCompPort(self, text: bytearray) -> int:
        result = 0
        if UARTController.__instance._ser_stt is not None:
            result = UARTController.__instance._ser_stt.write(text)  # write data
            print('\r\nWriteCompPort: {}'.format(text.hex()))
            # logger.info("\r\n{}: {}".format(fun_name(), text.hex()), also_console=True)
        return result

    # return internal buffer data with timeout 500ms (waiting for get data from PBA)
    def ReadCompPort(self, timout=0.5) -> bytes:
        pass
        # start = time.time()
        # while True:
        #     if len(UARTController.__instance.strOut) != 0 or timout == 0:
        #         str = UARTController.__instance.strOut
        #         UARTController.__instance.strOut = ""  # clear the current reading
        #         if len(str):
        #             logger.info("{}: {}".format(fun_name(), str.hex()), also_console=True)
        #         return str
        #
        #     if ((time.time() - start) >= timout):  # Check in 500ms
        #         raise AssertionError("{}: Receive time out".format(fun_name()))


    # clear Serial in/out buffer
    def ClearAllDataInBuffer(self):
        if UARTController.__instance._ser_stt is not None:
            UARTController.__instance._ser_stt.reset_input_buffer()
            UARTController.__instance._ser_stt.reset_output_buffer()


if __name__ == '__main__':
    # ex1
    bufferSend = bytearray(31)  # create 31 bytes
    bufferSend[0] = TEST_START1
    bufferSend[1] = TEST_START2_A6
    bufferSend[2] = 0x06
    bufferSend[29] = XORChecksum(bufferSend)
    # ex2
    bufferSend2 = bytearray(16)
    bufferSend2[0] = 0xD0
    bufferSend2[1] = 0xC0
    bufferSend2[2] = 0x04
    bufferSend2[3] = 0x0C
    bufferSend2[9] = 0x07
    bufferSend2[10] = 0xFC
    bufferSend2[11] = 0x01
    bufferSend2[14] = 0xE2
    bufferSend2[15] = 0xE0
    # ex3
    buff = "5AA6050000000000000000000000000000000000000000000000000000F900"

    comport = UARTController()

    ret = comport.OpenComPort(UARTConfig.COM_PORT, UARTConfig.BAUD_RATE)
    if ret:  # determine if the serial port is successfully opened.
        count = comport.WriteCompPort(bufferSend)  # Send entry command
        strOut = comport.ReadCompPort()

        count = comport.WriteCompPort(bytearray.fromhex(buff))  # Send entry command
        strOut = comport.ReadCompPort()

        count = comport.WriteCompPort(bufferSend2)  # Send entry command
        strOut = comport.ReadCompPort()

