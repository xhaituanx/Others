from UART.ScubeHandler import *
from UART.PCBHandler import *
from Protocol.Parser.OutBug.A5_Struct.A5_Common import *
from Protocol.Parser.OutBug.A6_Struct.A6_Common import *
from Protocol.Parser.OutBug.A7_Struct.A7_Common import *

# {Attr Name, Attr ID, Handler}
ScubeFuncDict = {
    'F_Door_Status': (0x87, Scube_FDoorStatus),
    'R_Door_Status': (0x47, Scube_RDoorStatus),
    'R_Door_Lamp': (0x11, RDoorLamp),
    'R_Room_Setting_Notch': (0x5A, RRoomSettingNotch),
    'R_Room_Min_Notch': (0x5B, RRoomMinNotch),
    'R_Room_Max_Notch': (0x5C, RRoomMaxNotch),
    'F_Room_Setting_Notch': (0x9A, FRoomSettingNotch),
    'F_Room_Min_Notch': (0x9B, FRoomMinNotch),
    'F_Room_Max_Notch': (0x9C, FRoomMaxNotch),
    'CV_Room_Setting_Temp': (0x7A, CVRoomSettingTemp),
    'Power_Freeze_Setting': (0x8C, powerFreezSetting),
    'Power_Fridge_Setting': (0x4C, powerRefrigeSetting),
    'Temp_Unit': (0x2A, tempUnit),
    'Vacation_Funtion': (0x5F, vacationFuntion),
    'Sabbath_Funtion': (0x18, sabbathFuntion),
    'Self_Check_Function': (0xA0, selfCheckFunction),
    'Ice_Making_Status': (0xC6, iceMakingStatus),
    'ID_Support': (0x0E, IDSupport),
    'Key_Support': (0x0A, KeySupport),
    'Ice_Name': (0xC2, IceName),
    'Ref_Abnormal_Status': (0x5E, RefAbnormalStatus),
    'Fre_Abnormal_Status': (0x9E, FreAbnormalStatus),
    'CV_Abnormal_Status': (0x7E, CVAbnormalStatus),
    'Refrigerator_Error': (0xA0, RefrigeratorError),
    'Door_Open_Status': (0x67, DoorOpenStatus),
    'Freeze_Convert_Status': (0x9F, FreezerConvertStatus),
    'Panel_Comm_Error': (0xAE, PanelCommError),
    'CV_Name': (0x7B, CVName),
    'Water_Filter': (0xA2, WaterFilter),
    'Deo_Filter': (0xA3, DeoFilter),
    'Door_Alarm_Key': (0x48, DoorAlarmKey),
    'Demo_Mode': (0xA8, DemoMode),
    'Lock': (0xA6, Lock),
    'Ice_Off': (0xC3, IceOff),
    'R_Room_Temp': (0x5D, RRoomTemp)
}

ScubeNetworkDict = {
    'JOIN_NETWORK': (0x97, JoinNetwork),
    'CONNECTION_STATUS': (0x89, ConnectionStatus),
    'AP_SCAN_STATUS': (0x88, APScanStatus),
    'MAC_ADRESS': (0x82, MACAddress),
    'FIRMWARE_VERSION': (0x33, FirmwareVersion),
    'WIFI_AP_STATUS': (0xA1, WifiApStatus),
    'WIFI_FACTORY_RESCUE_ATTR': (0xFD, WifiFactoryRescueAttr)
}

ScubeInfoDict = {
    'Product Info': (0x21, ProductInfoDetection),
    'Manufact Name': (0x22, ManufactNameInfo),
    'Model ID': (0x23, ModelIDInfo),
    'Device Type': (0x24, DeviceTypeInfo),
    'Sale Location': (0x25, SaleLocationInfo),
    'ID Set': (0x26, IDSetInfo),
    'Set ASCII': (0x27, SetAsciiInfo),
    'OTN Ver': (0x33, OTNVerInfo),
    'Model Class': (0x40, ModelClassificationInfo),
    'Serial Num': (0x94, SerialNumInfo),
    'MNID': (0xE1, MNIDInfo),
    'Setup ID': (0xE2, SetupIDInfo),
    'SSID Type': (0xE5, SSIDTypeInfo)
}


ScubeDRLCDict = {
    'DRLC Level': (0x14, DRLCLevel),
    'DRLC Override': (0x15, DRLCOverride),
    'Delay Defrost': (0x16, DelayDefrost),
    'DRLC RealSaving': (0x20, DRLCRealSaving),
    'DRLC StartTime': (0x12, DRLCStartTime),
    'DRLC Duration': (0x13, DRLCDuration)
}

ScubePowerDict = {
    'Zibgee Common': (0x01, ZigbeeCommonEnable),
    'Power Consumption': (0x13, PowerConsumption)
}


PCBFncDict = {
    STR_F_DOOR_STATUS: PCBFDoorStatus,
    STR_R_DOOR_STATUS: PCBRDoorStatus,
    STR_F_DOOR_LAMP: PCBFDoorLamp,
    STR_R_DOOR_LAMP: PCBRDoorLamp,
    STR_F_ROOM_TEMP: PCBFRoomTemp,
    STR_F_DEF_TEMP: PCBFDefTemp,
    STR_R_ROOM_TEMP: PCBRRoomTemp,
    STR_R_DEF_TEMP: PCBRDefTemp,
    STR_AIR_TEMP: PCBExtTemp,
    STR_HUMIDITY_STATUS: PCBHumidity,
    STR_AIR_MODE: PCBExtMode,
    STR_F_FAN_STATUS: PCBFanStatusRead,
    STR_R_FAN_STATUS: PCBFanStatusRead,
    STR_C_FAN_STATUS: PCBFanStatusRead,
    STR_F_DEF_HEATER: PCBFDefHeaterStatus,
    STR_R_DEF_HEATER: PCBRDefHeaterStatus,
    STR_SELF_CHECK: PCBSelfCheck,
    STR_R_NOTCH_SETTING: PCBRNotchSetting,
    STR_F_NOTCH_SETTING: PCBFNotchSetting,
    STR_VACATION_FUNC: PCBVacationStatus,
    STR_DOOR_ALARM: PCBDoorAlarmStatus,
    STR_DEMO_MODE: PCBDemoModeStatus,
    STR_LOCK_MODE: PCBLockStatus,
    STR_ICE_MODE: PCBIceStatus,
    STR_COMP_RPM: PCBCompRPMRead,
    STR_F_FAN_RPM: PCBFanRPMRead,
    STR_FAST_MODE: PCBFastMode
}

OpItempDict = {
    'F Room Temp Shift': 0,
    'R Room Temp Shift': 1,
    'Ice Maker Water Amount': 2,
    'Ice Maker Water Time': 3,
    'Ice Maker Eject Time': 4,
    'F Room Hysteresis': 5,
    'F Room Notch Cold Gap': 6,
    'F Room Notch Warm Gap': 7,
    'R Room Notch Cold Gap': 8,
    'R Room Notch Warm Gap': 9,
    'R Room Hysteresis': 10,
    'Open Air Temp Shift': 11,
    'Iso Case 3 Defrost Time': 12,
    'R Defrost Come Back Temp': 13,
    'F Defrost Come Back Temp': 14,
    'R Room Comp Off Cycle': 15,
    'Display Option': 16,
    'Defrost After Service': 17,
    'Check Fan Restriction': 18,
    'Dispenser Heater': 19,
    'C Room Temp Shift': 20,
    'C Room Hysteresis': 21,
    'Idle Time': 22,
    'Control Bldc Fan High Low': 23,
    'Deodorizer Fan': 24,
    'C Room Thaw TempShift': 25,
    'R Initial Off': 26,
    'Comp RPM': 27,
    'F Fan Force': 28,
    'R Fan Force': 29,
    'C Fan Force': 30,
    'Internal Humidity': 31,
    'Door Open Fan': 32,
    'Shut Off Valve': 33,
    # 'Reserved': 34,
    # 'Reserved': 35,
    # 'Reserved': 36,
    'Inv Comp RPM Up': 37,
    'CV Room Temp Shift': 38
}


