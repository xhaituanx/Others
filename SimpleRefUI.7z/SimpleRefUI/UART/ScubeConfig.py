# Scube
SCUBE_STX = 0xD0
SCUBE_PRFID = 0xC0
SCUBE_VER = 0x04
SCUBE_ETX = 0xE0
SCUBE_BASE_LENGTH = 16


CL_FUNCTION = 'Function'
CL_INFO = 'Info'
CL_NETWORK = 'Network'
CL_DRLC = 'DRLC'
CL_TIME = 'Time'
CL_POWER = 'PowerConsumption'
CL_FACTORY = 'FactoryMode'

# {Cluster name, cluster ID}
ClusterDict = {
    CL_FUNCTION: (0xFE, 0x02),
    CL_INFO: (0xFC, 0x01),
    CL_NETWORK: (0xFC, 0x94),
    CL_DRLC: (0xFD, 0x01),
    CL_TIME: (0xFD, 0x03),
    CL_POWER: (0xFD, 0x12),
    CL_FACTORY: (0xFC, 0x9F)
}
