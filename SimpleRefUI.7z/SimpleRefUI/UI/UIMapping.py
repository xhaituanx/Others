from UI.RefSimpleUI import *
from UART.UARTController import UARTController
from UART import PCBHandler
from PyQt5 import QtWidgets, QtCore, QtGui
from UART.Handler import ScubeFuncDict, ScubeNetworkDict, PCBFncDict, OpItempDict, EEPAdrrDict, ScubeInfoDict, ScubeDRLCDict, ScubePowerDict
from UART.UARTUtil import *
import serial, serial.tools.list_ports
from PyQt5.QtCore import QObject, QThread, pyqtSignal, pyqtSlot
from UART.ScubeConfig import *
from UART.PCBConfig import *
from PyQt5.QtWidgets import QFileDialog
from ExcelHandle.ExcelFile import ExcelApp
from ExcelHandle.ExcelConfig import *

from time import sleep
from threading import Thread
import sys, os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'Protocol'))
# from Protocol.Parser.ParseData import Wifi_Package, Outbug_Package, Print_Data
from contextlib import redirect_stdout
import io


class Worker(QObject):
    finished = pyqtSignal()
    intReady = pyqtSignal(bytes)

    @pyqtSlot()
    def __init__(self, serial):
        super(Worker, self).__init__()
        self.working = True
        self.ser = serial

    def work(self):
        while self.working:
            line = self.ser.ReadData()
            if len(line) > 0:
                self.data = line
                print('ReadCompPort:', line.hex())
                self.intReady.emit(line)
        self.finished.emit()


class Worker2(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(int)

    @pyqtSlot()
    def __init__(self):
        super(Worker2, self).__init__()
        self.working = True

    def run(self):
        while True:
#            print(1)
            self.progress.emit(1)
            sleep(1)


class UIExecute(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.isDataSend = False     # Use to know first pack received after sending
        self.strCmd = ''    # Use for highlighting msg return

        #Load status
        self.stComp = 0
        self.stFan = 0
        self.stDefrostHeater = 0


    # Comp Port ===============================================================
        self.thread = None
        self.worker = None
        self.listport = []
        self.listBaudrate = []
        self.Add_Baudrate()
        self.Add_Com_Port()
        self.ui.refreshComPort.clicked.connect(self.Refresh_Com_Port)
        self.comport = UARTController()

        # open/close com port
        self.ui.openComPort.clicked[bool].connect(self.connectHandler)
        self.isPortOpen = False

        # additional UI features ==============================================
        self.ui.icon2 = QtGui.QIcon()
        self.ui.icon2.addPixmap(QtGui.QPixmap(":/Images/icon/disconnected_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.ui.icon1 = QtGui.QIcon()
        self.ui.icon1.addPixmap(QtGui.QPixmap(":/Images/icon/connected_icon.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.ui.iconOFF = QtGui.QIcon()
        self.ui.iconOFF.addPixmap(QtGui.QPixmap(":/Images/icon/gray_circle.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.ui.iconON = QtGui.QIcon()
        self.ui.iconON.addPixmap(QtGui.QPixmap(":/Images/icon/green_circle.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)


#        self.ui.actualACKData.setEnabled(False)


        #Button connect:
        self.ui.BtForceDefrost.clicked[bool].connect(self.ForceDef)
        self.ui.BtForceRun.clicked[bool].connect(self.ForceRun)
        self.ui.BtNormalMode.clicked[bool].connect(self.NormalMode)
        self.ui.BtNormalMode_2.clicked[bool].connect(self.status_update)

        #Make a background thread for automatically updating the REF load status:
        # self.daemon = Thread(target=self.status_update, args=(3,), daemon=True, name='status')
        # self.daemon.start()
        self.thread2 = QThread()
        self.worker2 = Worker2()
        self.worker2.moveToThread(self.thread2)
        self.thread2.started.connect(self.worker2.run)
        self.worker2.progress.connect(self.status_update)
        # self.worker2.finished.connect(self.thread2.quit)
        # self.worker2.finished.connect(self.worker2.deleteLater)
        # self.thread2.finished.connect(self.thread2.deleteLater)
        #self.worker2.progress.connect(self.reportProgress)
        self.thread2.start()

    def status_update(self):
        if self.ui.StCompEdit.text() == '1':
            self.ui.StComp.setIcon(self.ui.iconON)
        else:
            self.ui.StComp.setIcon(self.ui.iconOFF)

        # Fan Status
        if self.ui.StFanEdit.text() == '1':
            self.ui.StFan.setIcon(self.ui.iconON)
        else:
            self.ui.StFan.setIcon(self.ui.iconOFF)

        # Fan Status
        if self.ui.StHeaterEdit.text() == '1':
            self.ui.StDefrostHeater.setIcon(self.ui.iconON)
        else:
            self.ui.StDefrostHeater.setIcon(self.ui.iconOFF)


    def start_loop(self):
        self.worker = Worker(self.comport)   # a new worker to perform those tasks
        self.thread = QThread()  # a new thread to run our background tasks in
        self.worker.moveToThread(self.thread)  # move the worker into the thread, do this first before connecting the signals

        self.thread.started.connect(self.worker.work)   # begin our worker object's loop when the thread starts running

        self.worker.intReady.connect(self.readFromPort)

        #self.ui.closeComPort.clicked.connect(self.closeComport)

        self.worker.finished.connect(self.loop_finished)       # do something in the gui when the worker loop ends
        self.worker.finished.connect(self.thread.quit)         # tell the thread it's time to stop running
        self.worker.finished.connect(self.worker.deleteLater)  # have worker mark itself for deletion
        self.thread.finished.connect(self.thread.deleteLater)  # have thread mark itself for deletion

        self.thread.start()

    def loop_finished(self):
        print('Loop Finished')

    ############################### Comp Port ##########################################
    def connectHandler(self, flag):
        if flag:
            self.openComport()
        else:
            self.closeComport()

    def openComport(self):
        for port in self.listport:
            if port.isChecked():
                Comport = port.text()

        for BDrate in self.listBaudrate:
            if BDrate.isChecked():
                baudrate = BDrate.text().split()[1]

        try:
            self.isPortOpen = self.comport.OpenComPort(Comport, baudrate)
            if self.isPortOpen:
                self.start_loop()

                self.ui.openComPort.setIcon(self.ui.icon1)
                self.displayLogMsg('Open {} successfully with baudrate {} \r\n'.format(Comport, baudrate))
                print(Comport, baudrate)
            else:
                self.displayLogMsg('Cannot Open {} with baudrate {}'.format(Comport, baudrate))
        except:
            self.displayLogMsg("Please select Comport and Baudrate !!")
            self.ui.openComPort.setChecked(0)

    def closeComport(self):
        try:
            self.worker.working = False
        except:
            pass

        if self.isPortOpen:
            self.comport.ColseCompPort()
            self.isPortOpen = False
            self.displayLogMsg("Close Com port successfully \r\n")
            # for display UI
            self.ui.openComPort.setIcon(self.ui.icon2)

    def readFromPort(self, text: bytes):
        receivePackage = text.hex()
        out = ''
        # separate each byte by insert ' '
        for index in range(0, len(receivePackage) // 2):
            out += receivePackage[index * 2] + receivePackage[index * 2 + 1] + ' '

        if self.isDataSend:
            self.isDataSend = False
            self.displayLogMsgandParse(out.upper(), self.isDataSend, self.strCmd)

        self.ui.actualACKData.setText(out.upper())
        self.ui.textBrowser_logDisplay.insertPlainText('PBA->PC: ' + out.upper() + '\r\n')
        self.ui.textBrowser_logDisplay.moveCursor(QtGui.QTextCursor.End)

    def Add_Com_Port(self):
        ##############Add Separator########################
        self.ui.menuSerial.addSeparator()
        ##############Add Com Port########################
        for port in serial.tools.list_ports.comports():
            self.Nport = QtWidgets.QAction(self)
            self.Nport.setCheckable(True)
            self.Nport.setObjectName(port.device)
            self.ui.menuSerial.insertAction(self.ui.menuSerial.menuAction(),self.Nport)
            self.Nport.setText(port.device)
            self.listport.append(self.Nport)
            ##############Set signal for Port########################
            self.Nport.triggered.connect(lambda signal,PortName=port.device:self.Comport_handle(PortName,signal))

    def Comport_handle(self,PortName,signal):
        for check in self.listport:
            if check.text() == PortName:
                if signal == False:
                    check.setChecked(True)
                    pass
                else:
                    handle = check
                    for new in self.listport:
                        new.setChecked(False)
                    handle.setChecked(True)
                    pass

    def Add_Baudrate(self):
        self.actionBaudrate_9600 = QtWidgets.QAction(self)
        self.actionBaudrate_9600.setCheckable(True)
        self.actionBaudrate_9600.setChecked(True)
        self.actionBaudrate_9600.setEnabled(True)
        self.actionBaudrate_9600.setObjectName("actionBaudrate_9600")

        self.actionBaudrate_115200 = QtWidgets.QAction(self)
        self.actionBaudrate_115200.setCheckable(True)
        self.actionBaudrate_115200.setObjectName("actionBaudrate_115200")

        self.actionBaudrate_9600.setText("Baudrate 9600")
        self.actionBaudrate_115200.setText("Baudrate 115200")

        self.ui.menuSerial.addAction(self.actionBaudrate_9600)
        self.ui.menuSerial.addAction(self.actionBaudrate_115200)

        ##############create list Baudrate##########################
        self.listBaudrate.append(self.actionBaudrate_9600)
        self.listBaudrate.append(self.actionBaudrate_115200)

        ##############Set signal for Baudrate########################
        for item in self.listBaudrate:
            item.triggered.connect(lambda signal,BaudrateName=item.text():self.Baudrate_Handle(BaudrateName,signal))


    def Baudrate_Handle(self,BaudrateName,signal):
        for check in self.listBaudrate:
            if check.text() == BaudrateName:
                if signal == False:
                    check.setChecked(True)
                    pass
                else:
                    handle = check
                    for new in self.listBaudrate:
                        new.setChecked(False)
                    handle.setChecked(True)
                    pass

    def Refresh_Com_Port(self):
        for port in self.listport:
            self.ui.menuSerial.removeAction(port)
        self.listport = []
        self.Add_Com_Port()


    # Display Log =====================================================
    def displayLogMsg(self, msg:str, color=QtCore.Qt.black):
        self.ui.textBrowser_parsePkg.moveCursor(QtGui.QTextCursor.End)
        self.ui.textBrowser_parsePkg.setTextColor(color)
        self.ui.textBrowser_parsePkg.insertPlainText(msg + '\r\n')
        self.ui.textBrowser_parsePkg.moveCursor(QtGui.QTextCursor.End)

    def displayPackage(self, buffData:list, direc):
        out = ''
        # separate each byte by insert ' '
        for index in range(0, len(buffData)):
            out += f'{buffData[index]:0>2x}' + ' '

        self.ui.testPackageData.setText(out.upper())
        self.displayLogMsgandParse(out.upper(), direc)


    def displayLogMsgandParse(self, msg:str, direc=True, chkStr=''):
        if direc:
            self.displayLogMsg('PC->PBA: ' + msg, QtGui.QColor(9, 229, 139))
        else:
            self.displayLogMsg('PBA->PC: ' + msg, QtCore.Qt.cyan)

        reval, remsg = self.Translate_Pack(msg, chkStr)
        if reval != '':
            self.displayLogMsg(chkStr + ' : ' + str(reval) + '\r\n', QtCore.Qt.yellow)
        else:
            self.displayLogMsg(remsg)


    def SendPackage(self, arr: list, strToCheckRet=''):
        count = self.comport.WriteCompPort(bytearray(arr))  # Send entry command
        if count == 0:
            self.displayLogMsg('Cannot write data {}'.format(arr))
        else:
            self.isDataSend = True
            self.strCmd = strToCheckRet
            self.displayPackage(arr, self.isDataSend)

    def NormalMode(self, OnOff):
        if self.isPortOpen:
            self.ui.StCompEdit.setText('0')
            self.ui.StFanEdit.setText('0')
            self.ui.StHeaterEdit.setText('0')
            #            if OnOff:
            arr = PCBHandler.PCBForceDefWrite(0)

            #            else:
            #                arr = PCBHandler.PCBForceDefWrite(0)
            arr[MAX_LENGTH_PCBTEXT - 2] = XORChecksum(arr)
            self.SendPackage(arr)

            arr = PCBHandler.PCBForceRunWrite(0)
            arr[MAX_LENGTH_PCBTEXT - 2] = XORChecksum(arr)
            self.SendPackage(arr)

        else:
            self.displayLogMsg("Please Open UART Port first !!")


    def ForceDef(self, OnOff):
        if self.isPortOpen:
#            if OnOff:
            arr = PCBHandler.PCBForceDefWrite(1)
            self.ui.StCompEdit.setText('0')
            self.ui.StFanEdit.setText('0')
            self.ui.StHeaterEdit.setText('1')
#            else:
#                arr = PCBHandler.PCBForceDefWrite(0)
            arr[MAX_LENGTH_PCBTEXT - 2] = XORChecksum(arr)
            self.SendPackage(arr)
        else:
            self.displayLogMsg("Please Open UART Port first !!")


    def ForceRun(self, OnOff):
        if self.isPortOpen:
            #if OnOff:
            arr = PCBHandler.PCBForceRunWrite(1)
            self.ui.StCompEdit.setText('1')
            self.ui.StFanEdit.setText('1')
            self.ui.StHeaterEdit.setText('0')
            #else:
            #    arr = PCBHandler.PCBForceRunWrite(0)
            arr[MAX_LENGTH_PCBTEXT - 2] = XORChecksum(arr)
            self.SendPackage(arr)
        else:
            self.displayLogMsg("Please Open UART Port first !!")


    ##################################### Parse Data ###########################################
    def Translate_Pack(self, raw_input:str, keyToHighLighted=''):
        data_des = {}
        reval = ''
        with io.StringIO() as buff:
            with redirect_stdout(buff):
                try:
                    barr = bytearray.fromhex(raw_input)
                    if not Wifi_Package(barr, data_des):
                        if not Outbug_Package(barr, data_des):
                            print('Invalid wireless package checksum')
                            print('Invalid outbug package checksum')

                    if len(data_des) > 0:
                        Print_Data(data_des)
                        for key, val in data_des.items():
                            if keyToHighLighted == key.strip():
                                reval = val
                                break
                except:
                    print('Warning ! Incorrect package type')

                return reval, buff.getvalue()

if __name__ == "__main__":
    pass