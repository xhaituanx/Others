# from cgitb import text
from Parser.ParseData import *
import sys
# import json
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from PyQt5 import QtGui, QtWidgets
from UI.Info import *
from contextlib import redirect_stdout
import io

prevInput = ''

class EventHandler:
    def __init__(self, mainWindow):
        self.mainWindow = mainWindow

    def showPkgDescription(self, output: str):
        # f_Out = open('out.txt','a+')
        # f_Out.seek(0)
        # self.mainWindow.textBrowser_pkgDescription.setText(f_Out.read())
        # f_Out.close()
        self.mainWindow.textBrowser_pkgDescription.setText(output)


    def updateSearchHistory(self, data):
        self.mainWindow.listWidget_searchHistory.insertItem(0, data)
        self.mainWindow.listWidget_searchHistory.setCurrentRow(0)
        self.mainWindow.listWidget_searchHistory.clearSelection()

    def chooseItemFromHistory(self):
        curRow = self.mainWindow.listWidget_searchHistory.currentRow()
        item = self.mainWindow.listWidget_searchHistory.item(curRow)

        self.mainWindow.lineEdit_searchPackage.setText(item.text())
        self.searchPkgSignal()

    def openFile(self):
        fileName = QFileDialog.getOpenFileName(None, "Open File", "")
        self.showPkgDescription(traslateLog(fileName[0]))


    def saveFile(self):
        fileName = QFileDialog.getSaveFileName(None, "Save File", "", '*.txt')

        if fileName[0]:
            with open(fileName[0], 'w', encoding='utf-8') as f:
                data = self.mainWindow.textBrowser_pkgDescription.toPlainText()
                try:
                    f.write(data)
                except Exception as e:
                    print('Save log file: ', e)
                msg = QMessageBox()
                msg.setWindowIcon(QtGui.QIcon('packageICON.png'))
                msg.setWindowTitle("Package Translate")
                msg.setText("File has been saved")
                msg.exec_()

    def appInfo(self):
        msg = QMessageBox()
        msg.setWindowIcon(QtGui.QIcon('Image/packageICON.png'))
        msg.setWindowTitle("Package Translate")
        msg.setText("Version: " + VERSION + "\nDate: " + TIME
                    + "\nOS: " + OS + "\nDesign: " + DESIGN + "\nContact: " + CONTACT)
        msg.exec_()        

    def searchPkgSignal(self):
        global prevInput
        self.mainWindow.listWidget_searchHistory.hide()

        input_var = self.mainWindow.lineEdit_searchPackage.text()
        input_var = input_var.replace('\n', '')
        input_var_temp = input_var.replace(' ', '')
        
        if (prevInput != input_var_temp) and (input_var_temp != ''):
            self.updateSearchHistory(input_var)
            self.showPkgDescription(Translate_Package(input_var))

        prevInput = input_var_temp

        # item = self.mainWindow.listWidget_searchHistory.item(1)
        # item.setText("OK OK")


def Translate_Package(raw_input:str):
    # #create file
    # f_Out = open('out.txt', 'w')
    # orig_stdout = sys.stdout
    # sys.stdout = f_Out

    if raw_input != '':
        data_des = {}
        with io.StringIO() as buff:
            with redirect_stdout(buff):
                try:
                    barr = bytearray.fromhex(raw_input)
                    if not Wifi_Package(barr, data_des):
                        if not Outbug_Package(barr, data_des):
                            print('Invalid wireless package checksum')
                            print('Invalid outbug package checksum')

                    if len(data_des) > 0:
                        Print_Data(data_des)
                except:
                    print('Warning ! Incorrect package type. Plz enter HEX package')

                return buff.getvalue()
    # sys.stdout = orig_stdout
    # f_Out.close()
    return ''


def traslateLog(fileName):
    # f_Out = open('out.txt', 'w')
    # orig_stdout = sys.stdout
    # sys.stdout = f_Out

    if fileName != '':
        with io.StringIO() as buff:
            with redirect_stdout(buff):
                with open(f'{fileName}', "r") as f:
                    num_lines = sum(1 for line in open(f'{fileName}'))
                    lines = f.readlines()
                    for x in range(0, num_lines):
                        data_des = {}
                        try:
                            print("\n \n")
                            barr = bytearray.fromhex(lines[x])
                            print(f"{x+1}/  {lines[x]}")
                            if not Wifi_Package(barr, data_des):
                                if not Outbug_Package(barr, data_des):
                                    print('Invalid wireless package checksum')
                                    print('Invalid outbug package checksum')

                            if len(data_des) > 0:
                                Print_Data(data_des)

                        except:
                            print('Warning ! Incorrect package type. Plz enter HEX package')
                return buff.getvalue()
    # sys.stdout = orig_stdout
    # f_Out.close()
    return ''

    