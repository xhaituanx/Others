# Version update in formation

# VERSION = "1.0.0" #The first version
VERSION = "1.0.1" #Update search history list
# TIME = "2022/09/14"
TIME = "2022/10/12"
OS = "Windows_NT x64 10.0.19043"
DESIGN = "REF Part (SHRC)"
CONTACT = "Truong Duy Khang"
