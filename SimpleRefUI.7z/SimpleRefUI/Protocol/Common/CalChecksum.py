from Common.DataConfig import *

def XORChecksum(bArrData: bytearray):
    # print("in checksum {}".format(bArrData))
    chSum = 0
    for i in range(0, len(bArrData)):
        chSum ^= bArrData[i]
        # chSum ^= ord(el)
    return chSum

def Check_Valid_Wireless_Pack(bArrData: bytearray):     # input with full package
    ret = False
    if bArrData[0] == STX_PACK and bArrData[1] == PRF_ID_PACK and bArrData[-1] == ETX_PACK:
        cal_cksum = XORChecksum(bArrData[:-2])
        if cal_cksum == bArrData[-2]:
            ret = True
        else:
            print("Cal checksum {} for: {}".format(hex(cal_cksum), bArrData.hex()))

    return ret

def Check_Valid_Outbug_Pack(bArrData: bytearray):     # input with full package
    ret = False
    if bArrData[0] == TEST_START1 and bArrData[-1] == OUTBUG_ETX_PACK:  # and \
            # ((bArrData[-4] == 0xF0 and bArrData[-3] == 0x01) or (bArrData[-4] == 0x01 and bArrData[-3] == 0xF0)):
        cal_cksum = XORChecksum(bArrData[:-2])
        if cal_cksum == bArrData[-2]:
            ret = True
        else:
            print("Cal checksum {} for: {}".format(hex(cal_cksum), bArrData.hex()))

    return ret

