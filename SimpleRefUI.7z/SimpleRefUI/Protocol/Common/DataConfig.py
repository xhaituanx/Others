# Wireless HASS
STX_PACK = 0xD0
PRF_ID_PACK = 0xC0
ETX_PACK = 0xE0

STR_CLS_ID = 'CLS ID'
STR_CMD_ID = 'CMD ID'


# ========================== Outbug ==============================
STR_START2_CMD = 'Start2 CMD'

# Protocol
MAX_LENGTH = 31

START1_ADDR = 0
START2_ADDR = 1
CMD_ADDR = 2
DATA_BASE_ADDR = 3

TEST_START1 = 0x5A
OUTBUG_ETX_PACK = 0x00

# IN Parser Structure : list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
NAME_IND_STR_LIST = 0
VAL_IND_STR_LIST = 1
DATA_CONVERT_FUNC_LIST = 4
CHECK_WRITE_LIST = 5

# OutBug : cmdid: (description, isReadcmd, writebuffer, checkwrite, clearDataFunc)
OB_DES_IDX = 0
OB_RW_IDX = 1
OB_WBUFFER_IDX = 2
OB_CKWRITE_IDX = 3
OB_CLDATA_IDX = 4

# read/write type
OB_RW_TYPE_W = 0
OB_RW_TYPE_R = 1
OB_RW_TYPE_RW = 2

