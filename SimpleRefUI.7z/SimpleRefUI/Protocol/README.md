# ProtocolParser
Use to parse Wifi  + HASS + Outbug messages
