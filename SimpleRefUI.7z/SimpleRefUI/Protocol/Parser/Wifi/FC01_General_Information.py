from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des, DisplayName

def convertSerialNo(seNum: list):
    serdict = {}
    try:
        if len(seNum) > 0:
            #ascii_string = ''.join([chr(x) for x in seNum])
            ascii_string = bytes(seNum).decode("ASCII")
            # print('Serial Number {}'.format(ascii_string))
            serdict['Value'] = ascii_string
    except:
        print('Something wrong when convert Serial Number {}'.format(seNum))
        serdict['Value'] = 'Unknown {}'.format(seNum)

    return serdict

productDict = {
    0x00:   'Refrigerator',
    0x10:   'Kimchi-Refrigerator'
}

archDict = {
    0:  'T-Type',
    1:  'T-Type Chef',
    2:  'FDR',
    3:  'FSR',
    4:  'SBS',
    5:  'BMF',
    6:  'TMF',
    7:  '1-Door',
    8:  '1-Door Freezer',
    9:  '1-Door Refrigerator'
}

designDict = {
    0:  '1-Door',
    1:  '2-Door',
    2:  '3-Door',
    3:  '4-Door',
    4:  '5-Door',
    5:  '1-Door FDSR',
    6:  '2-Door FDSR',
    7:  '3-Door FDSR',
    8:  '4-Door FDSR',
    9:  '5-Door FDSR'
}

specETC = {
    0:  'Basic',
    1:  'Normal Freezer Mono',
    2:  'Normal Refrigerator Mono',
    3:  'Normal Twin',
    4:  'Dispenser Freezer Mono',
    5:  'Dispenser Refrigerator Mono',
    6:  'Dispenser Twin',
    7:  'Soda Freezer Mono',
    8:  'Soda Refrigerator Mono',
    9:  'Soda Twin',
    10: 'Dispenser Non Plumb'
}

subTypeDict = {
    0x00:  'Sub Panel: None, Sub Wifi: None',
    0x01:  'Sub Panel: LED, Sub Wifi: None',
    0x02: 'Sub Panel: VFD, Sub Wifi: None',
    0x03: 'Sub Panel: LCD, Sub Wifi: None',
    0x04: 'Sub Panel: Family Hub, Sub Wifi: None',
    0x10: 'Sub Panel: None, Sub Wifi: Embedded',
    0x11: 'Sub Panel: LED, Sub Wifi: Embedded',
    0x12: 'Sub Panel: VFD, Sub Wifi: Embedded',
    0x13: 'Sub Panel: LCD, Sub Wifi: Embedded',
    0x14: 'Sub Panel: Family Hub, Sub Wifi: Embedded',
    0x20: 'Sub Panel: None, Sub Wifi: LCD',
    0x21: 'Sub Panel: LED, Sub Wifi: LCD',
    0x22: 'Sub Panel: VFD, Sub Wifi: LCD',
    0x23: 'Sub Panel: LCD, Sub Wifi: LCD',
    0x24: 'Sub Panel: Family Hub, Sub Wifi: LCD',
    0x30: 'Sub Panel: None, Sub Wifi: Ready',
    0x31: 'Sub Panel: LED, Sub Wifi: Ready',
    0x32: 'Sub Panel: VFD, Sub Wifi: Ready',
    0x33: 'Sub Panel: LCD, Sub Wifi: Ready',
    0x34: 'Sub Panel: Family Hub, Sub Wifi: Ready'
}

modeClassDict = {
    0:  ('Product', productDict),
    1:  ('Architecture', archDict),
    2:  ('Design', designDict),
    3:  ('Capacity', None),
    4:  ('Spec ETC', specETC),
    5:  ('Year', None),
    6:  ('Sub Type', subTypeDict),
    7:  ('Option1', None),
    8:  ('Option2', None),
    9:  ('Option3', None),
    10:  ('Option4', None),
    11:  ('Reserved12', None),
    12:  ('Option6', None),
    13:  ('Option7', None),
    14:  ('Option15', None),
    15:  ('Option16', None)
}

def modeClass(modecl: list):
    retdict = {}
    for ind, val in enumerate(modecl):
        modID = modeClassDict.get(ind, None)
        if modID:
            if modID[1]:
                retdict["0x{:02x}".format(val) + ' ' + modID[0]] = modID[1].get(val, None)
            else:
                retdict["0x{:02x}".format(val) + ' ' + modID[0]] = val
        else:
            print('Unknown model classification index {}'.format(ind))
    return retdict

def DisplayManufName(data : list):
    name={}
    name['Value'] = bytes(data[1:]).decode()
    return name


def convertOTNVertion(data: list):
    retDict = {}
    if len(data) > 0:
        # main micom
        if data[10] != 0xFE:
            # micom code
            micom_val = data[0:4]
            try:
                Code = bytes(micom_val).hex()
                tmp = Code[0:2] + Code[2:4] + Code[4:6] + bytes.fromhex(Code[6:]).decode("ASCII")
            except:
                tmp = 'Something wrong when convert Micom Code'
            retDict['Assy Micom Code'] = tmp

            # micom date
            datever_val = data[4:8]
            try:
                DateVer = bytes(datever_val).hex()
                tmp = DateVer[0:2] + '.' + DateVer[2:4] + '.' + DateVer[4:6] + ' ' + DateVer[6:]
            except:
                tmp = 'Something wrong when convert Micom Date Version'

            retDict['Micom SW Version'] = tmp

            # address
            add_val = data[8:11]
            try:
                add = bytes(add_val).hex()
                tmp = add[0:2] + add[2:4] + add[4:6]
            except:
                tmp = 'Something wrong when convert Main Address'

            retDict['Main Address'] = tmp
        else:
            retDict['Main Micom'] = 'Unsupported'


        if data[21] != 0xFE:
            retDict['Sub'] = 'Need TODO'
        else:
            retDict['Sub'] = 'Unsupported'

    return retDict


width = 25

FC01_Attr_ID_Des = {
    0x21: (f'{"Product Detection": <{width}}', wifiEn_Dis_Des),
    0x22: (f'{"Manufacture Name": <{width}}', DisplayManufName),
    0x23: (f'{"Model ID": <{width}}', None),
    0x24: (f'{"Device Type": <{width}}', None),
    0x25: (f'{"Sales Location": <{width}}', None),
    0x26: (f'{"Set ID": <{width}}', None),
    0x27: (f'{"Set ASCII": <{width}}', DisplayName),
    0x33: (f'{"OTN Version": <{width}}', convertOTNVertion),
    0x34: (f'{"Unknown Atrr ID": <{width}}', wifiEn_Dis_Des),
    0x35: (f'{"Unknown Atrr ID": <{width}}', wifiEn_Dis_Des),
    0x36: (f'{"Unknown Atrr ID": <{width}}', wifiEn_Dis_Des),
    0x40: (f'{"Model Classification": <{width}}', modeClass),
    0x50: (f'{"Unknown Atrr ID": <{width}}', wifiEn_Dis_Des),
    0x94: (f'{"Serial Num": <{width}}', convertSerialNo),
    0xE1: (f'{"MNID": <{width}}', DisplayName),
    0xE2: (f'{"Setup ID": <{width}}', DisplayName),
    0xE5: (f'{"SSID Type": <{width}}', None)
}

def FC01_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FC01_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]      # Atrr description

            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FC01'.format(hex(key)))

    # print(data_des)
    return data_des
