from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des

def consumeWatt(conwatt: list):
    retdict = {}
    if len(conwatt) == 8:
        lInstPower = conwatt[0:4]
        lSavePower = conwatt[4:]
        strInstPower = [str(data) for data in lInstPower]
        strSavePower = [str(data) for data in lSavePower]
        retdict['InstPowerValue'] = int(''.join(strInstPower))
        retdict['SavePowerValue'] = int(''.join(strSavePower))
    else:
        print('Invalid Consume Watt data')
    return retdict

width = 20

FD12_Attr_ID_Des = {
    0x01: (f'{"Common Enable": <{width}}', wifiEn_Dis_Des),
    0x13: (f'{"Consume Watt": <{width}}', consumeWatt)
}

def FD12_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FD12_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]

            #tmp_list = []
            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            # tmp_list.append(dictData[key].hex())
            # tmp_list.append(tmp_dict)
            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FD12'.format(hex(key)))

    # print(data_des)
    return data_des
