
def append_value(dict_obj, key, value):
    # Check if key exist in dict or not
    if key in dict_obj:
        # Key exist in dict.
        # Check if type of value of key is list or not
        if not isinstance(dict_obj[key], list):
            # If type is not list then make it list
            dict_obj[key] = [dict_obj[key]]
        # Append the value in list
        dict_obj[key].append(value)
    else:
        # As key is not in dict,
        # so, add key-value pair
        dict_obj[key] = value



En_Dis_Des = {
    0x0F: 'Enable',
    0xF0: 'Disable',
    0xFE: 'Not Supported'
}

def wifiEn_Dis_Des(endis: list):
    retdict = {}
    for val in endis:
        retdict["0x{:02x}".format(val)] = En_Dis_Des.get(val, 'Unknown')

    return retdict

def DisplayName(data : list):
    name = {}
    if len(data) > 0:
        name['Value'] = bytes(data).decode()
    return name

ON_OFF_Des = {
    0x0F: 'ON',
    0xF0: 'OFF',
    0xFE: 'Not Supported'
}
def on_off_status(ononff: list):
    retdict = {}
    for val in ononff:
        retdict["0x{:02x}".format(val)] = ON_OFF_Des.get(val, 'Unknown')
    return retdict


Start_Stop_Des = {
    0x0F: 'Start',
    0xF0: 'Stop',
    0xFE: 'Not Supported',
    0xFF: 'Unknown'
}
def start_stop_status(strstop: list):
    retdict = {}
    for val in strstop:
        retdict["0x{:02x}".format(val)] = Start_Stop_Des.get(val, 'Unknown')
    return retdict
