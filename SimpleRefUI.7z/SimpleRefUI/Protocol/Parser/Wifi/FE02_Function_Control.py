from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des, on_off_status, start_stop_status


Temp_Unit_Dict = {0x12: '℃',
                    0x22: '℉'}
def tempUnit(tempUn: list):
    retdict = {}
    for val in tempUn:
        retdict["0x{:02x}".format(val)] = Temp_Unit_Dict.get(val, 'Unknown')
    return retdict


Door_State_Des = {
    0x0F: 'Open',
    0xF0: 'Closed',
    0xFE: 'Not Supported'
}
def doorState(door: list):
    retdict = {}
    for val in door:
        retdict["0x{:02x}".format(val)] = Door_State_Des.get(val, 'Unknown')
    return retdict


Water_Filter_Des = {
    0x0F: 'Filter Red',
    0x80: 'Filter Orange',
    0xF0: 'Filter Disable',
    0xFE: 'Not Supported'
}
def waterFilter(waterfil: list):
    retdict = {}
    for val in waterfil:
        retdict["0x{:02x}".format(val)] = Water_Filter_Des.get(val, 'Unknown')
    return retdict



keydict = {
    0x18:   'FUNC_SABBATH_MODE_ATTR',
    0x48:   'FUNC_DOOR_ALARM_KEY_ATTR',
    0x4C:   'FUNC_POWER_REF_ATTR',
    0x5A:   'FUNC_REF_SET_TEMP_ATTR',
    0x5F:   'FUNC_VACATION_ATTR',
    0x7A:   'FUNC_CV_SET_TEMP_ATTR',
    0x7C:   'FUNC_PANTRY_SET_TEMP_ATTR',
    0x8C:   'FUNC_POWER_FRE_ATTR',
    0x9A:   'FUNC_FRE_SET_TEMP_ATTR',
    0xA2:   'FUNC_WATER_FILTER_ATTR',
    0xA3:   'FUNC_FILTER_ATTR',
    0xA6:   'FUNC_LOCK_ATTR',
    0xA8:   'FUNC_DEMO_MODE_ATTR',
    0xC8:   'FUNC_AUTOFILL_ATTR'
}

def keyWrite(keywr):
    retdict = {}
    for item in keywr:
        retdict["0x{:02x}".format(item)] = keydict.get(item, 'Unknown')
    return retdict

Ice_Status_Dict = {0x0F: 'Ice Not Making',
                                0xF0: 'Ice Making'}
def iceMaking(icestt: list):
    retdict = {}
    for item in icestt:
        retdict["0x{:02x}".format(item)] = Ice_Status_Dict.get(item, 'Unknown')
    return retdict

Func_Support_Dict = {
    0x0A:   'FUNC_KEY_WRITE_ATTR',
    0x13:   'POWER_CONSUME_WATT_ATTR',
    0x14:   'DRLC_LEVEL_ATTR',
    0x15:   'DRLC_OVERRIDE_ATTR',
    0x18:   'FUNC_SABBATH_MODE_ATTR',
    0x1E:   'FUNC_AUTOFILL_ERROR_ATTR',
    0x20:   'DRLC_REALSAVING_ATTR',
    0x22:   'FUNC_PUSH_FILTER_USAGE_MAX_ATTR',
    0x2A:   'FUNC_TEMP_UNIT_ATTR',
    0x30:   'FUNC_COMPACT_ADO_BIXBY_CONTROL_ATTR',
    0x42:   'FUNC_COMPACT_ADO_CONTROL_ATTR',
    0x46:   'FUNC_COMPACT_ADO_SUPPORTED_ATTR',
    0x47:   'FUNC_R_DOOR_OPEN_STATUS_ATTR',
    0x48:   'FUNC_DOOR_ALARM_KEY_ATTR',
    0x49:   'FUNC_R_DOOR_OPEN_ALARM_ATTR',
    0x4C:   'FUNC_POWER_REF_ATTR',
    0x57:   'FUNC_CV_DOOR_OPEN_STATUS_ATTR',
    0x59:   'FUNC_CV_DOOR_OPEN_ALARM_ATTR',
    0x5A:   'FUNC_REF_SET_TEMP_ATTR',
    0x5B:   'FUNC_REF_TEMP_MIN',
    0x5C:   'FUNC_REF_TEMP_MAX',
    0x5D:   'FUNC_REF_CURRENT_TEMP_ATTR',
    0x5E:   'FUNC_REF_ABNORMAL_ATTR',
    0x5F:   'FUNC_VACATION_ATTR',
    0x64:   'FUNC_COMPACT_ADO_OP_SOUND_CONTROL_ATTR',
    0x65:   'FUNC_ADO_DOOR_OPEN_HOLDTIME_LIST_ATTR',
    0x66:   'FUNC_ADO_DOOR_OPEN_HOLDTIME_ATTR',
    0x67:   'FUNC_DOOR_OPEN_STATUS_ATTR',
    0x69:   'FUNC_DOOR_ALARM_ATTR',
    0x6F:   'FUNC_PANTRY_SUPPORT_ATTR',
    0x74:   'FUNC_PANTRY_THAWING_TIME',
    0x7A:   'FUNC_CV_SET_TEMP_ATTR',
    0x7B:   'FUNC_CV_NAME_ATTR',
    0x7C:   'FUNC_PANTRY_SET_TEMP_ATTR',
    0x7D:   'FUNC_PANTRY_NAME_ATTR',
    0x7E:   'FUNC_CV_ABNORMAL_ATTR',
    0x87:   'FUNC_F_DOOR_OPEN_STATUS_ATTR',
    0x89:   'FUNC_F_DOOR_OPEN_ALARM_ATTR',
    0x8C:   'FUNC_POWER_FRE_ATTR',
    0x9A:   'FUNC_FRE_SET_TEMP_ATTR',
    0x9B:   'FUNC_FRE_TEMP_MIN',
    0x9C:   'FUNC_FRE_TEMP_MAX',
    0x9D:   'FUNC_FRE_CURRENT_TEMP_ATTR',
    0x9E:   'FUNC_FRE_ABNORMAL_ATTR',
    0x9F:   'FUNC_FREEZER_CONVERT_ATTR',
    0xA0:   'FUNC_REF_ERROR_ATTR',
    0xA2:   'FUNC_WATER_FILTER_ATTR',
    0xA3:   'FUNC_FILTER_ATTR',
    0xA4:   'FUNC_SPI_ATTR',
    0xA6:   'FUNC_LOCK_ATTR',
    0xA8:   'FUNC_DEMO_MODE_ATTR',
    0xAE:   'FUNC_PANEL_COMM_ERROR_ATTR',
    0xAF:   'FUNC_SPI_NAME_ATTR',
    0xC3:   'FUNC_SET_ICE_OFF_ATTR',
    0xC6:   'FUNC_ICE_MAKING_STATUS',
    0xC8:   'FUNC_AUTOFILL_ATTR',
    0xCF:   'FUNC_AUTOFILL_SUPPORT_ATTR',
}
def funcSupport(funcsupp: list):
    retdict = {}
    for item in funcsupp:
        retdict["0x{:02x}".format(item)] = Func_Support_Dict.get(item, 'Unknown')
    return retdict

TEMP_SHIFT = 40 
def DisplayTemp(data: list):
    retdict = {}
    for val in data:
        retdict["0x{:02x}".format(val)] = val - TEMP_SHIFT
    return retdict

width = 35

FE02_Attr_ID_Des = {
    0x01: (f'{"Common Enable": <{width}}', wifiEn_Dis_Des),
    0x0E: (f'{"Support ID": <{width}}', funcSupport),
    0x0A: (f'{"Key Write": <{width}}', keyWrite),
    0x18: (f'{"Sabbath mode": <{width}}', on_off_status),
    0x1E: (f'{"AutoFill Error": <{width}}', None),
    0x2A: (f'{"Temp Unit": <{width}}', tempUnit),
    0x30: (f'{"Compact ADO Bixby Control": <{width}}', None),
    0x42: (f'{"Compact ADO Control": <{width}}', None),
    0x46: (f'{"Compact ADO Supported": <{width}}', None),
    0x47: (f'{"R room Door open state": <{width}}', doorState),
    0x48: (f'{"Door Alarm Key": <{width}}', start_stop_status),
    0x49: (f'{"R room Door opening alarm": <{width}}', wifiEn_Dis_Des),
    0x4C: (f'{"Power R setting": <{width}}', on_off_status),
    0x57: (f'{"CV room Door open state": <{width}}', doorState),
    0x59: (f'{"CV room Door opening alarm": <{width}}', wifiEn_Dis_Des),
    0x5A: (f'{"R room setting temperature": <{width}}', DisplayTemp),
    0x5B: (f'{"R room setting min temperature": <{width}}', DisplayTemp),
    0x5C: (f'{"R room setting max temperature": <{width}}', DisplayTemp),
    0x5D: (f'{"R room actual temperature": <{width}}', DisplayTemp),
    0x5E: (f'{"R room abnormal temperature": <{width}}', wifiEn_Dis_Des),
    0x5F: (f'{"Vacation": <{width}}', on_off_status),
    0x64: (f'{"Compact ADO OP Sound Control": <{width}}', None),
    0x65: (f'{"ADO Door Open HoldTime List": <{width}}', None),
    0x66: (f'{"ADO Door Open HoldTime": <{width}}', None),
    0x67: (f'{"Door Open Status": <{width}}', doorState),
    0x69: (f'{"Door Alarm": <{width}}', wifiEn_Dis_Des),
    0x6F: (f'{"Pantry support": <{width}}', None),
    0x7A: (f'{"CV room setting temperature": <{width}}', None),
    0x7B: (f'{"CV name": <{width}}', None),
    0x7C: (f'{"Pantry room setting temperature": <{width}}', None),
    0x7D: (f'{"Pantry name": <{width}}', None),
    0x87: (f'{"F room Door open state": <{width}}', doorState),
    0x89: (f'{"F room Door opening alarm": <{width}}', wifiEn_Dis_Des),
    0x8C: (f'{"Power F setting": <{width}}', on_off_status),
    0x9A: (f'{"F room setting temperature": <{width}}', DisplayTemp),
    0x9B: (f'{"F room setting min temperature": <{width}}', DisplayTemp),
    0x9C: (f'{"F room setting max temperature": <{width}}', DisplayTemp),
    0x9D: (f'{"F room actual temperature": <{width}}', DisplayTemp),
    0x9E: (f'{"F room abnormal temperature": <{width}}', None),
    0xA0: (f'{"Self Diagnosis function": <{width}}', None),
    0xA2: (f'{"Water Filter": <{width}}', waterFilter),
    0xA3: (f'{"Clean Deodorization Filter": <{width}}', None),
    0xA4: (f'{"SPI": <{width}}', None),
    0xA5: (f'{"Energy Save": <{width}}', on_off_status),
    0xA6: (f'{"Lock": <{width}}', wifiEn_Dis_Des),
    0xA7: (f'{"Dispenser Lock": <{width}}', on_off_status),
    0xA8: (f'{"Demo mode": <{width}}', on_off_status),
    0xA9: (f'{"Light": <{width}}', on_off_status),
    0xC3: (f'{"Set Ice Off": <{width}}', on_off_status),
    0xC6: (f'{"Ice Making Status": <{width}}', iceMaking),
    0xC8: (f'{"AutoFill": <{width}}', None),
    0xCF: (f'{"AutoFill Supported": <{width}}', None)
}

def FE02_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FE02_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]

            #tmp_list = []
            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            # tmp_list.append(dictData[key].hex())
            # tmp_list.append(tmp_dict)
            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FE02'.format(hex(key)))

    # print(data_des)
    return data_des
