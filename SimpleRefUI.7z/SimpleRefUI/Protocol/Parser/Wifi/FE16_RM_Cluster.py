from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des

def pinCode(pin_val: list):
    retdict = {}
    retdict['Value'] = pin_val[0]   # Pin code only 1 byte
    return retdict


rmStatusDict = {0x0F: 'Enable',
                    0xEE: 'RMOTN',
                    0xF0: 'Disable'}

def rmStatus(rmstt: list):
    retdict = {}
    for val in rmstt:
        retdict["0x{:02x}".format(val)] = rmStatusDict.get(val, 'Unknown')
    return retdict



width = 20

FE16_Attr_ID_Des = {
    0xB1: (f'{"RM Key": <{width}}', wifiEn_Dis_Des),
    0xB2: (f'{"RM Pin Code": <{width}}', pinCode),
    0xB3: (f'{"RM Status": <{width}}', rmStatus),
    0xB4: (f'{"RM 7 Seg": <{width}}', wifiEn_Dis_Des)
}

def FE16_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FE16_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]    # Attr ID description

            #tmp_list = []
            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            # tmp_list.append(dictData[key].hex())
            # tmp_list.append(tmp_dict)
            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FE16'.format(hex(key)))
    # print(data_des)
    return data_des
