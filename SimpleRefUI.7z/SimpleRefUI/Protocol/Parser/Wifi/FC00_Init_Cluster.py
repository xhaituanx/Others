from Parser.Wifi.Wifi_Util import append_value


def deviceType(device: list):
    retdict = {}
    if len(device) == 2:
        strProfile = ["{:02x}".format(data) for data in device]
        retdict['Value'] = '0x' + ''.join(strProfile)
    else:
        print('Invalid Device Type data')
    return retdict


def profileType(profile: list):
    retdict = {}
    if len(profile) == 2:
        strProfile = ["{:02x}".format(data) for data in profile]
        retdict['Value'] = '0x' + ''.join(strProfile)
    else:
        print('Invalid Profile Type data')
    return retdict


FC00_Attr_ID_Des = {
    0x12: ('Device Type', deviceType),
    0x13: ('Scube Version', None),
    0x22: ('Profile Type', profileType)
}

def FC00_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FC00_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]

            #tmp_list = []
            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            # tmp_list.append(dictData[key].hex())
            # tmp_list.append(tmp_dict)
            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FC00'.format(hex(key)))
    # print(data_des)
    return data_des
