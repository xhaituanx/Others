from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des


ID97_backup_Des = {0x85: 'AP Mode',
                                0xEA: 'Network Fail',
                                0xEE: 'Network Timeout',
                                0xEF: 'Network Completed'}

fwVersionList = ['YY','MM','DD','FF']

def fwVerSion(fwversion:list):
    retdict = {}
    #retdict={'YY':1,'MM':2,'DD':3,'FF':4}
    for i in range(0,len(fwVersionList)):
        retdict[fwVersionList[i]] = hex(fwversion[i])

    #print(fwversion)
    return retdict

# macAddressList = ['B1','B2','B3','B4','B5','B6' ]

def macAddress(macaddress:list):
    retdict = {}
    tmp = hex(macaddress[0])[2:].upper()
    for i in range(1, len(macaddress)):
        tmp += ':' + hex(macaddress[i])[2:].upper()
    retdict['Value'] = tmp
    return retdict

easySetupDict = {0x22: 'Confirm Start',
                    0x2A: 'Confirm Completed',
                    0x40: 'Connect Success',
                    0x50: 'Connect Fail'}

def easySetup(easysetup: list):
    retdict = {}
    for val in easysetup:
        retdict["0x{:02x}".format(val)] = easySetupDict.get(val, 'Unknown')

    return retdict

connectStatusDict = {0x00: 'No network',
                        0x2A: 'Ap Connected',
                        0x4A: 'Internet Connected'}

def conStatus(constt: list):
    retdict = {}
    for val in constt:
        retdict["0x{:02x}".format(val)] = connectStatusDict.get(val, 'Unknown')

    return retdict

joinNetWorkDict = {0xEA: 'Network fail',
                        0xEE: 'Network timeout',
                        0xEF: 'Network compleated',
                        0x85: 'AP mode',
                        0xF0: 'Stop OP'}

def joinNetWork(constt: list):
    retdict = {}
    for val in constt:
        retdict["0x{:02x}".format(val)] = joinNetWorkDict.get(val, 'Not supported')
    return retdict

wifiFactoryRescueDict = {0x10: 'Wifi init success value',
                                                }
def wifiFactoryRescue(constt: list):
    retdict = {}
    for val in constt:
        retdict["0x{:02x}".format(val)] = wifiFactoryRescueDict.get(val, 'Not supported')
    return retdict

width = 25

FC94_Attr_ID_Des = {
    0x33: (f'{"FW Version": <{width}}', fwVerSion),
    0x82: (f'{"MAC Address": <{width}}', macAddress),
    0x88: (f'{"AP Scan Status": <{width}}', wifiEn_Dis_Des),
    0x89: (f'{"Connection Status": <{width}}', conStatus),
    0x97: (f'{"Join Network": <{width}}', joinNetWork),
    0xA1: (f'{"Easy Setup": <{width}}', easySetup),
    0xFD: (f'{"Wifi Factory Rescue": <{width}}', wifiFactoryRescue)
}

def FC94_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:    # loop Attr ID from dict
        data_key = FC94_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]    # Get Attr description

            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FC94'.format(hex(key)))
    # print(data_des)
    return data_des
