from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des


Val_Update_Type_Dict = {
    0x00: 'Init',
    0x01: 'Forced',
    0x02: 'Agree',
    0xAA: 'Time Out'
}

def updateType(uptype: list):
    retdict = {}
    for val in uptype:
        retdict["0x{:02x}".format(val)] = Val_Update_Type_Dict.get(val, 'Unknown')
    return retdict

updateTargetDict = {
    1:  'Main Only',
    2:  'Sub Only',
    3:  'Main + Sub'
}

def updateTarget(uptarget: list):
    retdict = {}
    for val in uptarget:
        retdict["0x{:02x}".format(val)] = updateTargetDict.get(val, 'Unknown')
    return retdict

updateReqDict = {
    0x10:   'Update Start',
    0x20:   'Update Ready',
    0x30:   'Update Complete'
}

def updateStrReq(upstrreq: list):
    retdict = {}
    for val in upstrreq:
        retdict["0x{:02x}".format(val)] = updateReqDict.get(val, 'Unknown')
    return retdict

width = 35

FE14_Attr_ID_Des = {
    0xD1: (f'{"OTN Force Update Start Request": <{width}}', None),
    0xD2: (f'{"OTN Force Update Target": <{width}}', None),
    0xF0: (f'{"OTN User Certification": <{width}}', wifiEn_Dis_Des),
    0xF1: (f'{"OTN Update Start Request": <{width}}', updateStrReq),
    0xF2: (f'{"OTN Set Update Target": <{width}}', updateTarget),
    0xF3: (f'{"OTN Set Update Available": <{width}}', wifiEn_Dis_Des),
    0xF5: (f'{"OTN Set Update Possibility": <{width}}', wifiEn_Dis_Des),
    0xF7: (f'{"OTN Update Type": <{width}}', updateType)
}

def FE14_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FE14_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]

            #tmp_list = []
            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            # tmp_list.append(dictData[key].hex())
            # tmp_list.append(tmp_dict)
            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FE14'.format(hex(key)))
    # print(data_des)
    return data_des

