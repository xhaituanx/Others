from Parser.Wifi.Wifi_Util import append_value, wifiEn_Dis_Des

realSavingDict = {
    0x0F: 'RealSaving ON',
    0xF0: 'RealSaving Off'
}

def realSaving_Des(realsv: list):
    retdict = {}
    for val in realsv:
        retdict["0x{:02x}".format(val)] = realSavingDict.get(val, 'Unknown')

    return retdict


width = 25

FD01_Attr_ID_Des = {
    0x12: (f'{"Start time": <{width}}', None),
    0x13: (f'{"Duration": <{width}}', None),
    0x14: (f'{"DR Level": <{width}}', None),
    0x15: (f'{"DRLC Override": <{width}}', wifiEn_Dis_Des),
    0x16: (f'{"Defrost delay": <{width}}', wifiEn_Dis_Des),
    0x20: (f'{"DRLC AI Saving Mode": <{width}}', realSaving_Des),
    0xD2: (f'{"INST Power": <{width}}', None)
}

def FD01_Data_Des(dictData: {}):
    # print(dictData)
    data_des = {}
    for key in dictData:
        data_key = FD01_Attr_ID_Des.get(key, None)
        if data_key:
            data_des["0x{:02x}".format(key)] = data_key[0]      # Atrr description

            #tmp_list = []
            tmp_dict = {}
            if data_key[1]:
                attr_val = list(dictData[key])
                tmp_dict.update(data_key[1](attr_val))
            else:
                tmp_dict['Value'] = dictData[key].hex()

            # tmp_list.append(dictData[key].hex())
            # tmp_list.append(tmp_dict)
            append_value(data_des, "0x{:02x}".format(key), tmp_dict)
        else:
            print('Unknown Attr ID {} cluster FD01'.format(hex(key)))
    # print(data_des)
    return data_des
