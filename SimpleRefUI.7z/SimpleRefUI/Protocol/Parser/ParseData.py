import ctypes
# import pprint
import json
from Parser.DataStruct import HeaderWifiStruct, HeaderOutBugStruct
from Common.DataConfig import *
from Parser.DataDict import Cmd_ID_Des, Cluster_ID_Des, Outbug_ID_Des
from Common.CalChecksum import Check_Valid_Wireless_Pack, Check_Valid_Outbug_Pack


def Parse_Attr_ID_and_Value(bArrData: bytearray):
    id_val = {}
    i = 0
    while i < len(bArrData):
        id = bArrData[i]    # Attr ID
        ll = bArrData[i+1]  # Len of data
        val = bArrData[i+2: i+2+ll]     # 1 for id, 1 for len
        id_val[id] = val
        # loop for next ID
        i += 1+1+ll     # 1 for id, 1 for len
    return id_val

def Wifi_Des(bArrData: bytearray, data_des: dict):   # input full package
    header_len = ctypes.sizeof(HeaderWifiStruct)    # header length
    headerParse = HeaderWifiStruct.from_buffer_copy(bArrData[:header_len])
    # print(headerParse)
    cls_id = getattr(headerParse, STR_CLS_ID)   # Get cluster ID value from name
    cls_des = Cluster_ID_Des.get(cls_id, None)
    if cls_des:
        data_des[hex(cls_id)] = cls_des[0]    # cluster description

        cmd_id = getattr(headerParse, STR_CMD_ID)       # Get cmd ID value from name
        cmd_des = Cmd_ID_Des.get(cmd_id, None)
        data_des["0x{:02x}".format(cmd_id)] = cmd_des               # cmd description

        if cls_des[1]:
            # get attr des
            lenof = bArrData[header_len]  # value indicate length of data
            data_dict = Parse_Attr_ID_and_Value(bArrData[header_len + 1: header_len + 1 + lenof])
            data_des.update(cls_des[1](data_dict))
        elif cls_id == 0xFE15:  # Scube HASS
            lenof = bArrData[header_len]  # value indicate length of data
            Outbug_Des(bArrData[header_len + 1: header_len + 1 + lenof], data_des)
        else:
            print("Unknown data parsing function")
    else:
        print('Unknown cluster id {}'.format(hex(cls_id)))
        cls_id = None

    # print(hd_des)
    # print()
    # for key, val in data_des.items():
    #     print(key, ' : ', val[0], end='')
    #     if len(val[1]) > 2:
    #         # pprint.pprint(val[1], sort_dicts=False)
    #         print(json.dumps(val[1], indent=8))
    #     else:
    #         print(val[1])

    return cls_id


def isOutbug_PCtoPBA(bArrData: bytearray):   # input full package
    if bArrData[-4] == 0xF0 and bArrData[-3] == 0x01:
        return True
    return False


def Outbug_Des(bArrData: bytearray, data_des: dict):   # input full package
    header_len = ctypes.sizeof(HeaderOutBugStruct)
    headerParse = HeaderOutBugStruct.from_buffer_copy(bArrData[:header_len])
    # print(headerParse)
    cmd_id = getattr(headerParse, STR_START2_CMD)   # Get cluster ID value from name
    cmd_des = Outbug_ID_Des.get(cmd_id, None)
    if cmd_des:
        data_des[hex(cmd_id)] = cmd_des[OB_DES_IDX]    # store cmd ID and description

        if cmd_des[OB_WBUFFER_IDX]:     # temporary check, will remove later
            cmd_des[OB_CLDATA_IDX]()  # clear old data
            if cmd_des[OB_RW_IDX] == OB_RW_TYPE_R:
                if isOutbug_PCtoPBA(bArrData):
                    data_des['0xf001'] = 'PC -> PBA => {}'
                else:
                    data_des['0x01f0'] = 'PBA -> PC'
                    cmd_des[OB_WBUFFER_IDX](bArrData)  # parse data
                    data_des.update(cmd_des[OB_CKWRITE_IDX]())  # check write and return des
            elif cmd_des[OB_RW_IDX] == OB_RW_TYPE_W:
                if isOutbug_PCtoPBA(bArrData):
                    data_des['0xf001'] = 'PC -> PBA'
                    cmd_des[OB_WBUFFER_IDX](bArrData)  # parse data
                    data_des.update(cmd_des[OB_CKWRITE_IDX]())  # check write and return des
                else:
                    data_des['0xf001'] = 'PBA -> PC => {}'
            else:   # cmd can read/write
                if isOutbug_PCtoPBA(bArrData):
                    data_des['0xf001'] = 'PC -> PBA'
                else:
                    data_des['0xf001'] = 'PBA -> PC'

                cmd_des[OB_WBUFFER_IDX](bArrData)  # parse data
                data_des.update(cmd_des[OB_CKWRITE_IDX]())  # check write and return des

        else:
            print("Unknown data parsing function")
    else:
        print('Unknown Outbug cmd id {}'.format(hex(cmd_id)))
        cmd_id = None

    # print(hd_des)
    # print()
    # for key, val in data_des.items():
    #     print(key, ' : ', val)

    return cmd_id

def Wifi_Package(barr: bytearray, data_des: dict):
    cmd_id = None
    if Check_Valid_Wireless_Pack(barr):
        cmd_id = Wifi_Des(barr, data_des)
    # else:
    #     print('Invalid wireless package checksum')
    return cmd_id


def Outbug_Package(barr: bytearray, data_des: dict):
    cmd_id = None
    if Check_Valid_Outbug_Pack(barr):
        cmd_id = Outbug_Des(barr, data_des)
    # else:
    #     print('Invalid outbug checksum')
    return cmd_id

def Print_Data(indata: dict):
    for key, val in indata.items():
        if isinstance(val, list):
            if len(val) <= 1:
                print(key, ':', val)
            else:
                print(key, ':', val[0], end='')
                if len(val[1]) > 2:
                    # pprint.pprint(val[1], sort_dicts=False)
                    print(json.dumps(val[1], indent=8))
                else:
                    print(val[1])
        else:
            print(key, ':', val)

