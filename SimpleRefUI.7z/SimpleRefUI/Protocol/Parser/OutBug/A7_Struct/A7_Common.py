
STR_R_NOTCH_SETTING = 'R Room Setting Notch'
STR_F_NOTCH_SETTING = 'F Room Setting Notch'
STR_VACATION_FUNC = 'Vacation Function'
STR_DOOR_ALARM = 'Door Alarm Key'
STR_DEMO_MODE = 'Demo Mode'
STR_LOCK_MODE = 'Lock'
STR_ICE_MODE = 'Ice OnOff'
STR_F_FAN_RPM = 'Fan RPM'
STR_FAST_MODE = 'Fast Mode'

