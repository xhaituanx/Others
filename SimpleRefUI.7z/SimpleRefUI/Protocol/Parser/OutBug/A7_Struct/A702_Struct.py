from Parser.DataStruct import *
from Parser.OutBug.DataConvert import exCheckZeroList, sensorToTemp, sensorToHumidity
from Parser.OutBug.A7_Struct.A701_Struct import sensorWREnable


width = 50
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
sensorRW2List = [
    # DATA1~2
    [f'{"Ice Room Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"Auto write Ice making sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA3~4
    [f'{"R Ice Maker Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"Auto write Ice Maker sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA5~6
    [f'{"R Humidity Sensor": <{width}}', [], 8, 1, sensorToHumidity, exCheckZeroList],
    [f'{"Auto write R room humidity sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA7~8
    [f'{"R Rotary switch": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write R rotary switch": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA9~10
    [f'{"F Rotary switch": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write F Rotary switch": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA11~12
    [f'{"Crystal IM sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write Crystal IM sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA13~14
    [f'{"Top Humidity sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write Top Humidity sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA15~16
    [f'{"Bot Humidity sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write Bot Humidity sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA17~18
    [f'{"Mid Humidity sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write Mid Humidity sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA19~20
    [f'{"P Room2 sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write P Room2 sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA21~22
    [f'{"Plate sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write Plate sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA23~24
    [f'{"ExtPlate sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Auto write ExtPlate sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList]
]

class A702_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(sensorRW2List)
