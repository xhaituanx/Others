from Parser.DataStruct import *
from Parser.OutBug.DataConvert import readwrite, exCheckZeroList
from Parser.OutBug.A7_Struct.A7_Common import *

FNotch_Type_Des = {
    0x00:   'Fahrenheit',
    0x01:   'Celsius',
    0x02:   'Bar Type 5 Steps',
    0x03:   'Bar Type 7 Steps',
    0x04:   'Bar Type 6 Steps',
    0x0A:   'Wine Fahrenheit',
    0x0B:   'Wine Celsius'
}
def FNotchType_conv(ldata: list):
    ftval = ldata[0]
    return FNotch_Type_Des.get(ftval, 'Unknown')



FNotch_F_Des = {
    0x05:	'5℉/4℉',
    0x04:	'3℉',
    0x03:	'2℉',
    0x02:	'1℉',
    0x01:	'0℉',
    0xFF:	'-1℉/-2℉',
    0xFD:	'-3℉',
    0xFC:	'-4℉',
    0xFB:	'-5℉',
    0xFA:	'-6℉',
    0xF9:	'-7℉',
    0xF8:	'-8℉'
}
FNotch_C_Des = {
    0xF1:	'-15℃',
    0xF0:	'-16℃',
    0xEF:	'-17℃',
    0xEE:	'-18℃',
    0xED:	'-19℃',
    0xEC:	'-20℃',
    0xEB:	'-21℃',
    0xEA:	'-22℃',
    0xE9:	'-23'
}
Wine_F_Des = {
    0x01:	'65℉',
    0x02:	'64℉',
    0x03:	'63℉',
    0x04:	'62℉',
    0x05:	'61℉',
    0x06:	'60℉',
    0x07:	'59℉',
    0x08:	'58℉',
    0x09:	'57℉',
    0x0A:	'56℉',
    0x0B:	'55℉',
    0x0C:	'54℉',
    0x0D:	'53℉',
    0x0E:	'52℉',
    0x0F:	'51℉',
    0x10:	'50℉',
    0x11:	'49℉',
    0x12:	'48℉',
    0x13:	'47℉',
    0x14:	'46℉',
    0x15:	'45℉',
    0x16:	'44℉',
    0x17:	'43℉',
    0x18:	'42℉',
    0x19:	'41℉',
    0x1A:	'40℉'
}
Wine_C_Des = {
    0x01:	'18℃',
    0x03:	'17℃',
    0x05:	'16℃',
    0x07:	'15℃',
    0x09:	'14℃',
    0x0B:	'13℃',
    0x0C:	'12℃',
    0x0E:	'11℃',
    0x10:	'10℃',
    0x12:	'9℃',
    0x14:	'8℃',
    0x16:	'7℃',
    0x17:	'6℃',
    0x19:	'5℃',
    0x1A:	'4℃'
}
def FNotch_change_conv(ldata: list):
    ftval = ldata[0]
    if ftval == 0x00:
        return FNotch_F_Des.get(ftval, 'Unknown')
    elif ftval == 0x01:
        return FNotch_C_Des.get(ftval, 'Unknown')
    elif ftval == 0x03 or ftval == 0x04:
        return "Need to implement for {}".format(hex(ftval))
    elif ftval == 0x0A:
        return Wine_F_Des.get(ftval, 'Unknown')
    elif ftval == 0x0B:
        return Wine_C_Des.get(ftval, 'Unknown')
    else:
        return 'Unknown'


width = 25
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
FNotchList = [
    # DATA1~2
    [f'{"F Notch Read/Write": <{width}}', [], 8, 1, readwrite, exCheckZeroList],
    [f'{"F Notch Type": <{width}}', [], 8, 1, FNotchType_conv, exCheckZeroList],
    [f'{STR_F_NOTCH_SETTING: <{width}}', [], 8, 1, FNotch_change_conv, exCheckZeroList],  # DATA3
    [f'{"Reserved": <{width}}', [], 8, 21, None, exCheckZeroList]
]

class A703_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(FNotchList)
