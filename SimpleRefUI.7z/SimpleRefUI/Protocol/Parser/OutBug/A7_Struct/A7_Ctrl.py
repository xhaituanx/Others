import ctypes
from Common.DataConfig import *
from Parser.OutBug.OutBug_Util import addDataToBuffer, checkWritetable, ClearStructData
from Parser.OutBug.A7_Struct.A701_Struct import A701_FieldStruct, sensorRW1List
from Parser.OutBug.A7_Struct.A702_Struct import A702_FieldStruct, sensorRW2List
from Parser.OutBug.A7_Struct.A703_Struct import A703_FieldStruct, FNotchList
from Parser.OutBug.A7_Struct.A704_Struct import A704_FieldStruct, RNotchList
from Parser.OutBug.A7_Struct.A708_Struct import A708_FieldStruct, funcIOList
from Parser.OutBug.A7_Struct.A709_Struct import A709_FieldStruct, fastSWList
from Parser.OutBug.A7_Struct.A70B_Struct import A70B_FieldStruct, doorWriteList
from Parser.OutBug.A7_Struct.A70C_Struct import A70C_FieldStruct, defrostInfoList
from Parser.OutBug.A7_Struct.A70D_Struct import A70D_FieldStruct, fanRPMList
from Parser.OutBug.A7_Struct.A70E_Struct import A70E_FieldStruct, tempOnOffList


# A701
def A701_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A701_FieldStruct)
    sensorRW1Parsed = A701_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(sensorRW1Parsed, sensorRW1List)

def A701_CheckWrite():
    return checkWritetable(sensorRW1List)

def A701_ClearData():
    ClearStructData(sensorRW1List)


# A702
def A702_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A702_FieldStruct)
    sensorRW2Parsed = A702_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(sensorRW2Parsed, sensorRW2List)

def A702_CheckWrite():
    return checkWritetable(sensorRW2List)

def A702_ClearData():
    ClearStructData(sensorRW2List)

# A703
def A703_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A703_FieldStruct)
    FnotchParsed = A703_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(FnotchParsed, FNotchList)

def A703_CheckWrite():
    return checkWritetable(FNotchList)

def A703_ClearData():
    ClearStructData(FNotchList)


# A704
def A704_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A704_FieldStruct)
    RnotchParsed = A704_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(RnotchParsed, RNotchList)

def A704_CheckWrite():
    return checkWritetable(RNotchList)

def A704_ClearData():
    ClearStructData(RNotchList)



# A708
def A708_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A708_FieldStruct)
    funcIOParsed = A708_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(funcIOParsed, funcIOList)

def A708_CheckWrite():
    return checkWritetable(funcIOList)

def A708_ClearData():
    ClearStructData(funcIOList)


# A709
def A709_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A709_FieldStruct)
    fastSWParsed = A709_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(fastSWParsed, fastSWList)

def A709_CheckWrite():
    return checkWritetable(fastSWList)

def A709_ClearData():
    ClearStructData(fastSWList)

# A70B
def A70B_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A70B_FieldStruct)
    doorSWParsed = A70B_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(doorSWParsed, doorWriteList)

def A70B_CheckWrite():
    return checkWritetable(doorWriteList)

def A70B_ClearData():
    ClearStructData(doorWriteList)


# A70C
def A70C_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A70C_FieldStruct)
    defrostParsed = A70C_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(defrostParsed, defrostInfoList)

def A70C_CheckWrite():
    return checkWritetable(defrostInfoList)

def A70C_ClearData():
    ClearStructData(defrostInfoList)

# A70D
def A70D_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A70D_FieldStruct)
    fanParsed = A70D_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(fanParsed, fanRPMList)

def A70D_CheckWrite():
    return checkWritetable(fanRPMList)

def A70D_ClearData():
    ClearStructData(fanRPMList)


# A70E
def A70E_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A70E_FieldStruct)
    tempParsed = A70E_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(tempParsed, tempOnOffList)

def A70E_CheckWrite():
    return checkWritetable(tempOnOffList)

def A70E_ClearData():
    ClearStructData(tempOnOffList)


