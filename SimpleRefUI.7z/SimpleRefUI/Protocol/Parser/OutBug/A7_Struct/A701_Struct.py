from Parser.DataStruct import *
from Parser.OutBug.DataConvert import exCheckZeroList, sensorToTemp, sensorToHumidity

def sensorWREnable(endis: list):
    en_val = endis[0]
    if en_val == 8:
        return 'Write enable'
    elif en_val == 4:
        return 'Write disable'
    elif en_val == 0:
        return 'Read enable'
    else:
        return 'Unknown value {}'.format(en_val)

def sensorToTemp10bit(hex: list):
    hex_val = hex[0]
    retStr = ''
    tmp_val = list(bytes(hex_val))
    readw = (tmp_val[1] & 0x0C) >> 2
    if readw == 0x02:
        retStr += 'Write: '
        retStr += str(sensorToTemp(tmp_val)) + ' ( 8bit ' + str(int(tmp_val[0]))
        retStr += ' OR 10bit ' + str(int((tmp_val[0] << 2) | (tmp_val[1] & 0x03))) + ' )'
    elif readw == 0x01:
        retStr += 'Write Disable'
    else:
        retStr += 'Unknown Read/Write'
    return retStr

width = 50
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
sensorRW1List = [
    # DATA1~2
    [f'{"F Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Freezer sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA3~4
    [f'{"R Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Refrigerator sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA5~6
    [f'{"F Defrost Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Freezer Defrost sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA7~8
    [f'{"R Defrost Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Refrigerator Defrost sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA9~10
    [f'{"Outside Air Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Outside air sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA11~12
    [f'{"Pantry Room Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Pantry Room sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA13~14
    [f'{"Ice Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Ice making sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA15~16
    [f'{"CV Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write Convertible sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA17~18
    [f'{"CR Room1 Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write C/R sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA19~20
    [f'{"CV Defrost Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write C/F (C/V) chamber defrost sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA21~22
    [f'{"CR Defrost Sensor (°C)": <{width}}', [], 8, 2, sensorToTemp10bit, exCheckZeroList],
    # [f'{"Auto write C/R room defrost sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList],
    # DATA23~24
    [f'{"Humidity sensor (%)": <{width}}', [], 8, 1, sensorToHumidity, exCheckZeroList],
    [f'{"Auto write Humidity sensor": <{width}}', [], 8, 1, sensorWREnable, exCheckZeroList]
]

class A701_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(sensorRW1List)
