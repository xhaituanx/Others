from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault
from Parser.OutBug.A7_Struct.A7_Common import *


fastEnDis = {
    0x01: 'Enable',
    0x00: 'Disable'
}

fastTF = {
    0x00: 'True',
    0x01: 'False'
}

def fastEnDis_conv(ldata: list):
    ftval = ldata[0]
    return fastEnDis.get(ftval, 'Unknown')

def fastTF_conv(ldata: list):
    ftval = ldata[0]
    return fastTF.get(ftval, 'Unknown')

width = 25
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
fastSWList = [
    # DATA1~2
    [f'{"Fast Test En/Dis": <{width}}', [], 8, 1, fastEnDis_conv, writeDefault],
    [f'{STR_FAST_MODE: <{width}}', [], 8, 1, fastTF_conv, writeDefault]
]

class A709_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(fastSWList)
