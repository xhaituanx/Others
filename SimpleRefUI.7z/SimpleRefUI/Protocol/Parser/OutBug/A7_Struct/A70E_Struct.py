from Parser.DataStruct import *
from Parser.OutBug.DataConvert import exCheckZeroList


width = 50
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
tempOnOffList = [
    # DATA1~2
    [f'{"F room on point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"F room on point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA3~4
    [f'{"F room off point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"F room off point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA5~6
    [f'{"R room on point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"R room on point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA7~8
    [f'{"R room off point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"R room off point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA9~10
    [f'{"CV room (Flex) On point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"CV room (Flex) On point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA11~12
    [f'{"CV room (Flex) off point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"CV room (Flex) off point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA13~14
    [f'{"Pantry On Point Count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Pantry On Point Count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA15~16
    [f'{"Pantry Off Point Count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Pantry Off Point Count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA17~18
    [f'{"I room on point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"I room on point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA19~20
    [f'{"I room off point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"I room off point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA21~22
    [f'{"Pantry2 On point count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Pantry2 On point count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA23~24
    [f'{"Pantry2 Off Point Count (top 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Pantry2 Off Point Count (lower 2Bit)": <{width}}', [], 8, 1, None, exCheckZeroList]
]

class A70E_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(tempOnOffList)
