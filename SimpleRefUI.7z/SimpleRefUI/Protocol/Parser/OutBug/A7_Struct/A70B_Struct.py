from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault


def autoDoorEnDis(autodoor: list):
    autodoor_val = autodoor[0]
    if autodoor_val == 0x01:
        return 'Enable'
    elif autodoor_val == 0x00:
        return 'Disable'
    else:
        return 'Unknown value {}'.format(autodoor_val)


def doorHiLo(doorstt: list):
    doorstt_val = doorstt[0]
    if doorstt_val == 0x01:
        return 'HIGH'
    elif doorstt_val == 0x00:
        return 'LOW'
    else:
        return 'Unknown value {}'.format(doorstt_val)


width = 50
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
doorWriteList = [
    # DATA1~2
    [f'{"F Door Switch Enable/Disable": <{width}}', [], 8, 1, autoDoorEnDis, writeDefault],
    [f'{"F Door Switch HIGH/LOW": <{width}}', [], 8, 1, doorHiLo, writeDefault],
    # DATA3~4
    [f'{"R Door Switch Enable/Disable": <{width}}', [], 8, 1, autoDoorEnDis, writeDefault],
    [f'{"R Door Switch HIGH/LOW": <{width}}', [], 8, 1, doorHiLo, writeDefault],
    # DATA5~6
    [f'{"CV Door Switch Enable/Disable": <{width}}', [], 8, 1, autoDoorEnDis, writeDefault],
    [f'{"CV Door Switch HIGH/LOW": <{width}}', [], 8, 1, doorHiLo, writeDefault]
]

class A70B_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(doorWriteList)
