from Parser.DataStruct import *
from Parser.OutBug.DataConvert import readwrite, exCheckZeroList
from Parser.OutBug.A7_Struct.A7_Common import *

RNotch_Type_Des = {
    0x00:   'Fahrenheit',
    0x01:   'Celsius',
    0x02:   'Bar Type 5 Steps',
    0x03:   'Bar Type 7 Steps',
    0x04:   'Bar Type 6 Steps',
    0x0A:   'Wine Fahrenheit',
    0x0B:   'Wine Celsius'
}
def RNotchType_conv(ldata: list):
    ftval = ldata[0]
    return RNotch_Type_Des.get(ftval, 'Unknown')



RNotch_F_Des = {
    0x2C:	'44℉',
    0x2B:	'43℉',
    0x2A:	'42℉',
    0x29:	'41℉',
    0x28:	'40℉',
    0x27:	'39℉',
    0x26:	'38℉',
    0x25:	'37℉',
    0x24:	'36℉',
    0x23:	'35℉',
    0x22:	'34'
}
RNotch_C_Des = {
    0x07:	'7℃',
    0x06:	'6℃',
    0x05:	'5℃',
    0x04:	'4℃',
    0x03:	'3℃',
    0x02:	'2℃',
    0x01:	'1℃',
    0x00:	'0℃'
}

def RNotch_change_conv(ldata: list):
    ftval = ldata[0]
    if ftval == 0x00:
        return RNotch_F_Des.get(ftval, 'Unknown')
    elif ftval == 0x01:
        return RNotch_C_Des.get(ftval, 'Unknown')
    elif ftval == 0x03 or ftval == 0x04 or ftval == 0x0A or ftval == 0x0B:
        return "Need to implement for {}".format(hex(ftval))
    else:
        return 'Unknown'


width = 25
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
RNotchList = [
    # DATA1~2
    [f'{"R Notch Read/Write": <{width}}', [], 8, 1, readwrite, exCheckZeroList],
    [f'{"R Notch Type": <{width}}', [], 8, 1, RNotchType_conv, exCheckZeroList],
    [f'{STR_R_NOTCH_SETTING: <{width}}', [], 8, 1, RNotch_change_conv, exCheckZeroList],  # DATA3
    [f'{"Reserved": <{width}}', [], 8, 21, None, exCheckZeroList]
]

class A704_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(RNotchList)
