from Parser.DataStruct import *
from Parser.OutBug.DataConvert import exCheckZeroList
from Parser.OutBug.A7_Struct.A7_Common import *

width = 50
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
fanRPMList = [
    # DATA1~2
    [f'{STR_F_FAN_RPM: <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"F-FAN RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA3~4
    [f'{"R-FAN RPM Count (upper 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"R-FAN RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA5~6
    [f'{"CV-FAN RPM Count (upper 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"CV-FAN RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA7~8
    [f'{"P-FAN RPM Count (upper 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"P-FAN RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA9~10
    [f'{"I-FAN RPM Count (upper 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"I-FAN RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA11~12
    [f'{"C-FAN RPM Count (upper 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"C-FAN RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DATA13~14
    [f'{"P-FAN2 RPM Count (upper 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"P-FAN2 RPM Count (lower 8Bit)": <{width}}', [], 8, 1, None, exCheckZeroList]
]

class A70D_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(fanRPMList)
