from Parser.DataStruct import *
from Parser.OutBug.DataConvert import readwrite, exCheckZeroList, onOffStatus, settingRelease
from Parser.OutBug.A7_Struct.A7_Common import *

def lowhigh(lhigh: list):
    lhigh_val = lhigh[0]
    tmp = int(lhigh_val)
    if tmp == 1:
        return 'Full'
    elif tmp == 2:
        return 'Low'
    else:
        return 'Unknown {}'.format(tmp)

width = 55
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
funcIOList = [
    # DATA1~2
    [f'{"Read/Write": <{width}}', [], 8, 1, readwrite, exCheckZeroList],
    [f'{STR_ICE_MODE: <{width}}', [], 8, 1, onOffStatus, exCheckZeroList],
    [f'{"Energy Save OnOff": <{width}}', [], 8, 1, onOffStatus, exCheckZeroList],  # DATA3
    [f'{"Full Ice / Low Ice": <{width}}', [], 8, 1, lowhigh, exCheckZeroList],
    [f'{"Rapid F setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"Rapid R setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"Dispenser Lock setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],   # DATA7
    [f'{STR_DEMO_MODE: <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{STR_VACATION_FUNC: <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"2nd Ice On/Off": <{width}}', [], 8, 1, onOffStatus, exCheckZeroList],     # DATA10
    [f'{STR_DOOR_ALARM: <{width}}', [], 8, 1, onOffStatus, exCheckZeroList],
    [f'{STR_LOCK_MODE: <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"AutoFill setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"ADO sensitivity setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],    # DATA14
    [f'{"Night ice making function setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"Defrost setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"Slow Ice setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],
    [f'{"ADOC setting/release": <{width}}', [], 8, 1, settingRelease, exCheckZeroList],   # DATA18
    [f'{"Reserved": <{width}}', [], 8, 6, None, exCheckZeroList]
]

class A708_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(funcIOList)
