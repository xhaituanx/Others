from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault


width = 50
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
defrostInfoList = [
    # DATA1~2
    [f'{"Defrosting cycle (time)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Comp integration (Hr)": <{width}}', [], 8, 1, None, writeDefault],
    # DATA3~4
    [f'{"Comp integration (Min)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Number of Door Opens": <{width}}', [], 8, 1, None, writeDefault],
    # DATA5~6
    [f'{"Door Open cumulative time (top 8Bit)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Door Open cumulative time (lower 8Bit)": <{width}}', [], 8, 1, None, writeDefault],
    # DATA7~9
    [f'{"Real-time defrost operation": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Real-time defrost cycle remaining time (top 8Bit)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Real-time defrost cycle remaining time (lower 8Bit)": <{width}}', [], 8, 1, None, writeDefault]
]

class A70C_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(defrostInfoList)
