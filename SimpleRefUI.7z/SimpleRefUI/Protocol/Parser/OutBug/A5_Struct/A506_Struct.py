from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList

def convertMicomCode(micomcode: list):
    micom_val = micomcode[0]
    try:
        Code = bytes(micom_val).hex()
        return Code[0:2] + Code[2:4] + Code[4:6] + bytes.fromhex(Code[6:]).decode("ASCII")
    except:
        print('Something wrong when convert Micom Code')
        return ''

def convertDateVer(datever: list):
    datever_val = datever[0]
    try:
        DateVer = bytes(datever_val).hex()
        return DateVer[0:2] + '.' + DateVer[2:4] + '.' + DateVer[4:6] + ' ' + DateVer[6:]
    except:
        print('Something wrong when convert Micom Date Version')
        return ''

width = 25
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
ONTUpdateVerList = [
    [f'{"Main Assy Micom Code": <{width}}', [], 8, 4, convertMicomCode, writeDefault],
    [f'{"Main Date Version": <{width}}', [], 8, 4, convertDateVer, writeDefault],
    [f'{"reserved9": <{width}}', [], 8, 2, None, exCheckZeroList],
    [f'{"Sub Assy Micom Code": <{width}}', [], 8, 4, None, exCheckZeroList],
    [f'{"Sub Date Version": <{width}}', [], 8, 4, None, exCheckZeroList]
]


class A506_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(ONTUpdateVerList)

