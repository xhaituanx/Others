from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList

width = 45

def pressedState(pressval: list):
    pressval_val = pressval[0]
    tmp = int(pressval_val)
    if tmp == 1:
        return 'Pressed'
    else:
        return 'Not pressed'

def avtiveState(state: list):
    state_val = state[0]
    tmp = int(state_val)
    if tmp == 1:
        return 'Active'
    else:
        return 'Deactive'

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
otherInputList = [
    #DATA1
    [f'{"Damper Heater Open": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F-Damper Heater Open": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Key Input1": <{width}}', [], 1, 1, pressedState, writeDefault],
    [f'{"Key Input2": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R room Ice Duct (Drain) Heater Open": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Ice Making Room Bucket (Room) Heater Open": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Handel Heater Open Error Detection Input Port": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Crystal Ice Making Room Bucket (Room) Heater Open": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DATA2
    [f'{"F-Fan FG": <{width}}', [], 1, 1, avtiveState, writeDefault],
    [f'{"R-Fan FG": <{width}}', [], 1, 1, avtiveState, writeDefault],
    [f'{"C-Fan FG": <{width}}', [], 1, 1, avtiveState, writeDefault],
    [f'{"I-Fan FG": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"M-Fan FG": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"CV-Fan FG": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"Inv. R-Comp Feedback": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"Inv. Comp Feedback": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA3
    [f'{"Flow Sensor": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"P-Fan FG": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved": <{width}}', [], 6, 1, None, exCheckZeroList]
]

class A512_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(otherInputList)