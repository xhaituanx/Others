from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault, exCheckZeroList

width = 20

def fanstate(fan:list):
    fanval = fan[0]
    tmp = int(fanval)
    if tmp == 1:
        return 'HIGH'
    else:
        return 'OFF'

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
fanList = [
    #DATA1
    [f'{"F-Fan High": <{width}}', [], 1, 1, fanstate, writeDefault],
    [f'{"F-Fan Low": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Fan High": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Fan Low": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"C-Fan High": <{width}}', [], 1, 1, fanstate, writeDefault],
    [f'{"C-Fan Low": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"I-Fan High": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"I-Fan Low": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA2
    [f'{"C-Fan": <{width}}', [], 1, 1, fanstate, writeDefault],
    [f'{"reserved2_2": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Box-Fan": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Deo-Fan": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Mid-Fan": <{width}}', [], 1, 1, fanstate, writeDefault],
    [f'{"P-Fan": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved2_6": <{width}}', [], 2, 1, None, exCheckZeroList]
]

class A532_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(fanList)