from Parser.DataStruct import *
from Parser.OutBug.DataConvert import convertDectoHex, writeDefault, exCheckZeroList, diodeConvert

width = 25

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
versionOptionList = [
    [f'{"Model Year": <{width}}', [], 8, 1, convertDectoHex, writeDefault],
    [f'{"Model Code": <{width}}', [], 8, 1, convertDectoHex, writeDefault],
    [f'{"Version": <{width}}', [], 8, 1, convertDectoHex, writeDefault],
    [f'{"reserved4": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Diode Option": <{width}}', [], 8, 1, diodeConvert, writeDefault]
]

class A530_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(versionOptionList)
