from Parser.DataStruct import *
from Parser.OutBug.DataConvert import sensorToTemp, sensorToHumidity, exCheckZeroList, writeDefault
from Parser.OutBug.A5_Struct.A5_Common import *

width = 45

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
sensorValueList = [
    [f'{STR_F_ROOM_TEMP: <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{STR_R_ROOM_TEMP: <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"Refrigerator (second) Sensor upper byte": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{STR_F_DEF_TEMP: <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    # DAT5
    [f'{STR_R_DEF_TEMP: <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{STR_AIR_TEMP: <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"Pantry Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"Ice Maker Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    # DAT9
    [f'{"CV Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"CR Room Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"CV Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    # DAT12
    [f'{"CR Defrost Sensor": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{STR_HUMIDITY_STATUS: <{width}}', [], 8, 1, sensorToHumidity, exCheckZeroList],
    [f'{"I Room Sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"R Room Ice Sensor": <{width}}', [], 8, 1, None, exCheckZeroList],
    # DAT16
    [f'{"R Humidity Sensor (%)": <{width}}', [], 8, 1, sensorToHumidity, exCheckZeroList],
    [f'{"reserved17": <{width}}', [], 8, 3, None, exCheckZeroList],
    # DAT20
    [f'{"Power ON (minutes)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Power ON (seconds)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Initial Freezer Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"Initial Refrigerator Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    # DAT24
    [f'{"Initial CV Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList]
]


class A511_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(sensorValueList)
