
STR_F_DOOR_STATUS = 'F Door Status'
STR_R_DOOR_STATUS = 'R Door Status'

STR_F_ROOM_TEMP = 'F Room Temp'
STR_R_ROOM_TEMP = 'R Room Temp'
STR_F_DEF_TEMP = 'F Def Temp'
STR_R_DEF_TEMP = 'R Def Temp'
STR_AIR_TEMP = 'Ext Temp'

STR_HUMIDITY_STATUS = 'Humidity Status'

STR_AIR_MODE = 'Ext Mode'

STR_SELF_CHECK = 'Self Check'


EEPAdrrDict = {
    'Error Start Day1': [0x41, 'To do'],
    'Error Start Day2': [0x43, 'To do'],
    'Error Start Day3': [0x45, 'To do'],
    'Error Start Day4': [0x47, 'To do'],
    'Error Start Day5': [0x49, 'To do'],
    'Save Error1': [0x50, 'To do'],
    'Save Error2': [0x52, 'To do'],
    'Save Error3': [0x54, 'To do'],
    'Save Error4': [0x56, 'To do'],
    'Save Error5': [0x58, 'To do'],
    'Error Keep Time1': [0x51, 'To do'],
    'Error Keep Time2': [0x53, 'To do'],
    'Error Keep Time3': [0x55, 'To do'],
    'Error Keep Time4': [0x57, 'To do'],
    'Error Keep Time5': [0x59, 'To do'],
    'Deo Filter Time': [0x2C, 'To do'],
    'Convertible Key': [0x48, 'To do'],
    'COMP On Time Hour': [0x60, 'To do'],
    'COMP On Time Minute': [0x62, 'To do'],
    'Case Defrost Time': [0x64, 'To do'],
    'Defrost Case Judge': [0x66, 'To do'],
    'F Defrost': [0x68, 'To do'],
    'Model Option': [0x74, 'To do'],
    'Model Option2': [0x76, 'To do'],
    'Model Option3': [0x78, 'To do'],
    'Model Year Group': [0x70, 'To do'],
    'Model Code': [0x72, 'To do']
}

