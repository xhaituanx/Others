import ctypes
from Common.DataConfig import *
from Parser.OutBug.OutBug_Util import addDataToBuffer, checkWritetable, ClearStructData
from Parser.OutBug.A5_Struct.A504_Struct import A504_FieldStruct, serialNumberWriteList
from Parser.OutBug.A5_Struct.A505_Struct import A505_FieldStruct, serialNumberList
from Parser.OutBug.A5_Struct.A506_Struct import A506_FieldStruct, ONTUpdateVerList
from Parser.OutBug.A5_Struct.A510_Struct import A510_FieldStruct, loadRelayList
from Parser.OutBug.A5_Struct.A511_Struct import A511_FieldStruct, sensorValueList
from Parser.OutBug.A5_Struct.A512_Struct import A512_FieldStruct, otherInputList
from Parser.OutBug.A5_Struct.A513_Struct import A513_FieldStruct, ledList
from Parser.OutBug.A5_Struct.A514_Struct import A514_FieldStruct, switchInputList
from Parser.OutBug.A5_Struct.A515_Struct import A515_FieldStruct, buzzerList
from Parser.OutBug.A5_Struct.A521_Struct import A521_FieldStruct, motorList
from Parser.OutBug.A5_Struct.A530_Struct import A530_FieldStruct, versionOptionList
from Parser.OutBug.A5_Struct.A531_Struct import A531_FieldStruct, pulseList
from Parser.OutBug.A5_Struct.A532_Struct import A532_FieldStruct, fanList
from Parser.OutBug.A5_Struct.A533_Struct import A533_FieldStruct, EEPROMWriteList
from Parser.OutBug.A5_Struct.A534_Struct import A534_FieldStruct, eepromReadList
from Parser.OutBug.A5_Struct.A543_Struct import A543_FieldStruct, valveList
from Parser.OutBug.A5_Struct.A544_Struct import A544_FieldStruct, selfDiagnosisRequestList
from Parser.OutBug.A5_Struct.A561_Struct import A561_FieldStruct, sensorInputRead2List

# A504
def A504_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A504_FieldStruct)
    serNumWParsed = A504_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(serNumWParsed, serialNumberWriteList)

def A504_CheckWrite():
    return checkWritetable(serialNumberWriteList)

def A504_ClearData():
    ClearStructData(serialNumberWriteList)

# A505
def A505_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A505_FieldStruct)
    serNumParsed = A505_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(serNumParsed, serialNumberList)

def A505_CheckWrite():
    return checkWritetable(serialNumberList)

def A505_ClearData():
    ClearStructData(serialNumberList)

# A506
def A506_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A506_FieldStruct)
    otnVerParsed = A506_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(otnVerParsed, ONTUpdateVerList)

def A506_CheckWrite():
    return checkWritetable(ONTUpdateVerList)

def A506_ClearData():
    ClearStructData(ONTUpdateVerList)

# A510
def A510_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A510_FieldStruct)
    relayParsed = A510_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(relayParsed, loadRelayList)

def A510_CheckWrite():
    return checkWritetable(loadRelayList)

def A510_ClearData():
    ClearStructData(loadRelayList)

# A511
def A511_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A511_FieldStruct)
    sensorParsed = A511_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(sensorParsed, sensorValueList)

def A511_CheckWrite():
    return checkWritetable(sensorValueList)

def A511_ClearData():
    ClearStructData(sensorValueList)

# A512
def A512_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A512_FieldStruct)
    otherInputParsed = A512_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(otherInputParsed, otherInputList)

def A512_CheckWrite():
    return checkWritetable(otherInputList)

def A512_ClearData():
    ClearStructData(otherInputList)

# A513
def A513_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A513_FieldStruct)
    ledParsed = A513_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(ledParsed, ledList)

def A513_CheckWrite():
    return checkWritetable(ledList)

def A513_ClearData():
    ClearStructData(ledList)


# A514
def A514_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A514_FieldStruct)
    swinputParsed = A514_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(swinputParsed, switchInputList)

def A514_CheckWrite():
    return checkWritetable(switchInputList)

def A514_ClearData():
    ClearStructData(switchInputList)


# A515
def A515_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A515_FieldStruct)
    buzzerParsed = A515_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(buzzerParsed, buzzerList)

def A515_CheckWrite():
    return checkWritetable(buzzerList)

def A515_ClearData():
    ClearStructData(buzzerList)


# A521
def A521_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A521_FieldStruct)
    motorParsed = A521_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(motorParsed, motorList)

def A521_CheckWrite():
    return checkWritetable(motorList)

def A521_ClearData():
    ClearStructData(motorList)

# A530
def A530_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A530_FieldStruct)
    verParsed = A530_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(verParsed, versionOptionList)

def A530_CheckWrite():
    return checkWritetable(versionOptionList)

def A530_ClearData():
    ClearStructData(versionOptionList)

# A531
def A531_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A531_FieldStruct)
    pulseParsed = A531_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(pulseParsed, pulseList)

def A531_CheckWrite():
    return checkWritetable(pulseList)

def A531_ClearData():
    ClearStructData(pulseList)

# A532
def A532_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A532_FieldStruct)
    fanParsed = A532_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(fanParsed, fanList)

def A532_CheckWrite():
    return checkWritetable(fanList)

def A532_ClearData():
    ClearStructData(fanList)


# A533
def A533_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A533_FieldStruct)
    eepWrParsed = A533_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(eepWrParsed, EEPROMWriteList)

def A533_CheckWrite():
    return checkWritetable(EEPROMWriteList)

def A533_ClearData():
    ClearStructData(EEPROMWriteList)

# A534
def A534_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A534_FieldStruct)
    eepParsed = A534_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(eepParsed, eepromReadList)

def A534_CheckWrite():
    return checkWritetable(eepromReadList)

def A534_ClearData():
    ClearStructData(eepromReadList)


# A543
def A543_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A543_FieldStruct)
    valveParsed = A543_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(valveParsed, valveList)

def A543_CheckWrite():
    return checkWritetable(valveList)

def A543_ClearData():
    ClearStructData(valveList)


# A544
def A544_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A544_FieldStruct)
    selfDiagParsed = A544_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(selfDiagParsed, selfDiagnosisRequestList)

def A544_CheckWrite():
    return checkWritetable(selfDiagnosisRequestList)

def A544_ClearData():
    ClearStructData(selfDiagnosisRequestList)

# A561
def A561_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A561_FieldStruct)
    sensorInputParsed = A561_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(sensorInputParsed, sensorInputRead2List)

def A561_CheckWrite():
    return checkWritetable(sensorInputRead2List)

def A561_ClearData():
    ClearStructData(sensorInputRead2List)


