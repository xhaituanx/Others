from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault, exCheckZeroList

width = 20

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
ledList = [
    #DATA1
    [f'{"Panel Grid1": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel Grid2": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel Grid3": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel Grid4": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel Grid5": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel Grid6": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"reserved1": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved2": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DATA2
    [f'{"Panel DATA1": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA2": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA3": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA4": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA5": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA6": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA7": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Panel DATA8": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    #DATA3
    [f'{"UV Deodorizer LED": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Photosynthesis LED": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Lamp LED": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"F-Lamp LED": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Deodorizer LED": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"M-Lamp LED": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Decoration LED": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"CV-Lamp LED": <{width}}', [], 1, 1, None, exCheckZeroList]
]

class A513_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(ledList)