from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault


A504_SERIAL_NUMBER_LEN = 15

def convertSerialNumber(seNum: list):
    parSeNum = seNum[0]
    try:
        ascii_string = bytes(parSeNum).decode("ASCII")
        # print('Serial Number {}'.format(ascii_string))
        return ascii_string
    except:
        print('Something wrong when convert Serial Number {}'.format(bytes(parSeNum)))
        return 'Unknown'


width = 25
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
serialNumberWriteList = [
    [f'{"Serial Number Write": <{width}}', [], 8, A504_SERIAL_NUMBER_LEN, convertSerialNumber, writeDefault]
]

class A504_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(serialNumberWriteList)
    # _fields_ = [
    #     ('Serial Number Read', c_uint8 * 15),
    # ]
