from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault, exCheckZeroList


width = 25

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
loadRelayList = [
    #DATA1
    [f'{"F Defrost Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"R Defrost Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"CV Defrost Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"CR Defrost Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F Room Lamp": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R Room Lamp": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"C/F Room Lamp": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"CR Room Lamp": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DAT2
    [f'{"Cube Motor": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Auger Motor": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Ice Solenoid Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Ice Maker G-Motor": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Ice Maker Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Ice Route Motor": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Water Tank Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Water Solenoid Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DATA3
    [f'{"Dispenser Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Homebar Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"French Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Ice Solenoid Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Ice Motor(CW)": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Ice Motor(CCW)": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-Ice Maker Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F-Ice Motor(CCW)": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA4
    [f'{"F-FAN": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"C-FAN": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Chammatsil Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Low temperature heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Water Pipe heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R Door Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Show Case Door Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"(2nd) Show Case Door Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA5
    [f'{"DC DISPENSER VALVE": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"AUTO FILL VALVE": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Crystal Ice-Sol Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Crystal Ice Maker Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Safety VALVE": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Pantry Heater1 (Left)": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Pantry Heater2 (Right)": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved5_7": <{width}}', [], 1, 1, None, exCheckZeroList]
]

class A510_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(loadRelayList)