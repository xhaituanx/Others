from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault


width = 20

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
buzzerList = [
    #DATA1
    [f'{"Buzzer": <{width}}', [], 8, 1, onOffStatus, writeDefault]
]

class A515_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(buzzerList)