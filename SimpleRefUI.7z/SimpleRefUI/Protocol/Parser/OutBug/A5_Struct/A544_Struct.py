from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault
from Parser.OutBug.A5_Struct.A5_Common import *

sensorErrList = [
    # DATA1
    'F sensor error, ',
    'R sensor error, ',
    'R(2nd) sensor error, ',
    'F defrost sensor error, ',
    'R defrost sensor error, ',
    'Outside air sensor error, ',
    'Convertible room sensor error, ',
    'F ice maker sensor error, ',
    # DAT2
    'CV sensor error, ',
    'Curd sensor error, ',
    'CV defrost sensor error, ',
    'CR defrost sensor error, ',
    'Humidity sensor error, ',
    'R ice maker sensor error, ',
    'R ice making Room sensor error, ',
    'R Humidity sensor error, ',
    # DAT3
    'F Rotary Switch, ',
    'R Rotary Switch, ',
    'F room abnormal high temperature, ',
    'R room abnormal high temperature, ',
    'CV room abnormal high temperature, ',
    'Crystal ice maker sensor, ',
    'Crystal ice maker function error, ',
    'Crystal Ice maker Ice Pipe Heater Error, ',
    # DAT4
    'F Fan Error, ',
    'R Fan Error, ',
    'C Fan Error, ',
    'F Defrosting Error (High Resistance), ',
    'R Defrosting Error (High Resistance), ',
    'F ice maker function error, ',
    'Damper Heater Error, ',
    'Deodorizer Fan Error, ',
    # DAT5
    'CV defrosting error (high resistance), ',
    'CR Defrosting Error (High Resistance), ',
    'CV-Fan Error, ',
    'Curd Fan Error, ',
    'F Ice-Pipe-Heater Error, ',
    'Water Tank Heater Error, ',
    'F Defrosting Error (low resistance), ',
    'R Defrosting Error (low resistance), ',
    # DAT6
    'CV defrosting error (low resistance), ',
    'CR Defrosting Error (low resistance), ',
    'R ice maker function error, ',
    'Ice Making Room Fan Error, ',
    'R Ice Duct (Drain) heater error, ',
    'Convertible (C,P,M) Fan Error (Pantry1 Fan Error), ',
    'EZ Kit Error, ',
    'Comp Start Failure Error, ',
    # DAT7
    'Comp IPM Fault Error, ',
    'Comp Abnormal Current Detection Error, ',
    'Comp Motor Constraint Error, ',
    'Comp Low Voltage Error, ',
    'Comp overvoltage error, ',
    'Bucket (Room) Heater Error in Ice Making Room, ',
    'Door heater error, ',
    'Sub Damper Heater Error, ',
    # DAT8
    'Panel<->Main Error, ',
    'Main<->Load Error, ',
    'Panel2<->Main Error, ',
    'Carbonated water temperature sensor error, ',
    'Carbonated Water OverFlow Error, ',
    'Carbonated water supply error, ',
    'Carbonated Water CO2 Error, ',
    'AUTO FILL Over Flow Error, ',
    # DAT9
    'R-Comp start failure Error, ',
    'R-Comp IPM Fault Error, ',
    'R-Comp Abnormal Current Detection Error, ',
    'R-Comp motor restraint error, ',
    'R-Comp Low Voltage Error, ',
    'R-Comp overvoltage error, ',
    'Wifi communication UART error, ',
    'LCD OP(Option) Error, ',
    # DAT10
    'Comp Communication Error, ',
    'R-Comp communication error, ',
    'IO Exp. Communication Error, ',
    'F-Hub Wifi Error, ',
    'F-Hub Bluetooth Error, ',
    'F-Hub Mike Error, ',
    'F-Hub proximity sensor error, ',
    'F-Hub camera error, ',
    # DAT11
    'LCD USER mode entry error, ',
    'Camera Error, ',
    'Cabinet Rear Heater Error, ',
    'Illuminance sensor error, ',
    'Curd Heater Error, ',
    'reserved1, ',
    'Showcase heater Error(C79), ',
    '(2nd) Showcase Heater Error(C80), ',
    # DAT12
    'Easy Open Door1 Communication Error, ',
    'Easy Open Door2 Communication Error, ',
    'Easy Open Door3 Communication Error, ',
    'Easy Open Door4 Communication Error, ',
    'Easy Open Door1 Function Error, ',
    'Easy Open Door2 Function Error, ',
    'Easy Open Door3 Function Error, ',
    'Easy Open Door4 Function Error, ',
    # DAT13
    'Comp IPM Shut Down, ',
    'Loss humidity sensor error, ',
    'Humidity sensor error to do, ',
    'Serious room humidity sensor error, ',
    'R Comp IPM Shut Down, ',
    'Pantry 2 Sensor Error (Right Pantry), ',
    'DOC 1 Motor Function Error, ',
    'DOC 2 Motor Function Error, ',
    # DAT14
    'Pantry Fan2 Error, ',
    'Sensor PBA Communication ERROR, ',
    'reserved2_1, ',
    'reserved2_2, ',
    'reserved2_3, ',
    'reserved2_4, ',
    'reserved2_5, ',
    'reserved2_6, ',
    # DAT15
    'Proximity Sensor Mid_LEFT ERROR, ',
    'Proximity Sensor Mid_RIGHT ERROR, ',
    'Left_Left ERROR at the bottom of the proximity sensor, ',
    'Left_Right ERROR at the bottom of the proximity sensor, ',
    'Right_Left ERROR at the bottom of the proximity sensor, ',
    'Right_Right ERROR at the bottom of the proximity sensor, ',
    'Left ADOC Reed SW ERROR, ',
    'Right ADOC Reed SW  ERROR, '
]

def hex_to_binary(hex_number: bytes, num_digits: int = 8) -> str:
    tmpStr = ''
    for i in range(len(hex_number)):
        # tmpStr += str(bin(int(hex_number[i])))[2:].zfill(num_digits)

        # Reverse bit and format 8 bits
        # print(str(bin(int('{:08b}'.format(hex_number[i])[::-1], 2))[2:].zfill(num_digits)))
        tmpStr += str(bin(int('{:08b}'.format(hex_number[i])[::-1], 2))[2:].zfill(num_digits))

    return tmpStr

def checkerror(err: list):
    errval = err[0]
    result = ''
    tmp_val = hex_to_binary(bytes(errval))
    for i in range(len(tmp_val)):
        if tmp_val[i] == '1':
            try:
                result += sensorErrList[i]
            except:
                print("Cannot get sensor name from list at index {}".format(i))

    if len(result) == 0:
        result = 'No Error'

    return result


width = 25
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
selfDiagnosisRequestList = [
    [f'{STR_SELF_CHECK: <{width}}', [], 8, 15, checkerror, writeDefault]
]


class A544_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(selfDiagnosisRequestList)

