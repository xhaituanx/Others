from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList
from Parser.OutBug.A5_Struct.A5_Common import *

externalMode = {
    0: '40℃ <= extmp',
    1: '34℃ <= extmp <= 39℃',
    2: '28℃ <= extmp <= 33℃',
    3: '22℃ <= extmp <= 27℃',
    4: '19℃ <= extmp <= 21℃',
    5: '16℃ <= extmp <= 18℃',
    6: '12℃ <= extmp <= 15℃',
    7: '8℃ <= extmp <= 11℃',
    8: '3℃ <= extmp <= 7℃',
    9: '-2℃ <= extmp <= 2℃',
    10: 'extmp <= -3℃'
}
def getExternalMode(externalmode: list):
    externalmode_val = externalmode[0] - 1
    return externalMode.get(externalmode_val, None)

width = 35
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
sensorInputRead2List = [
    # DATA1
    [f'{"ADO Push Magnetic 1": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA2
    [f'{"ADO Push Magnetic 2": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA3
    [f'{"ADO Push Magnetic 3": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA4
    [f'{"ADO Push Magnetic 4": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA5
    [f'{STR_AIR_MODE: <{width}}', [], 8, 1, getExternalMode, writeDefault],
    # f'{"DATA6
    [f'{"Humidity mode": <{width}}', [], 8, 1, None, writeDefault],
    # f'{"DATA7
    [f'{"R room humidity mode": <{width}}', [], 8, 1, None, writeDefault],
    # f'{"DATA8
    [f'{"Loss humidity sensor upper byte": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA9
    [f'{"Current humidity sensor upper byte": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA10
    [f'{"Backup humidity sensor upper byte": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA11
    [f'{"Loss Hmod": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA12
    [f'{"Current Hmod": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA13
    [f'{"Backup Hmod": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA14
    [f'{"reserved14": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA15
    [f'{"Pantry Room2 Sensor Upper byte": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA16
    [f'{"ADOC proximity sensor Mid_Left": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA17
    [f'{"ADOC proximity sensor Mid_Right": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA18
    [f'{"ADOC Proximity Sensor Left_Left": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA19
    [f'{"ADOC Proximity Sensor Left_Right": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA20
    [f'{"ADOC proximity sensor Right_Left": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA21
    [f'{"ADOC Proximity Sensor Right_Right": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DATA22~24
    [f'{"reserved22": <{width}}', [], 8, 3, None, exCheckZeroList]
]

class A561_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(sensorInputRead2List)

