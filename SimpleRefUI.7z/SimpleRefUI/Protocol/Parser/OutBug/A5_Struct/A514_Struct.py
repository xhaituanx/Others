from Parser.DataStruct import *
from Parser.OutBug.DataConvert import exCheckZeroList, openClosedStatus, onOffStatus, writeDefault
from Parser.OutBug.A5_Struct.A5_Common import *

def detectedStatus(deval: list):
    deval_val = deval[0]
    tmp = int(deval_val)
    if tmp == 1:
        return 'Undetected'
    else:
        return 'Detected'

def pressedStatus(preval: list):
    preval_val = preval[0]
    tmp = int(preval_val)
    if tmp == 1:
        return 'Not pressed'
    else:
        return 'Pressed'

def iceDetectionStatus(iceval: list):
    iceval_val = iceval[0]
    tmp = int(iceval_val)
    if tmp == 1:
        return 'Ice detection position'
    else:
        return 'Initial position'

def horizontalStatus(hor: list):
    hor_val = hor[0]
    tmp = int(hor_val)
    if tmp == 1:
        return 'Horizontal not detected'
    else:
        return 'Horizontal detected'

def horizontalSankyoStatus(horSankyo: list):
    horSankyo_val = horSankyo[0]
    tmp = int(horSankyo_val)
    if tmp == 1:
        return 'Horizontal detected'
    else:
        return 'Horizontal not detected'

def iceFullStatus(icefull: list):
    icefull_val = icefull[0]
    tmp = int(icefull_val)
    if tmp == 1:
        return 'Full Ice'
    else:
        return 'Less Ice'

def carbonatedWaterStatus(carbWater: list):
    carbWater_val = carbWater[0]
    tmp = int(carbWater_val)
    if tmp == 1:
        return 'Water'
    else:
        return 'Carbonated Water'

width = 45
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
switchInputList = [
    # DATA1
    [f'{STR_F_DOOR_STATUS: <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{STR_R_DOOR_STATUS: <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"F H/B Door Switch": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"R H/B Door Switch": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"CV Door Switch": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"C/R Door Switch": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"M Door Switch": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"reserved1": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA2
    [f'{"F I/M Horizontal Switch": <{width}}', [], 1, 1, horizontalStatus, writeDefault],
    [f'{"F I/M Full Switch": <{width}}', [], 1, 1, iceDetectionStatus, writeDefault],
    [f'{"F I/M Test Switch": <{width}}', [], 1, 1, pressedStatus, writeDefault],
    [f'{"I/M Hall IC switch (Sankyo)": <{width}}', [], 1, 1, horizontalSankyoStatus, writeDefault],
    [f'{"R I/M Horizontal switch": <{width}}', [], 1, 1, horizontalStatus, writeDefault],
    [f'{"R I/M full switch": <{width}}', [], 1, 1, iceDetectionStatus, writeDefault],
    [f'{"R I/M test switch": <{width}}', [], 1, 1, pressedStatus, writeDefault],
    [f'{"R I/M Hall IC switch [DC]": <{width}}', [], 1, 1, horizontalStatus, writeDefault],
    # DATA3
    [f'{"Water (Dispenser) Switch": <{width}}', [], 1, 1, pressedStatus, writeDefault],
    [f'{"Ice switch": <{width}}', [], 1, 1, pressedStatus, writeDefault],
    [f'{"Cube Motor Switch": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Route Motor Switch 1": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Route Motor Switch 2": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Bucket Switch": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Full-ice optical sensor": <{width}}', [], 1, 1, iceFullStatus, writeDefault],
    [f'{"A carbonated water/water selection switch": <{width}}', [], 1, 1, carbonatedWaterStatus, writeDefault],
    # DATA4
    [f'{"Dispenser Cubed Key Switch": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Dispenser Crushed Key Switch": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Dispenser Water Key Switch": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Easy Open On/Off Switch": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"reserved4": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Crystal I/M Full Switch": <{width}}', [], 1, 1, iceDetectionStatus, writeDefault],
    [f'{"Crystal I/M Test Switch": <{width}}', [], 1, 1, pressedStatus, writeDefault],
    [f'{"Crystal I/M Hall IC switch": <{width}}', [], 1, 1, horizontalStatus, writeDefault],
    # DATA5
    [f'{"Auto Fill Box Switch": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"Auto Fill Overflow Switch": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"Auto Fill Water Level Detection Switch": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"DOC Motor1 Open Hall": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"DOC Motor1 Close Hall": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"DOC Motor2 Open Hall": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"DOC Motor2 CLose Hall": <{width}}', [], 1, 1, detectedStatus, writeDefault],
    [f'{"reserved5": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA6
    [f'{"R Door Switch (Right)": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"R Door Switch (Right FDSR)": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"R Door Switch (Left)": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"ADOC Left IR Sensor": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"ADOC Right IR Sensor": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"ADOC Open Reed Switch (Left)": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"ADOC Open Reed Switch (Right)": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"reserved6": <{width}}', [], 1, 1, None, exCheckZeroList]
]

class A514_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(switchInputList)

