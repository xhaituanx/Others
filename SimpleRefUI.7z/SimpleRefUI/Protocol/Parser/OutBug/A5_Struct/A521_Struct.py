from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault, exCheckZeroList

width = 45

def wifiState(state:list):
    state_val = state[0]
    tmp = int(state_val)
    if tmp == 1:
        return 'Off'
    else:
        return 'On'

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
motorList = [
    #DATA1
    [f'{"I/M Eject Motor CW": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"I/M Eject Motor CCW": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"EZ Motor CW": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"EZ Motor CCW": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Chammatsil Damper Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F seal feed heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R ice duct (drain) heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Ice room bucket heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DATA2
    [f'{"Step Motor Valve A": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Step Motor Valve A*": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Step Motor Valve B": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Step Motor Valve B*": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Chammatsil Damper Motor A": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Chammatsil Damper Motor B": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R Damper Motor A": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R Damper Motor B": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DATA3
    [f'{"F Damper Motor A": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F Damper Motor B": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"DC ice maker Motor A": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"DC ice maker Motor B": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Handle heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Wifi Module": <{width}}', [], 1, 1, wifiState, writeDefault],
    [f'{"reserved11": <{width}}', [], 2, 1, None, exCheckZeroList],
    # DATA4
    [f'{"F damper heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R damper heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Water Pump": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"ICE Water Pump": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R(2nd) Step Motor Valve A": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R(2nd) Step Motor Valve A*": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R(2nd) Step Motor Valve B": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R(2nd) Step Motor Valve B*": <{width}}', [], 1, 1, None, exCheckZeroList]
]

class A521_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(motorList)