from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault, exCheckZeroList

width = 45

def speedWrite(speed:list):
    speed_val = speed[0]
    tmp = int(speed_val)
    if tmp == 1:
        return '1050'
    elif tmp == 2:
        return '1400'
    elif tmp == 3:
        return '1800'
    elif tmp == 4:
        return '2200'
    elif tmp == 5:
        return '2700'
    elif tmp == 6:
        return '3450'
    elif tmp == 7:
        return '3700'
    elif tmp == 8:
        return '500'
    else:
        return 'not defined'

def compType(typeval:list):
    compType_val = typeval[0]
    tmp = int(compType_val)
    if tmp == 1:
        return 'ENV CU'
    elif tmp == 2:
        return 'ENV AL'
    elif tmp == 3:
        return 'MKV CU'
    elif tmp == 4:
        return 'MKV AL'
    elif tmp == 5:
        return 'MSV4A1 CU'
    elif tmp == 6:
        return 'ENV2 CU'
    elif tmp == 7:
        return 'ENV2 AL'
    elif tmp == 8:
        return 'MSV172 AL'
    elif tmp == 9:
        return 'MSV172 CU'
    elif tmp == 10:
        return 'F3 CU'
    elif tmp == 11:
        return 'MSV2 CU'
    elif tmp == 12:
        return 'F3 AL'
    elif tmp == 13:
        return 'K1 CU'
    elif tmp == 14:
        return 'K1 AL'
    elif tmp == 15:
        return 'M3 CU'
    elif tmp == 16:
        return 'F5 CU'
    elif tmp == 17:
        return 'M3 CU 9CC'
    elif tmp == 18:
        return 'F3 AL LC'
    elif tmp == 19:
        return 'F5 AL'
    elif tmp == 20:
        return 'F5 AL LC'
    elif tmp == 2:
        return 'F5 CU HYBRID'
    elif tmp == 21:
        return 'F5 AL HYBRID'
    elif tmp == 22:
        return 'M3 CU HYBRID'
    elif tmp == 23:
        return 'M3 CU 9CC HYBRID'
    else:
        return 'not defined'

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
pulseList = [
    #DATA1
    [f'{"Inverter Write (RPM)": <{width}}', [], 8, 1, speedWrite, writeDefault],
    #DATA2
    [f'{"reserved1": <{width}}', [], 8, 1, None, exCheckZeroList],
    #DATA3
    [f'{"Inverter Comp Type": <{width}}', [], 8, 1, compType, writeDefault]
]

class A531_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(pulseList)