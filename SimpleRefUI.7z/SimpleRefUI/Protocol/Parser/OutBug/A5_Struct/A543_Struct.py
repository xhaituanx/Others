from Parser.DataStruct import *
from Parser.OutBug.DataConvert import onOffStatus, writeDefault, exCheckZeroList

width = 20

def valeveMove(valve:list):
    valve_val = valve[0]
    tmp = int(valve_val)
    if tmp == 1:
        return 'Origin Position'
    elif tmp == 2:
        return 'Valve R Close, Valve F Close'
    elif tmp == 3:
        return 'Valve R Open, Valve F Close'
    elif tmp == 4:
        return 'Valve R Open, Valve F Open'
    elif tmp == 5:
        return 'Valve R Close, Valve F Open'
    else:
        return "not defined"

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
valveList = [
    #DATA1
    [f'{"Step Valve Move": <{width}}', [], 8, 1, valeveMove, writeDefault],
    [f'{"R Step Valve Move": <{width}}', [], 8, 1, None, exCheckZeroList]
]

class A543_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(valveList)