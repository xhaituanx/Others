import ctypes
from Parser.DataStruct import *
from Parser.OutBug.DataConvert import diodeConvert
from Parser.OutBug.A5_Struct.A5_Common import *


E2P_ADDR_STORED_ERROR1 = 0x50
E2P_ADDR_STORED_ERROR2 = 0x52
E2P_ADDR_STORED_ERROR3 = 0x54
E2P_ADDR_STORED_ERROR4 = 0x56
E2P_ADDR_STORED_ERROR5 = 0x58

E2P_ADDR_ERROR_TIME1 = 0x51
E2P_ADDR_ERROR_TIME2 = 0x53
E2P_ADDR_ERROR_TIME3 = 0x55
E2P_ADDR_ERROR_TIME4 = 0x57
E2P_ADDR_ERROR_TIME5 = 0x59

E2P_ADDR_ERROR_START1 = 0x41
E2P_ADDR_ERROR_START2 = 0x43
E2P_ADDR_ERROR_START3 = 0x45
E2P_ADDR_ERROR_START4 = 0x47
E2P_ADDR_ERROR_START5 = 0x49


def eepromWriteData(eep: list):
    eepval = eep[0]
    tmp_val = bytes(eepval)
    if all([int(tmp_val[0]) == E2P_ADDR_STORED_ERROR1 and int(tmp_val[1]) == 0xFF,
           int(tmp_val[2]) == E2P_ADDR_STORED_ERROR2 and int(tmp_val[3]) == 0xFF,
           int(tmp_val[4]) == E2P_ADDR_STORED_ERROR3 and int(tmp_val[5]) == 0xFF,
           int(tmp_val[6]) == E2P_ADDR_STORED_ERROR4 and int(tmp_val[7]) == 0xFF,
           int(tmp_val[8]) == E2P_ADDR_STORED_ERROR5 and int(tmp_val[9]) == 0xFF]):
        return 'Clear recently 5 errors Code'
    elif all([int(tmp_val[0]) == E2P_ADDR_ERROR_TIME1 and int(tmp_val[1]) == 0xFF,
             int(tmp_val[2]) == E2P_ADDR_ERROR_TIME2 and int(tmp_val[3]) == 0xFF,
             int(tmp_val[4]) == E2P_ADDR_ERROR_TIME3 and int(tmp_val[5]) == 0xFF,
             int(tmp_val[6]) == E2P_ADDR_ERROR_TIME4 and int(tmp_val[7]) == 0xFF,
             int(tmp_val[8]) == E2P_ADDR_ERROR_TIME5 and int(tmp_val[9]) == 0xFF]):
        return 'Clear recently 5 errors time'
    elif all([int(tmp_val[0]) == E2P_ADDR_ERROR_START1 and int(tmp_val[1]) == 0xFF,
             int(tmp_val[2]) == E2P_ADDR_ERROR_START2 and int(tmp_val[3]) == 0xFF,
             int(tmp_val[4]) == E2P_ADDR_ERROR_START3 and int(tmp_val[5]) == 0xFF,
             int(tmp_val[6]) == E2P_ADDR_ERROR_START4 and int(tmp_val[7]) == 0xFF,
             int(tmp_val[8]) == E2P_ADDR_ERROR_START5 and int(tmp_val[9]) == 0xFF]):
        return 'Clear recently 5 errors occurrence date'
    else:
        return 'Unknown'

gEEPAddr = 0x00
gEEPCheckZero = True

def exCheckZeroListEEPAddr(data: list):
    global gEEPCheckZero
    gEEPCheckZero = True
    if isinstance(data[0], int):
        for i in range(len(data)):
            if data[i] != 0:
                gEEPCheckZero = False
                return True
    elif isinstance(data[0], (ctypes.Array, ctypes.c_ubyte)):
        for i in range(len(data)):
            convertedVal = bytes(data[i])
            for j in range(len(convertedVal)):
                if convertedVal[j] != 0:
                    gEEPCheckZero = False
                    return True
    else:
        print('Unknown type {}'.format(type(data[0])))
    return False

def exCheckZeroListEEPData(data: list):
    global gEEPCheckZero
    return not gEEPCheckZero

def convertEEPAddr(addr: list):
    global gEEPAddr
    gEEPAddr = 0x00
    testkey = addr[0]
    gEEPAddr = testkey
    testval = 'Unknown'
    for key, val in EEPAdrrDict.items():
        if val[0] == testkey:
            testval = key
            break

    return str(hex(testkey)) + '(' + testval + ')'

def convertEEPData(data: list):
    global gEEPAddr
    if gEEPAddr == 0x74 or gEEPAddr == 0x76 or gEEPAddr == 0x78:
        if data[0] != 0x00:
            data[0] = data[0] - 0x01

        strdiodeinsert = diodeConvert(data)
        if strdiodeinsert == '':
            return 'No Diode is inserted'
        else:
            return 'Insert Diode: ' + strdiodeinsert
    else:
        return data[0]

width = 25

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
EEPROMWriteList = [
    # DATA1~16
    [f'{"EEP Addr1": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data1": <{width}}', [], 8, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr2": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data2": <{width}}', [], 8, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr3": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data3": <{width}}', [], 8, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr4": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data4": <{width}}', [], 8, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr5": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data5": <{width}}', [], 1, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr6": <{width}}', [], 1, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data6": <{width}}', [], 6, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr7": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data7": <{width}}', [], 8, 1, convertEEPData, exCheckZeroListEEPData],
    [f'{"EEP Addr8": <{width}}', [], 8, 1, convertEEPAddr, exCheckZeroListEEPAddr],
    [f'{"EEP Data8": <{width}}', [], 8, 1, convertEEPData, exCheckZeroListEEPData]
]


class A533_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(EEPROMWriteList)


