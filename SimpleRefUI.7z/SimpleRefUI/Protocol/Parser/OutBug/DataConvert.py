import ctypes
import numpy as np

MAX_TEMP_COUNT = 239
MIN_TEMP_COUNT = 46
MAX_HUM_COUNT = 239
MIN_HUM_COUNT = 30

tempTbl8bit = {
    239: -50,
    238: -49,
    237: -48,
    236: -47,
    235: -46,
    234: -45,
    233: -44,
    232: -43,
    231: -42,
    230: -41,
    229: -40,
    227: -39,
    226: -38,
    225: -37,
    223: -36,
    222: -35,
    220: -34,
    219: -33,
    217: -32,
    216: -31,
    214: -30,
    212: -29,
    210: -28,
    209: -27,
    207: -26,
    205: -25,
    203: -24,
    201: -23,
    199: -22,
    197: -21,
    194: -20,
    192: -19,
    190: -18,
    188: -17,
    185: -16,
    183: -15,
    181: -14,
    178: -13,
    176: -12,
    173: -11,
    171: -10,
    168: -9,
    166: -8,
    163: -7,
    161: -6,
    158: -5,
    155: -4,
    153: -3,
    150: -2,
    148: -1,
    145: 0,
    142: 1,
    140: 2,
    137: 3,
    134: 4,
    132: 5,
    129: 6,
    127: 7,
    124: 8,
    122: 9,
    119: 10,
    117: 11,
    114: 12,
    112: 13,
    109: 14,
    107: 15,
    104: 16,
    102: 17,
    100: 18,
    97: 19,
    95: 20,
    93: 21,
    91: 22,
    89: 23,
    87: 24,
    84: 25,
    82: 26,
    80: 27,
    78: 28,
    77: 29,
    75: 30,
    73: 31,
    71: 32,
    69: 33,
    67: 34,
    66: 35,
    64: 36,
    62: 37,
    61: 38,
    59: 39,
    58: 40,
    56: 41,
    55: 42,
    53: 43,
    52: 44,
    51: 45,
    49: 46,
    48: 47,
    47: 48,
    46: 49,
}

hummidityTbl8bit = {
    46: 0,
    60: 10,
    62: 11,
    78: 23,
    80: 24,
    96: 36,
    98: 37,
    114: 49,
    116: 50,
    128: 59,
    130: 60,
    134: 64,
    136: 65,
    141: 69,
    143: 70,
    153: 76,
    155: 77,
    158: 81,
    160: 82,
    162: 84,
    164: 85,
    169: 89,
    171: 90,
    176: 94,
    178: 95,
    185: 100
}

def sensorToTemp(adc_count: list):
    temp = 999
    adc_val = adc_count[0]
    if isinstance(adc_val, int):
        if adc_val >= MAX_TEMP_COUNT or adc_val < MIN_TEMP_COUNT:
            if adc_val == 0:
                return f'N/A'
            return f'Sensor Error'
        else:
            array = np.asarray(list(tempTbl8bit.keys()))
            idx = (np.abs(array - adc_val)).argmin()
            # print(array)
            # print(idx)
            # print(tempTbl[array[idx]])
            if adc_val == array[idx]:
                temp = tempTbl8bit[array[idx]]
            elif adc_val < array[idx]:
                temp = tempTbl8bit[array[idx]] + (array[idx] - adc_val) / (array[idx] - array[idx + 1])
            else:
                temp = tempTbl8bit[array[idx]] + (array[idx] - adc_val) / (array[idx - 1] - array[idx])
            # temp = float(-0.0000152*adc_count*adc_count*adc_count +
            #              0.00636*adc_count*adc_count + 1.25*adc_count + 94.2)  #AT502 Themistor polynomial trendline
    else:
        print("Unknown val type {}".format(type(adc_val)))
    return round(float(temp), 2)  # reduced to 2nd decimal place


def sensorToHumidity(adc_count):
    temp = 999
    adc_val = adc_count[0]
    if isinstance(adc_val, int):
        if adc_val >= MAX_HUM_COUNT or adc_val < MIN_HUM_COUNT:
            if adc_val == 0:
                return f'N/A'
            return f'Humidity Sensor Error'
        else:
            temp = adc_val
            # array = np.asarray(list(hummidityTbl8bit.keys()))
            # idx = (np.abs(array - adc_val)).argmin()
            # if adc_val == array[idx]:
            #     temp = hummidityTbl8bit[array[idx]]
            # elif adc_val < array[idx]:
            #     temp = hummidityTbl8bit[array[idx]] + (array[idx] - adc_val) / (array[idx] - array[idx + 1])
            # else:
            #     temp = hummidityTbl8bit[array[idx]] + (array[idx] - adc_val) / (array[idx - 1] - array[idx])
    else:
        print("Unknown val type {}".format(type(adc_val)))
    return round(float(temp), 2)  # reduced to 2nd decimal place


def exCheckZeroList(data: list):
    if isinstance(data[0], int):
        for i in range(len(data)):
            if data[i] != 0:
                return True
    elif isinstance(data[0], (ctypes.Array, ctypes.c_ubyte)):
        for i in range(len(data)):
            convertedVal = bytes(data[i])
            for j in range(len(convertedVal)):
                if convertedVal[j] != 0:
                    return True
    else:
        print('Unknown type {}'.format(type(data[0])))
    return False

def writeDefault(data: list):
    return True

def convertDectoHex(ldata: list):
    ftval = ldata[0]
    try:
        return hex(ftval)
    except:
        return ''


def disYesNo(yn: list):
    yn_val = yn[0]
    tmp = int(yn_val)
    if tmp == 1:
        return 'Yes'
    else:
        return 'No'

def onOffStatus(onoff: list):
    onoff_val = onoff[0]
    tmp = int(onoff_val)
    if tmp == 1:
        return 'On'
    else:
        return 'Off'


def openClosedStatus(openclose: list):
    openclose_val = openclose[0]
    tmp = int(openclose_val)
    if tmp == 1:
        return 'Open'
    else:
        return 'Closed'

def settingRelease(stre: list):
    stre_val = stre[0]
    tmp = int(stre_val)
    if tmp == 1:
        return 'Setting'
    elif tmp == 2:
        return 'Release'
    else:
        return 'Unknown {}'.format(tmp)

def readwrite(rwt: list):
    rwt_val = rwt[0]
    if rwt_val == 0x11:
        return 'Read'
    elif rwt_val == 0x88:
        return 'Write'
    else:
        return 'Unknown {}'.format(rwt_val)


def diodeConvert(diode: list):
    dio_str = ''
    diode_val = diode[0]
    list_diode = list(bin(diode_val).replace("0b", ""))
    list_diode.reverse()

    for count, value in enumerate(list_diode, start=1):
        if value == '1':
            dio_str += 'D60' + str(count) + ' '
    return dio_str
