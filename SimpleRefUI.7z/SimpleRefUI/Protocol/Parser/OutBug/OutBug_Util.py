from Common.DataConfig import *

def addDataToBuffer(dataparse_list, field_list):
    for i in range(0, len(field_list)):
        # Get name from list
        name = field_list[i][NAME_IND_STR_LIST]
        # Get value from package based on name
        valFrom = getattr(dataparse_list, name)
        # Add data to list buffer
        field_list[i][VAL_IND_STR_LIST].append(valFrom)

def checkWritetable(field_list) -> dict:
    des_dict = {}
    if len(field_list[0][VAL_IND_STR_LIST]) == 0:  # No data
        return
    for i in range(0, len(field_list)):
        # If existing function to check excel item writetable
        if field_list[i][CHECK_WRITE_LIST]:
            # Execute checkWriteFunc and assign value back to defaultExcelWrite
            if field_list[i][CHECK_WRITE_LIST](field_list[i][VAL_IND_STR_LIST]):
                # If converfunc is existing
                if field_list[i][DATA_CONVERT_FUNC_LIST]:
                    des_dict[field_list[i][NAME_IND_STR_LIST]] = field_list[i][DATA_CONVERT_FUNC_LIST](field_list[i][VAL_IND_STR_LIST])
                else:
                    des_dict[field_list[i][NAME_IND_STR_LIST]] = field_list[i][VAL_IND_STR_LIST]

    return des_dict

def ClearStructData(field_list):
    if len(field_list[0][VAL_IND_STR_LIST]) == 0:  # No data
        return
    for i in range(0, len(field_list)):
        field_list[i][VAL_IND_STR_LIST].clear()

