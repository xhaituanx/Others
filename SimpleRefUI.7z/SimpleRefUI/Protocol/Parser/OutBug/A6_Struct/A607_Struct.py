from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList

def readMByte(Mbyte: list):
    Mbyte_val = Mbyte[0]
    return int.from_bytes(Mbyte_val, "big")

width = 10

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
freeServiceList = [
    # DAT1~2
    [f'{"Usage date ": <{width}}', [], 8, 2, readMByte, writeDefault],
    # DAT3~24
    [f'{"Reserved": <{width}}', [], 8, 22, None, exCheckZeroList]
]


class A607_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(freeServiceList)


