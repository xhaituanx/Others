from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList, disYesNo, onOffStatus
from Parser.OutBug.A6_Struct.A623_Struct import retInt

def fanDuty(duty: list):
    duty_val = duty[0]
    tmp = int(duty_val)
    if tmp == 0:
        return 'No Fan'
    else:
        return tmp

def iceCondition(cond: list):
    cond_val = cond[0]
    tmp = int(cond_val)
    if tmp == 0:
        return 'Off'
    elif tmp == 1:
        return '24 hour'
    elif tmp == 2:
        return '12 hour'
    else:
        return '8 hour'
    
def levInfor(lev: list):
    lev_val = lev[0]
    tmp = int(lev_val)
    if tmp == 1:
        return 'Full'
    else:
        return 'Not Full'

width = 60
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
fanOperationInfor1List = [
    # DAT1
    [f'{"Save Temp Transmit Hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT2
    [f'{"F Fan Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    # DAT3
    [f'{"R Fan Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    # DAT4
    [f'{"C Fan Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    # DAT5
    [f'{"P1-FAN Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    # DAT6
    [f'{"I1-FAN Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    #DAT7
    [f'{"C-FAN Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    #DAT18
    [f'{"P2-FAN Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    #DAT9
    [f'{"I2-FAN Duty (%)": <{width}}', [], 8, 1, fanDuty, writeDefault],
    #DAT10~15
    [f'{"Reserved10~15": <{width}}', [], 8, 6, None, exCheckZeroList],
    #DAT16
    [f'{"IceBall 1 Heater Duty": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT17
    [f'{"IceBall 2 Heater Duty": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT18
    [f'{"Ice Ball Apply": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Ice making selection conditions": <{width}}', [], 2, 1, iceCondition, writeDefault],
    [f'{"Number of flow sensor water supply errors for 1 hour": <{width}}', [], 2, 1, retInt, writeDefault],
    [f'{"Emergency diving mode occurs for 1 hour": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Reserved18_6~7": <{width}}', [], 2, 1, None, exCheckZeroList],
    #DAT19
    [f'{"Number of errors during Tray Open for 1h": <{width}}', [], 4, 1, retInt, writeDefault],
    [f'{"Number of errors during Tray Close for 1h": <{width}}', [], 4, 1, retInt, writeDefault],
    #DAT20
    [f'{"Ice making sensor temperature at the end of heating mode": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT21
    [f'{"Auto Fill application model": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Auto Fill Bottle status": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Auto Fill Level Information": <{width}}', [], 1, 1, levInfor, writeDefault],
    [f'{"Reserved21_3": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Number of Auto Fill Bottle uses (accumulated within 1 hour)": <{width}}', [], 4, 1, retInt, writeDefault],
    #DAT22
    [f'{"Auto Fill Valve operation time (accumulated within 1 hour)": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT23~24
    [f'{"Reserved23~24": <{width}}', [], 8, 2, None, exCheckZeroList]
]


class A624_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(fanOperationInfor1List)