from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList

width = 45
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
serviceOpReadList = [
    # DAT1
    [f'{"F room temperature shift": <{width}}', [], 4, 1, None, writeDefault],  # Option 0
    [f'{"R room temperature shift": <{width}}', [], 4, 1, None, writeDefault],  # Option 1
    # f'{"DAT2
    [f'{"Ice Tray Water Amount": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Ice Maker Water Time": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT3
    [f'{"Ice Maker Eject Time": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"F Room Hysteresis": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT4
    [f'{"F Room NC Gap": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"F Room NW Gap": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT5
    [f'{"R Room NC Gap": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"R Room NW Gap": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT6
    [f'{"R Room Hysteresis": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Open Air temperature shift": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT7
    [f'{"Iso Case3 Defrost Time": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"R Defrost Come Back temperature": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT8
    [f'{"F Defrost Come Back temperature": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"R Room Comp Off Cycle": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT9
    [f'{"Display Option": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Defrost After Service": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT10
    [f'{"Check Fan Restriction": <{width}}', [], 4, 1, None, writeDefault],  # Option 18
    [f'{"Dispenser Heater": <{width}}', [], 4, 1, None, writeDefault],  # Option 19
    # f'{"DAT11
    [f'{"C Room temperature Shift": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"C Room Hysteresis": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT12
    [f'{"Idle Time": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Control Bldc Fan High/Low": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT13
    [f'{"Deodorizer Fan": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"C Room Thaw Temp Shift": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT14
    [f'{"R Initial Off": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Comp RPM": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT15
    [f'{"F Fan Force": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"R Fan Force": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT16
    [f'{"C Fan Force": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Internal Humidity": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT17
    [f'{"Door Open Fan": <{width}}', [], 4, 1, None, writeDefault],
    [f'{"Shut Off Valve": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT18
    [f'{"reserved18_1": <{width}}', [], 4, 1, None, exCheckZeroList],
    [f'{"reserved18_2": <{width}}', [], 4, 1, None, exCheckZeroList],
    # f'{"DAT19
    [f'{"reserved19": <{width}}', [], 4, 1, None, exCheckZeroList],
    [f'{"InverterComp. RPM Step 1 Up": <{width}}', [], 4, 1, None, writeDefault],  # Option 37
    # f'{"DAT20
    [f'{"CV room temperature shift": <{width}}', [], 4, 1, None, writeDefault],  # Option 38
    [f'{"F/CV room natural defrosting time fixed": <{width}}', [], 4, 1, None, writeDefault]  # Option 39
]


class A606_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(serviceOpReadList)

