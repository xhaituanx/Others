from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList
from Parser.OutBug.A6_Struct.A623_Struct import retInt

def ReadRPM(RPM: list):
    RPM_val = RPM[0]
    return int.from_bytes(RPM_val, "big")

width = 55
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
fanOperationInfor2List = [
    # DAT1
    [f'{"Save Temp Transmit Hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT2~3
    [f'{"F Fan RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    # DAT4~5
    [f'{"R Fan RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    # DAT6~7
    [f'{"CV Fan RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    # DAT8~9
    [f'{"P1-FAN RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    # DAT10~11
    [f'{"I1-FAN RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    #DAT12~13
    [f'{"C-FAN RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    #DAT14~15
    [f'{"P2-FAN RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    #DAT16~17
    [f'{"I2-FAN RPM": <{width}}', [], 8, 2, ReadRPM, writeDefault],
    #DAT18~24
    [f'{"Reserved": <{width}}', [], 8, 7, None, exCheckZeroList]
]


class A625_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(fanOperationInfor2List)