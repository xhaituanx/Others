from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault

width = 35
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
serOpReadList = [
    [f'{"Service Option Read": <{width}}', [], 8, 20, None, writeDefault]
]


class A622_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(serOpReadList)


