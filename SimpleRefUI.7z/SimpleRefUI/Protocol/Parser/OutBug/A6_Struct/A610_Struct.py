from Parser.DataStruct import *
from Parser.OutBug.DataConvert import disYesNo, exCheckZeroList

width = 45
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
underControlReadList = [
    # DAT1
    [f'{"F Defrost Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R Defrost Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"C/F(C/V) Defrost Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"C/R Defrost Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved1": <{width}}', [], 4, 1, None, exCheckZeroList],
    #f'{"DAT2
    [f'{"Cube Motor": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Auger Motor": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Ice Solenoid Valve": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Ice Maker G-Motor": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Ice Maker Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Ice Route Motor": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Water Tank Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Water Solenoid Valve": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT3
    [f'{"Dispenser Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Homebar Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"French heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R-Ice Solenoid Valve": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved3_4": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Show Case Door Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R-Ice Maker Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved3_7": <{width}}', [], 1, 1, None, exCheckZeroList],
    #f'{"DAT4
    [f'{"reserved4": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"Pantry Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Low temperature compensating heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Water Pipe heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Door Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Show Case Door Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"(2nd) Show Case Door Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT5~6
    [f'{"reserved5": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"reserved6": <{width}}', [], 8, 1, None, exCheckZeroList],
    #f'{"DAT7
    [f'{"Panel Grid1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid2": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid3": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid4": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid5": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid6": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"F-H/L": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R=H/L": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],

    #f'{"DAT8
    [f'{"Panel DATA1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel DATA2": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel DATA3": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel DATA4": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel DATA5": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel DATA6": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid7": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Panel Grid8": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],

    #f'{"DAT9
    [f'{"UV Deodorizer LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Photosynthesis LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R-Lamp LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"F-Lamp LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Deodorizer LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"M-Lamp LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Decoration LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"CV-Lamp LED": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT10
    [f'{"DISPENSER PANEL LED1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"DISPENSER PANEL LED2": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"DISPENSER PANEL LED3": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"DISPENSER PANEL LED4": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"DISPENSER PANEL LED5": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Display Driver IC Enable": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"ADOC Welcome LED(Left)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"ADOC Welcome LED(Right)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT11
    [f'{"Service option 0 (F room temperature shift)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Service option 1 (R room temperature shift)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Service Option 19 (Sub Heater Operation Rate)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Service option 38 (CV room temperature shift)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Service Option 37 (InverterComp.RPM Up)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Service option 39 (F/CV natural defrost time fix)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved11": <{width}}', [], 2, 1, None, exCheckZeroList],
    #f'{"DAT12
    [f'{"reserved12": <{width}}', [], 4, 1, None, exCheckZeroList],
    [f'{"Pantry Damper Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"F seal feed heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R seal ice duct (drain) heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Ice making chamber bucket (Room) heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT13
    [f'{"reserved13": <{width}}', [], 8, 1, None, exCheckZeroList],
    #f'{"DAT14
    [f'{"reserved14": <{width}}', [], 5, 1, None, exCheckZeroList],
    [f'{"Wifi Module On/Off": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Water DC Valve (Non-Plumbing)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Ice Water Pump (Non-Plumbing)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT15
    [f'{"F room damper heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R seal damper heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Water Pump": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"ICE Water Pump": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"DOC1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"DOC2": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved15_67": <{width}}', [], 2, 1, None, exCheckZeroList],
    #f'{"DAT16
    [f'{"reserved16": <{width}}', [], 3, 1, None, exCheckZeroList],
    [f'{"Curd heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Handle heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Crystal ice pipe heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Cabinet Rear Heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"CV chamber damper heater": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT17
    [f'{"F-Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved17_1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R-Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved17_3": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"C-Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved17_5": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"I-Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved17_7": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT18
    [f'{"C/V Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"C/R Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"BOX Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"SPI-2 / Clean Deodorizer Power (Fan)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Mid Drawer Room Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"P-Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Curd-Fan": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved18": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    #f'{"DAT19
    [f'{"P-Fan 2 (Right Pantry Fan)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved19": <{width}}', [], 7, 1, None, exCheckZeroList],
    #f'{"DAT20
    [f'{"Easy Open operation": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved20": <{width}}', [], 7, 1, None, exCheckZeroList],
    #f'{"DAT21
    [f'{"Pantry DAMPER": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R DAMPER": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"F DAMPER": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"AIR JET Damper": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"R Damper (angle control)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"CV Damper": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"CV Damper (angle control)": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved21": <{width}}', [], 1, 1, None, exCheckZeroList],
    #f'{"DAT22
    [f'{"Forced start 1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Forced start 2": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Forced start 3": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Forced start 4": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Forced start 5": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved22": <{width}}', [], 3, 1, None, exCheckZeroList],

    #f'{"DAT23
    [f'{"Forced defrosting 1": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Forced defrosting 2": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"Forced defrosting 3": <{width}}', [], 1, 1, disYesNo, exCheckZeroList],
    [f'{"reserved23": <{width}}', [], 5, 1, None, exCheckZeroList]
]


class A610_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(underControlReadList)

