import ctypes
from Common.DataConfig import *
from Parser.OutBug.OutBug_Util import addDataToBuffer, checkWritetable, ClearStructData
from Parser.OutBug.A6_Struct.A601_Struct import A601_FieldStruct, forceStartModeList
from Parser.OutBug.A6_Struct.A602_Struct import A602_FieldStruct, loadDisplayModeList
from Parser.OutBug.A6_Struct.A603_Struct import A603_FieldStruct, Recent5ErrorsList
from Parser.OutBug.A6_Struct.A605_Struct import A605_FieldStruct, serviceOpList
from Parser.OutBug.A6_Struct.A606_Struct import A606_FieldStruct, serviceOpReadList
from Parser.OutBug.A6_Struct.A607_Struct import A607_FieldStruct, freeServiceList
from Parser.OutBug.A6_Struct.A608_Struct import A608_FieldStruct, mainOperationList
from Parser.OutBug.A6_Struct.A610_Struct import A610_FieldStruct, underControlReadList
from Parser.OutBug.A6_Struct.A611_Struct import A611_FieldStruct, monitorLoadReadList
from Parser.OutBug.A6_Struct.A612_Struct import A612_FieldStruct, compRPMReadList
from Parser.OutBug.A6_Struct.A613_Struct import A613_FieldStruct, modelOptionList
from Parser.OutBug.A6_Struct.A620_Struct import A620_FieldStruct, dfcTempList
from Parser.OutBug.A6_Struct.A621_Struct import A621_FieldStruct, serOpWriteList
from Parser.OutBug.A6_Struct.A622_Struct import A622_FieldStruct, serOpReadList
from Parser.OutBug.A6_Struct.A623_Struct import A623_FieldStruct, compOperationInforList
from Parser.OutBug.A6_Struct.A624_Struct import A624_FieldStruct, fanOperationInfor1List
from Parser.OutBug.A6_Struct.A625_Struct import A625_FieldStruct, fanOperationInfor2List

# A601
def A601_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A601_FieldStruct)
    forceParsed = A601_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(forceParsed, forceStartModeList)

def A601_CheckWrite():
    return checkWritetable(forceStartModeList)

def A601_ClearData():
    ClearStructData(forceStartModeList)

# A602
def A602_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A602_FieldStruct)
    loadDispParsed = A602_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(loadDispParsed, loadDisplayModeList)

def A602_CheckWrite():
    return checkWritetable(loadDisplayModeList)

def A602_ClearData():
    ClearStructData(loadDisplayModeList)

# A603
def A603_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A603_FieldStruct)
    errParsed = A603_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(errParsed, Recent5ErrorsList)

def A603_CheckWrite():
    return checkWritetable(Recent5ErrorsList)

def A603_ClearData():
    ClearStructData(Recent5ErrorsList)


# A605
def A605_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A605_FieldStruct)
    serParsed = A605_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(serParsed, serviceOpList)

def A605_CheckWrite():
    return checkWritetable(serviceOpList)

def A605_ClearData():
    ClearStructData(serviceOpList)



# A606
def A606_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A606_FieldStruct)
    serOpParsed = A606_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(serOpParsed, serviceOpReadList)

def A606_CheckWrite():
    return checkWritetable(serviceOpReadList)

def A606_ClearData():
    ClearStructData(serviceOpReadList)

# A607
def A607_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A607_FieldStruct)
    freeSerParsed = A607_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(freeSerParsed, freeServiceList)

def A607_CheckWrite():
    return checkWritetable(freeServiceList)

def A607_ClearData():
    ClearStructData(freeServiceList)

# A608
def A608_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A608_FieldStruct)
    mainOpParsed = A608_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(mainOpParsed, mainOperationList)

def A608_CheckWrite():
    return checkWritetable(mainOperationList)

def A608_ClearData():
    ClearStructData(mainOperationList)


# A610
def A610_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A610_FieldStruct)
    underControlParsed = A610_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(underControlParsed, underControlReadList)

def A610_CheckWrite():
    return checkWritetable(underControlReadList)

def A610_ClearData():
    ClearStructData(underControlReadList)


# A611
def A611_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A611_FieldStruct)
    loadParsed = A611_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(loadParsed, monitorLoadReadList)

def A611_CheckWrite():
    return checkWritetable(monitorLoadReadList)

def A611_ClearData():
    ClearStructData(monitorLoadReadList)

# A612
def A612_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A612_FieldStruct)
    compParsed = A612_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(compParsed, compRPMReadList)

def A612_CheckWrite():
    return checkWritetable(compRPMReadList)

def A612_ClearData():
    ClearStructData(compRPMReadList)

# A613
def A613_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A613_FieldStruct)
    modelParsed = A613_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(modelParsed, modelOptionList)

def A613_CheckWrite():
    return checkWritetable(modelOptionList)

def A613_ClearData():
    ClearStructData(modelOptionList)

# A620
def A620_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A620_FieldStruct)
    dfcParsed = A620_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(dfcParsed, dfcTempList)

def A620_CheckWrite():
    return checkWritetable(dfcTempList)

def A620_ClearData():
    ClearStructData(dfcTempList)


# A621
def A621_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A621_FieldStruct)
    serOpWrParsed = A621_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(serOpWrParsed, serOpWriteList)

def A621_CheckWrite():
    return checkWritetable(serOpWriteList)

def A621_ClearData():
    ClearStructData(serOpWriteList)

# A622
def A622_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A622_FieldStruct)
    serOpReParsed = A622_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(serOpReParsed, serOpReadList)

def A622_CheckWrite():
    return checkWritetable(serOpReadList)

def A622_ClearData():
    ClearStructData(serOpReadList)

#A623
def A623_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A623_FieldStruct)
    compInforParsed = A623_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(compInforParsed, compOperationInforList)

def A623_CheckWrite():
    return checkWritetable(compOperationInforList)

def A623_ClearData():
    ClearStructData(compOperationInforList)

#A624
def A624_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A624_FieldStruct)
    fanInfor1Parsed = A624_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(fanInfor1Parsed, fanOperationInfor1List)

def A624_CheckWrite():
    return checkWritetable(fanOperationInfor1List)

def A624_ClearData():
    ClearStructData(fanOperationInfor1List)

#A625
def A625_WriteBuffer(bArrData: bytearray):
    bStart = DATA_BASE_ADDR
    bEnd = bStart + ctypes.sizeof(A625_FieldStruct)
    fanInfor2Parsed = A625_FieldStruct.from_buffer_copy(bArrData[bStart: bEnd])
    addDataToBuffer(fanInfor2Parsed, fanOperationInfor2List)

def A625_CheckWrite():
    return checkWritetable(fanOperationInfor2List)

def A625_ClearData():
    ClearStructData(fanOperationInfor2List)