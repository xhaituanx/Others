from Parser.DataStruct import *
from Parser.OutBug.DataConvert import *
from Parser.OutBug.A6_Struct.A6_Common import *

def checkFan(fan: list):
    fan_val = fan[0]
    tmp = int(fan_val)
    if tmp == 1:
        return 'High'
    elif tmp == 2:
        return 'Low'
    elif tmp == 3:
        return 'Highest'
    else:
        return 'Off'

def exhibitionmode(exhi: list):
    exhi_val = exhi[0]
    tmp = int(exhi_val)
    if tmp == 1:
        return 'Exhibition Mode'
    else:
        return 'Not in Exhibition Mode'

width = 55
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
loadDisplayModeList = [
    # DAT1
    [f'{STR_R_FAN_STATUS: <{width}}', [], 2, 1, checkFan, writeDefault],
    # ('R-fan Low', [], 1, 1, None, excelWriteDefault],
    [f'{STR_R_DEF_HEATER: <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"R Comp": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Outside air temperature above 34 degrees Celsius": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Outside air temperature below 21 degrees Celsius": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Display mode": <{width}}', [], 1, 1, exhibitionmode, writeDefault],
    [f'{"P-FAN2 (Right Pantry Fan)": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    # DAT2
    [f'{"P-FAN (Left Pantry Fan)": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Night ice making stop mode": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Maker Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Full ice": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Twin ice maker-F full ice": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"F Pipe Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Water Tank Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"CV Damper": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    # DAT3
    [f'{"F Comp": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{STR_F_FAN_STATUS: <{width}}', [], 2, 1, checkFan, writeDefault],
    # ('F-fan Low', [], 1, 1, None, excelWriteDefault],
    [f'{STR_F_DEF_HEATER: <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{STR_C_FAN_STATUS: <{width}}', [], 2, 1, checkFan, writeDefault],
    # ('C-fan Low', [], 1, 1, None, excelWriteDefault],
    [f'{"Dispenser Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"HomeBar Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    # DAT4
    [f'{"CV-Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"F-Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"R-Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"I-Fan High": <{width}}', [], 2, 1, checkFan, writeDefault],
    # ['I-fan Low', [], 1, 1, None, excelWriteDefault],
    [f'{"Differential pressure (R)-Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"French Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"R-Damper": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    # DAT5
    [f'{"CV-Fan": <{width}}', [], 2, 1, checkFan, writeDefault],
    # ('CV-fan Low', [], 1, 1, None, excelWriteDefault],
    [f'{"CV defrost heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Pantry Damper": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"Pantry Fan": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Show Case Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Door Side Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"(2nd) Show Case Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    # DAT6
    [f'{"Water To Dispenser": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Carbonated Water To Dispenser": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Water To Tank": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"CO2 Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Vent Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"DC Water Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Auto Fill Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"CO2 Motor": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DAT7
    [f'{"Crystal Ice Maker Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Crystal Twin Ice maker-F Manbing": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Crystal F Pipe Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F-cooled-Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Cabinet Rear Heater": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R-cooled-Valve": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"R Damper Angle Control": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"CV Damper Angle Control": <{width}}', [], 1, 1, None, exCheckZeroList],
    #DAT8
    [f'{"Ice Room Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Drain Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Wifi Module On": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"R Damper Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"CV Damper Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"P Damper Heater": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Pantry Heater 1": <{width}}', [], 1, 1, onOffStatus, exCheckZeroList],
    [f'{"Pantry Heater 2": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    # DAT9
    [f'{STR_F_DOOR_LAMP: <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{STR_R_DOOR_LAMP: <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"CV-Room Lamp": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"reserved9_3": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Deodorizer (SPI)": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"reserved9_5": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved9_6": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved9_7": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DAT10
    [f'{"reserved10": <{width}}', [], 8, 1, None, exCheckZeroList]
]


class A602_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(loadDisplayModeList)


