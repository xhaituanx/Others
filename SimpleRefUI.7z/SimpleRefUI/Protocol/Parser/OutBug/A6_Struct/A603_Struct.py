from Parser.DataStruct import *
from Parser.OutBug.DataConvert import *

errorcodelist = {
    0: 'No error',
    1: 'Freezer sensor error',
    2: 'Refrigerator sensor 1 error',
    3: 'Refrigerator sensor 2 error',
    4: 'Freezer defrost sensor error',
    5: 'Refrigerating chamber defrosting sensor error',
    6: 'Outside air sensor error',
    7: 'Convertible sensor error',
    8: 'Ice making sensor error',
    9: 'CV room sensor error',
    10: 'Curd sensor error',
    13: 'Humidity sensor error',
    16: 'Refrigerator Humidity Sensor Error',
    21: 'Freezer fan error',
    22: 'Refrigerator fan error',
    23: 'C-Fan error',
    24: 'Freezer defrosting heater error',
    25: 'Refrigerating chamber defrosting heater error',
    26: 'Ice maker function error',
    27: 'R damper heater error',
    28: 'Deodorizer fan error',
    29: 'Geared motor error',
    33: 'General ice maker Ice Pipe Heater error',
    34: 'Water Tank Heater Error',
    35: 'F room defrost sensor low resistance error',
    36: 'R room defrost sensor low resistance error',
    38: 'Curd Fan error',
    41: 'Panel communication error',
    44: 'Comp communication error',
    46: 'IO Expander error',
    47: 'Main <-> 2nd Panel Communication error',
    63: 'FlexZone damper heater error',
    71: 'F abnormal sensor error',
    72: 'R abnormal sensor error',
    73: 'Flex / CV room / M room abnormal high temperature',
    81: 'Comp start failure error',
    82: 'Comp IPM Fault Error',
    83: 'Comp Abnormal Current Detection Error',
    84: 'Comp motor restraint error',
    85: 'Comp low voltage error',
    86: 'Comp overvoltage error',
    96: 'LOAD_ERROR_COMP_IPM_SHUT_DOWN',
    102: 'Curd Heater error'
}

def convertErrortoStr(err: list):
    err_val = err[0]
    tmp = int(err_val)
    if tmp in errorcodelist:
        return errorcodelist.get(tmp)
    else:
        print('Unknown error id {}'.format(tmp))
        return 'Unknown'

def converttoDec(hex: list):
    hex_val = hex[0]
    try:
        tmp_val = bytes(hex_val).hex()
        return str(int(tmp_val[0:2], 16)) + '-' + str(int(tmp_val[2:4], 16)) + '-' + str(int(tmp_val[4:6], 16)) + '-' + str(
            int(tmp_val[6:8], 16)) + '-' + str(int(tmp_val[8:], 16))
    except:
        print('Something wrong when convert to Decimal')
        return ''

width = 35
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
Recent5ErrorsList = [
    [f'{"LastErr5Data1": <{width}}', [], 8, 1, convertErrortoStr, writeDefault],
    [f'{"LastErr5Data2": <{width}}', [], 8, 1, convertErrortoStr, writeDefault],
    [f'{"LastErr5Data3": <{width}}', [], 8, 1, convertErrortoStr, writeDefault],
    [f'{"LastErr5Data4": <{width}}', [], 8, 1, convertErrortoStr, writeDefault],
    [f'{"LastErr5Data5": <{width}}', [], 8, 1, convertErrortoStr, writeDefault],
    [f'{"ERROR maintenance time (minutes)": <{width}}', [], 8, 5, converttoDec, writeDefault],
    [f'{"ERROR occurrence date (day)": <{width}}', [], 8, 5, converttoDec, writeDefault]
]


class A603_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(Recent5ErrorsList)

