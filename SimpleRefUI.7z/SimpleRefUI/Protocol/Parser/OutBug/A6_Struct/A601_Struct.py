from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList

def forceMode(mode: list):
    mode_val = mode[0]
    tmp = int(mode_val)
    if tmp == 0:
        return 'Release Forced Start Mode'
    elif tmp == 1:
        return 'Forced Start 1'
    elif tmp == 2:
        return 'Forced Start 2'
    elif tmp == 3:
        return 'Forced Start 3'
    elif tmp == 4:
        return 'Forced Start 4'
    elif tmp == 5:
        return 'Forced Start 5'
    elif tmp == 0xF1:
        return 'Forced Defrost 1'
    elif tmp == 0xF2:
        return 'Forced Defrost 2'
    else:
        return 'Unknown command'
width = 20
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
forceStartModeList = [
    # DAT1
    [f'{"Forced Start Mode ": <{width}}', [], 8, 1, forceMode, writeDefault],
    # DAT2~24
    [f'{"Reserve": <{width}}', [], 8, 23, None, exCheckZeroList]
]


class A601_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(forceStartModeList)