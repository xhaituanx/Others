STR_C_FAN_STATUS = 'C Fan Status'
STR_F_FAN_STATUS = 'F Fan Status'
STR_R_FAN_STATUS = 'R Fan Status'

STR_F_DOOR_LAMP = 'F Door Lamp'
STR_R_DOOR_LAMP = 'R Door Lamp'

STR_F_DEF_HEATER = 'F Def Heater'
STR_R_DEF_HEATER = 'R Def Heater'

STR_COMP_RPM = 'COMP RPM'
