from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList
from Parser.OutBug.A6_Struct.A612_Struct import convertRealRPM

def retInt(byte: list):
    return int(byte[0])
def readMByte(Mbyte: list):
    Mbyte_val = Mbyte[0]
    return int.from_bytes(Mbyte_val, "big")

def consumption(cons: list):
    cons_val = cons[0]
    return int.from_bytes(cons_val, "big")/100


width = 55
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
compOperationInforList = [
    # DAT1
    [f'{"Save Temp Transmit Hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT2
    [f'{"Compressor Inv Target RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    # DAT3
    [f'{"Compressor Actual RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    # DAT4
    [f'{"Compressor 2 Inv Target RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    # DAT5
    [f'{"Compressor 2 Actual RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    # DAT6
    [f'{"Compressor operation time for 1 hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT7
    [f'{"Compressor 2 operation time for 1 hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT8
    [f'{"Number of compressors on/off for 1 hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT9
    [f'{"Number of compressors on/off for 1 hour": <{width}}', [], 8, 1, retInt, writeDefault],
    # DAT10~11
    [f'{"Compressor input voltage": <{width}}', [], 8, 2, readMByte, writeDefault],
    #DAT12~13
    [f'{"Compressor Power Value for  1 minute (Wh)": <{width}}', [], 8, 2, consumption, writeDefault],
    #DAT14~15
    [f'{"Compressor 2 Power Value for  1 minute (Wh)": <{width}}', [], 8, 2, consumption, writeDefault],
    #DAT16
    [f'{"Compressor phase current average ": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT17
    [f'{"Compressor phase current MAX ": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT18
    [f'{"Compressor 2 phase current average ": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT19
    [f'{"Compressor 2 phase current MAX ": <{width}}', [], 8, 1, retInt, writeDefault],
    #DAT20
    [f'{"Compressor Main Target RPM ": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    #DAT21
    [f'{"Compressor Main Target RPM ": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    #DAT22~24
     [f'{"Reserved22~24 ": <{width}}', [], 8, 3, None, exCheckZeroList]
]


class A623_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(compOperationInforList)