from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList

width = 45

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
serviceOpList = [
    # DAT1
    [f'{"F room temperature shift": <{width}}', [], 4, 1, None, writeDefault],  # Option 0
    [f'{"R room temperature shift": <{width}}', [], 4, 1, None, writeDefault],  # Option 1
    # f'{"DAT2
    [f'{"Ice Tray Water Amount": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"reserved2": <{width}}', [], 3, 1, None, exCheckZeroList],
    [f'{"Ice Maker Water Time": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT3
    [f'{"Ice Maker Eject Time": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved3_3": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F Room Hysteresis": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved3_7": <{width}}', [], 1, 1, None, exCheckZeroList],
    # f'{"DAT4
    [f'{"F Room NC Gap": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved4_2": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved4_3": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"F Room NW Gap": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved4_6": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved4_7": <{width}}', [], 1, 1, None, exCheckZeroList],
    # f'{"DAT5
    [f'{"R Room NC Gap": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved5_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"R Room NW Gap": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved5_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT6
    [f'{"R Room Hysteresis": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved6_1": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Open Air temperature shift": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved6_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT7
    [f'{"Iso Case3 Defrost Time": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved7_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"R Defrost Come Back temperature": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved7_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT8
    [f'{"F Defrost Come Back temperature": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved8_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"R Room Comp Off Cycle": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved8_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT9
    [f'{"Display Option": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved9_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"Defrost After Service": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"reserved9_2": <{width}}', [], 3, 1, None, exCheckZeroList],
    # f'{"DAT10
    [f'{"Check Fan Restriction": <{width}}', [], 1, 1, None, writeDefault],  # Option 18
    [f'{"reserved10_1": <{width}}', [], 3, 1, None, exCheckZeroList],
    [f'{"Dispenser Heater": <{width}}', [], 1, 1, None, writeDefault],  # Option 19
    [f'{"reserved10_2": <{width}}', [], 3, 1, None, exCheckZeroList],
    # f'{"DAT11
    [f'{"C Room temperature Shift": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved11_1": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"C Room Hysteresis": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved11_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT12
    [f'{"Idle Time": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved12_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"Control Bldc Fan High/Low": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved12_2": <{width}}', [], 1, 1, None, exCheckZeroList],
    # f'{"DAT13
    [f'{"Deodorizer Fan": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved13_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"C Room Thaw Temp Shift": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved13_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT14
    [f'{"R Initial Off": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved14_1": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"Comp RPM": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved14_2": <{width}}', [], 1, 1, None, writeDefault],
    # f'{"DAT15
    [f'{"F Fan Force": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved15_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"R Fan Force": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved15_2": <{width}}', [], 2, 1, None, exCheckZeroList],
    # f'{"DAT16
    [f'{"C Fan Force": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"reserved16_1": <{width}}', [], 2, 1, None, exCheckZeroList],
    [f'{"Internal Humidity": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved16_2": <{width}}', [], 1, 1, None, exCheckZeroList],
    # f'{"DAT17
    [f'{"Door Open Fan": <{width}}', [], 3, 1, None, writeDefault],
    [f'{"reserved17_1": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"Shut Off Valve": <{width}}', [], 4, 1, None, writeDefault],
    # f'{"DAT18
    [f'{"reserved18_1": <{width}}', [], 4, 1, None, exCheckZeroList],
    [f'{"reserved18_2": <{width}}', [], 4, 1, None, exCheckZeroList],
    # f'{"DAT19
    [f'{"reserved19": <{width}}', [], 4, 1, None, exCheckZeroList],
    [f'{"InverterComp. RPM Step 1 Up": <{width}}', [], 4, 1, None, writeDefault],  # Option 37
    # f'{"DAT20
    [f'{"CV room temperature shift": <{width}}', [], 4, 1, None, writeDefault],  # Option 38
    [f'{"F/CV room natural defrosting time fixed": <{width}}', [], 4, 1, None, writeDefault]  # Option 39
]


class A605_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(serviceOpList)

