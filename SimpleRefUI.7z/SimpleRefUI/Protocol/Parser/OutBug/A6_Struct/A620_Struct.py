from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList, sensorToTemp, onOffStatus, openClosedStatus, disYesNo

width = 40
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
dfcTempList = [
    [f'{"Save Temp Transmit Hour": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"F Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"R Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"CV Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"F Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],  # DAT5
    [f'{"R Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"CV Defrost Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"ICE Room Sensor (°C)": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],  # DAT8
    #f'{"Begin # DAT9
    [f'{"F Comp": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"R Comp": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"F Fan/Damper": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"R Fan/Damper": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"CV Fan/Damper": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"I Fan": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"reserved9_6": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"reserved9_7": <{width}}', [], 1, 1, None, exCheckZeroList],  # End # DAT9

    [f'{"F Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],  # Begin # DAT10
    [f'{"R Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"CV Valve": <{width}}', [], 1, 1, openClosedStatus, writeDefault],
    [f'{"F Defrost (for 1 hour)": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"R Defrost (for 1 hour)": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"CV Defrost (for 1 hour)": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"I Defrost (for 1 hour)": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"reserved10": <{width}}', [], 1, 1, None, exCheckZeroList],  # End # DAT10

    [f'{"F Room Control Temp": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"R Room Control Temp": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"CV Room Control Temp": <{width}}', [], 8, 1, sensorToTemp, exCheckZeroList],
    [f'{"F Door Open in 1 hour": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"R Door Open in 1 hour": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"CV Door Open in 1 hour": <{width}}', [], 8, 1, None, writeDefault],  # DAT16

    [f'{"Emod + 1": <{width}}', [], 4, 1, None, writeDefault],  # Begin # DAT17
    [f'{"Hmod + 1": <{width}}', [], 4, 1, None, writeDefault],  # End # DAT17

    [f'{"Ice Maker1 removals": <{width}}', [], 2, 1, None, writeDefault],  # Begin # DAT18
    [f'{"Ice Maker2 removals": <{width}}', [], 2, 1, None, writeDefault],
    [f'{"Ice Maker1 On/Off": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Maker2 On/Off": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Maker1 Full Ice": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Ice Maker2 Full Ice": <{width}}', [], 1, 1, disYesNo, writeDefault],  # End # DAT18

    [f'{"Water Dispenser time in 1 hour": <{width}}', [], 8, 1, None, writeDefault],  # DAT19
    [f'{"Ice Dispenser time in 1 hour": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Water Dispenser pressed for 1 hour": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Ice Dispenser pressed for 1 hour": <{width}}', [], 8, 1, None, writeDefault],
    #DAT23
    [f'{"Defrosting delay time": <{width}}', [], 5, 1, None, writeDefault],
    [f'{"Condition to cancel the defrost delay": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Exception condition for defrost delay": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Defrost Pre Cooling Operation": <{width}}', [], 1, 1, disYesNo, writeDefault],
    #DAT24
    [f'{"reserved24": <{width}}', [], 8, 1, None, exCheckZeroList]
]


class A620_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(dfcTempList)

