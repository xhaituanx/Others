from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault, exCheckZeroList, disYesNo, onOffStatus


pantry2Notch = {
    # FDR Type Pantry Room Model
    1: 'Beverage',
    2: 'Deli',
    3: 'Meat/Fish',
    4: 'Chilled',
    5: 'Fresh',
    6: 'Cheese',
    7: 'Cold Drinks',
    8: 'Chill/Meat',
    9: 'Wine',
    # T Type Pantry Room Model
    17: 'Meat/Fish',
    18: 'Refrigerated',
    # TMF Flex Crisper model
    33: 'Refrigerated',
    34: 'Deli',
    35: 'Meat/Fish',
    36: 'Soft Freeze',
    37: 'Quick Cool',
    254: 'Not supported'
}


def pantry2NotchSet(notch: list):
    notchVal = notch[0]
    tmpVal = int(notchVal)
    tmpStr = ''
    if 0 < tmpVal <= 15:
        tmpStr += 'FDR Type Pantry Room Model: '
        if tmpVal in pantry2Notch.keys():
            return tmpStr + pantry2Notch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 16 < tmpVal <= 31:
        tmpStr += 'T Type Pantry Room Model: '
        if tmpVal in pantry2Notch.keys():
            return tmpStr + pantry2Notch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 32 < tmpVal <= 47:
        tmpStr += 'TMF Flex Crisper model: '
        if tmpVal in pantry2Notch.keys():
            return tmpStr + pantry2Notch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif tmpVal == 254:
        return pantry2Notch[tmpVal]
    else:
        return f'Unknown Notch: {tmpVal}'


freezerConvertNotch = {
    1: 'Freezer',
    2: 'Fridge',
    3: 'Off',
    4: 'Kimchi storage standard',
    5: 'Kimchi storage cold',
    6: 'Kimchi storage weak cooling',
    7: 'Soft Freezing (-5°C)',
    8: 'Chill (-1°C)',
    9: 'Cool (2°C)',
    10: 'Soft Freeze (Not used)',
    11: 'Chill (Not used)',
    12: 'Cool (Not used)',
    254: 'Not supported'
}


def freezerConvertNotchSet(notch: list):
    notchVal = notch[0]
    tmpVal = int(notchVal)
    if tmpVal in freezerConvertNotch.keys():
        return freezerConvertNotch[tmpVal]
    else:
        return f'Unknown Notch: {tmpVal}'


def FNotchSet(notch: list):
    notchVal = notch[0]
    tmpVal = int(notchVal)
    if 0 < tmpVal <= 7:
        return f'Bar type Notch{tmpVal}'
    elif 17 <= tmpVal <= 25:
        return f'{tmpVal - 40} °C'
    elif 32 <= tmpVal <= 45:
        return f'{tmpVal - 40} °F'
    elif tmpVal == 240:
        return 'Off (Freezer Convert)'
    elif tmpVal == 254:
        return 'Not supported'
    else:
        return f'Unknown Notch: {tmpVal}'


def RNotchSet(notch: list):
    notchVal = notch[0]
    tmpVal = int(notchVal)
    if 0 < tmpVal <= 7:
        return f'Bar type Notch{tmpVal}'
    elif 40 <= tmpVal <= 47:
        return f'{tmpVal - 40} °C'
    elif 74 <= tmpVal <= 88:
        return f'{tmpVal - 40} °F'
    elif tmpVal == 240:
        return 'Off (Vacation)'
    elif tmpVal == 254:
        return 'Not supported'
    else:
        return f'Unknown Notch: {tmpVal}'


CVNotch = {
    # T Type CV room model (RF9000K, RF9900K)
    1: 'Frozen/Freezer',
    2: 'Flesh Ice/Soft Freeze',
    3: 'Special/Chill',
    4: 'Refrigerated/Cool',
    5: 'Kimchi ripening',
    6: 'Kimchi storage weak cooling',
    7: 'Kimchi storage standard',
    8: 'Kimchi storage cold',
    9: 'Fish&Meat(Built-In)',
    10: 'Beer (F-Hub)',
    # SBS Pantry Room (RH9000K)
    17: 'Refrigerated',
    18: 'Quick Refrigerate',
    19: 'Thaw 5 hours',
    20: 'Thaw 10 hours',
    21: 'Fridge',
    22: 'Fruit & Vegetables',
    23: 'Beverage',
    24: 'Meat & Fish',
    # TMF Pantry Room (RT7000K)
    33: 'Fridge',
    34: 'Soft Freeze',
    35: 'Freezer',
    36: '-1°C Zone',
    37: 'Fast Cooling',
    38: 'OFF',
    # SSEC M room (RF5500K)
    49: 'Cool',
    50: 'Chill',
    51: 'Soft Freeze',
    52: 'Freezer',
    # Family Hub
    65: 'Frozen',
    66: 'Soft Freeze',
    67: 'Meat & Fish',
    68: 'Cheese & Vegetables',
    69: 'Beer & White wine',
    # FDR M Room
    81: 'Wine',
    82: 'Deli',
    83: 'Beverage',
    84: 'Meat',
    85: 'Wine',
    86: 'Cheese',
    87: 'Cold Drinks',
    88: 'Chill/Meat',
    254: 'Not supported'
}


def CVNotchSet(notch: list):
    notchVal = notch[0]
    tmpVal = int(notchVal)
    tmpStr = ''
    if 0 < tmpVal <= 15:
        tmpStr += 'T Type CV room model: '
        if tmpVal in CVNotch.keys():
            return tmpStr + CVNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 17 <= tmpVal <= 31:
        tmpStr += 'SBS Pantry Room: '
        if tmpVal in CVNotch.keys():
            return tmpStr + CVNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 33 <= tmpVal <= 47:
        tmpStr += 'TMF Pantry Room: '
        if tmpVal in CVNotch.keys():
            return tmpStr + CVNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 49 <= tmpVal <= 63:
        tmpStr += 'SSEC M room: '
        if tmpVal in CVNotch.keys():
            return tmpStr + CVNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 65 <= tmpVal <= 79:
        tmpStr += 'Family Hub: '
        if tmpVal in CVNotch.keys():
            return tmpStr + CVNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 81 <= tmpVal <= 95:
        tmpStr += 'FDR M Room: '
        if tmpVal in CVNotch.keys():
            return tmpStr + CVNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif tmpVal == 254:
        return CVNotch[tmpVal]
    else:
        return f'Unknown Notch: {tmpVal}'


pantryNotch = {
    # FDR Type Pantry Room Model
    1: 'Beverage',
    2: 'Deli',
    3: 'Meat/Fish',
    4: 'Chilled',
    5: 'Fresh',
    6: 'Cheese',
    7: 'Cold Drinks',
    8: 'Chill/Meat',
    9: 'Wine',
    # T Type Pantry Room Model
    17: 'Meat/Fish',
    18: 'Refrigerated',
    19: 'Red wine',
    20: 'Grain',
    21: 'Fruits and Vegetables',
    22: 'Meat/Fish',
    23: 'Tropical fruit',
    24: 'White wine',

    254: 'Not supported'
}


def pantryNotchSet(notch: list):
    notchVal = notch[0]
    tmpVal = int(notchVal)
    tmpStr = ''
    if 0 < tmpVal <= 15:
        tmpStr += 'FDR Type Pantry Room Model: '
        if tmpVal in pantryNotch.keys():
            return tmpStr + pantryNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif 16 < tmpVal <= 31:
        tmpStr += 'T Type Pantry Room Model: '
        if tmpVal in pantryNotch.keys():
            return tmpStr + pantryNotch[tmpVal]
        else:
            return tmpStr + f'Unknown Notch: {tmpVal}'
    elif tmpVal == 254:
        return pantryNotch[tmpVal]
    else:
        return f'Unknown Notch: {tmpVal}'


def configLocation(loca: list):
    loca_val = loca[0]
    tmpVal = int(loca_val)
    if tmpVal == 1:
        return 'External(HASS,app,RM,etc,)'
    else:
        return 'Device'

def compRPM(rpm: list):
    rpm_val = rpm[0]
    tmpVal = int(rpm_val)
    return f'{tmpVal * 50}'


def doorOpenTime(timedoor: list):
    time_val = timedoor[0]
    tmpVal = int(time_val)
    return f'{tmpVal * 10}'

width = 45
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
mainOperationList = [
    [f'{"Water filter usage (%)": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"Clean deodorization filter usage (%)": <{width}}', [], 8, 1, None, writeDefault],
    # f'{"DAT3~4
    [f'{"reserved3": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"reserved4": <{width}}', [], 8, 1, None, exCheckZeroList],
    [f'{"Pantry 2 Notch": <{width}}', [], 8, 1, pantry2NotchSet, writeDefault],
    [f'{"Time (MAX 120 hours)": <{width}}', [], 8, 1, None, writeDefault],
    # f'{"DAT7
    [f'{"F Comp MAIN Indicative RPM": <{width}}', [], 8, 1, compRPM, writeDefault],
    [f'{"R Comp MAIN Indicative RPM": <{width}}', [], 8, 1, compRPM, writeDefault],
    # f'{"DAT9
    [f'{"Freezer Convert Notch": <{width}}', [], 8, 1, freezerConvertNotchSet, writeDefault],
    [f'{"F Notch": <{width}}', [], 8, 1, FNotchSet, writeDefault],
    [f'{"R Notch": <{width}}', [], 8, 1, RNotchSet, writeDefault],
    # f'{"DAT12
    [f'{"CV Notch": <{width}}', [], 8, 1, CVNotchSet, writeDefault],
    [f'{"Pantry Notch": <{width}}', [], 8, 1, pantryNotchSet, writeDefault],
    [f'{"Pantry sensor": <{width}}', [], 8, 1, None, writeDefault],
    [f'{"First ice maker sensor": <{width}}', [], 8, 1, None, writeDefault],
    # f'{"DAT16
    [f'{"Second ice maker sensor": <{width}}', [], 8, 1, None, writeDefault],
    # f'{"DAT17
    [f'{"F Notch Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"R Notch Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"CV Notch Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"Pantry Notch Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"Sabbath final configuration location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"Power freeze final configuration location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"Power refrigeration final configuration location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"Pantry 2 Notch Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    # f'{"DAT18
    [f'{"Ice Maker On/Off Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"Sub Ice Maker On/Off Final Configuration Location": <{width}}', [], 1, 1, configLocation, writeDefault],
    [f'{"reserved18": <{width}}', [], 6, 1, None, exCheckZeroList],
    # f'{"DAT19
    [f'{"reserved19": <{width}}', [], 8, 1, None, exCheckZeroList],
    # f'{"DAT20
    [f'{"Sabbath Mode": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Ice Mode": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"Comp RPM Up Control Operation during F Comp 2 Hours (3 Hours) Continuous Operation": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Comp RPM Up Control Operation during F Comp 4Hr Continuous Operation": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Comp RPM Up Control Operation during R Comp 2 Hours (3 Hours) Continuous Operation": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Comp RPM Up Control Operation during R Comp 4Hr Continuous Operation": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"AI saving mode operation": <{width}}', [], 1, 1, onOffStatus, writeDefault],
    [f'{"reserved20": <{width}}', [], 1, 1, None, exCheckZeroList],
    # f'{"DAT21
    [f'{"Accumulated time of F Door Open for 1 hour (sec)": <{width}}', [], 8, 1, doorOpenTime, writeDefault],
    [f'{"Accumulated time of R Door Open for 1 hour (sec)": <{width}}', [], 8, 1, doorOpenTime, writeDefault],
    [f'{"Accumulated time of CV Door Open for 1 hour (sec)": <{width}}', [], 8, 1, doorOpenTime, writeDefault],
    # f'{"DAT24
    [f'{"Pantry 2 Sensor": <{width}}', [], 8, 1, None, writeDefault]
]


class A608_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(mainOperationList)

