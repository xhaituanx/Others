from Parser.DataStruct import *
from Parser.OutBug.DataConvert import *

def isFahrenheit(fah: list):
    fah_val = fah[0]
    tmp = int(fah_val)
    if tmp == 1:
        return 'Fahrenheit'
    else:
        return 'Celsius'

def sabbathmodel(sab: list):
    sav_val = sab[0]
    tmp = int(sav_val)
    if tmp == 1:
        return 'Sabbath Model'
    else:
        return 'Not Sabbath Model'

def comptype(comp: list):
    comp_val = comp[0]
    tmp = int(comp_val)
    if tmp == 1:
        return 'PWM'
    else:
        return 'UART'

def displaytype(disptype: list):
    disptype_val = disptype[0]
    tmp = int(disptype_val)
    if tmp == 1:
        return 'Dynamic Display'
    else:
        return 'Panel Communication Model'

def markettype(martype: list):
    martype_val = martype[0]
    tmp = int(martype_val)
    if tmp == 1:
        return 'Export'
    else:
        return 'National Edition'

def reftype(reftype: list):
    reftype_val = reftype[0]
    tmp = int(reftype_val)
    if tmp == 1:
        return 'External Type'
    else:
        return 'Basic Type'

width = 55

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
modelOptionList = [
    # DATA1
    [f'{"Market type": <{width}}', [], 1, 1, markettype, writeDefault],
    [f'{"Refrigerator type": <{width}}', [], 1, 1, reftype, writeDefault],
    [f'{"Carbonated water": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"TWIN ice maker": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"MONO ice maker": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"R ice maker": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"F ice maker": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"reserved1_7": <{width}}', [], 1, 1, None, exCheckZeroList],
    # DATA2
    [f'{"Temperature Degrees type": <{width}}', [], 1, 1, isFahrenheit, writeDefault],
    [f'{"reserved2_1": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"FS 0 CD1": <{width}}', [], 1, 1, None, writeDefault],
    [f'{"FDSR": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"reserved2_4": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"LCD": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"LED": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Rotary": <{width}}', [], 1, 1, disYesNo, writeDefault],
    # DATA3
    [f'{"Embedded": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Dongle": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Kimchi": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"SPI model": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Deodorizer model": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"CV UI": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Display type": <{width}}', [], 1, 1, displaytype, writeDefault],
    [f'{"Sabbath model": <{width}}', [], 1, 1, sabbathmodel, writeDefault],
    # DATA4
    [f'{"Comp Type": <{width}}', [], 1, 1, comptype, writeDefault],
    [f'{"PCB/WIFI public port": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"HM Cycle": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"TDM Cycle": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"Parallel Cycle": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"R Heater Non": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"reserved4_6": <{width}}', [], 1, 1, None, exCheckZeroList],
    [f'{"DOC Model": <{width}}', [], 1, 1, disYesNo, writeDefault],
    # DATA5
    [f'{"4-Ways Valve": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"3-Ways Valve": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"2-Ways Valve": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"2nd Valve": <{width}}', [], 1, 1, disYesNo, writeDefault],
    [f'{"reserved5_4": <{width}}', [], 3, 1, None, exCheckZeroList],
    [f'{"F/CV 1Door sw model": <{width}}', [], 1, 1, disYesNo, writeDefault]
]

class A613_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(modelOptionList)

