from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault

width = 35
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
serOpWriteList = [
    [f'{"Service Option Write": <{width}}', [], 8, 20, None, writeDefault]
]


class A621_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(serOpWriteList)

