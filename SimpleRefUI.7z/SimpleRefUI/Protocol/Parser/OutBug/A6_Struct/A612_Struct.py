from Parser.DataStruct import *
from Parser.OutBug.DataConvert import writeDefault
from Parser.OutBug.A6_Struct.A6_Common import *

def convertRealRPM(rpm: list):
    rpm_val = rpm[0]
    try:
        return int(rpm_val)*50
    except:
        print("rpm type {}".format(type(rpm_val)))
        return ''

def compMode(compval: list):
    compval_val = compval[0]
    tmp = int(compval_val)
    if tmp == 0:
        return 'RPM monitoring not applied'
    elif tmp == 1:
        return 'Standby state'
    elif tmp == 2:
        return 'Normal operation'
    elif tmp == 3:
        return 'Oil pumping operation'
    elif tmp == 4:
        return 'Multi-stage operation'
    elif tmp == 5:
        return 'Overload operation'
    elif tmp == 6:
        return 'Dynaminv braking'
    elif tmp == 7:
        return 'Comp error'
    else:
        print('Unknown Comp mode {}'.format(compval_val))
        return ''

def compCumulative(compval: list):
    compval_val = compval[0]
    tmp = int.from_bytes(compval_val, "big")
    if tmp == 0:
        return 'Not applied'
    elif tmp == int(0xFFFF):
        return 'Comp Off'
    else:
        return tmp

width = 45
# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
compRPMReadList = [
    [f'{"F Comp Mode": <{width}}', [], 8, 1, compMode, writeDefault],
    [f'{STR_COMP_RPM: <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    [f'{"F COMP INVERTER indication RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    [f'{"F COMP Actual RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],  # DAT4
    [f'{"R Comp Mode": <{width}}', [], 8, 1, compMode, writeDefault],
    [f'{"R COMP MAIN indication RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    [f'{"R COMP INVERTER indication RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],  # DAT7
    [f'{"R COMP Actual RPM": <{width}}', [], 8, 1, convertRealRPM, writeDefault],
    [f'{"F COMP Cumulative Power Value for 10 Seconds": <{width}}', [], 8, 2, compCumulative, writeDefault],  # DAT9, 10
    [f'{"R COMP Cumulative Power Value for 10 Seconds": <{width}}', [], 8, 2, compCumulative, writeDefault]  # DAT11, 12
]


class A612_FieldStruct(PrintableLittleEndianStructure):
    _pack_ = 1
    _fields_ = reListTupleFromListctypes(compRPMReadList)

