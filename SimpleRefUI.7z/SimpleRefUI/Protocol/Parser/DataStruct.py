import json
from collections import OrderedDict
from ctypes import *
from Common.DataConfig import *

class PrintableBigEndianStructure(BigEndianStructure):
    """ """
    def __get_value_str(self, name, fmt='{}'):
        val = getattr(self, name)
        if isinstance(val, Array):
            val = list(val)
        #return fmt.format(val)
        return val

    def __str__(self):
        return '{0}'.format(self.__class__) + json.dumps(self.__repr__(), indent=2)

    # def __repr__(self):
    #     info = OrderedDict((item[0], self.__get_value_str(item[0])) for item in self._fields_)
    #     return info

    # def __repr__(self):
    #     info = OrderedDict((item[0], getattr(self, item[0]).__repr__()) for item in self._fields_)
    #     return info

    def __repr__(self):
        info = OrderedDict((item[0], self.__get_value_str(item[0]).__repr__()) for item in self._fields_)
        return info

class PrintableLittleEndianStructure(LittleEndianStructure):
    """ """
    def __get_value_str(self, name, fmt='{}'):
        val = getattr(self, name)
        if isinstance(val, Array):
            val = list(val)
        #return fmt.format(val)
        return val

    def __str__(self):
        return '{0}'.format(self.__class__) + json.dumps(self.__repr__(), indent=2)

    # def __repr__(self):
    #     info = OrderedDict((item[0], self.__get_value_str(item[0])) for item in self._fields_)
    #     return info

    # def __repr__(self):
    #     info = OrderedDict((item[0], getattr(self, item[0]).__repr__()) for item in self._fields_)
    #     return info

    def __repr__(self):
        info = OrderedDict((item[0], self.__get_value_str(item[0]).__repr__()) for item in self._fields_)
        return info

    def __getitem__(self, item):
        dicinto = self.__repr__()
        try:
            i = list(dicinto.keys()).index(item)
            # logger.info("\r\nStructure: Item '{}' at index {}".format(item, i+1), also_console=True)
            return i
        except Exception:
            raise AssertionError("No such key-value pair!!")


################################################################################
#  Wifi header structure
class HeaderWifiStruct(PrintableBigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('STX', c_uint8),
        ('PRF ID', c_uint8),
        ('VER', c_uint8),
        ('LEN', c_uint8),
        ('SRC ADDR', c_uint16),
        ('DST ADDR', c_uint16),
        ('EP', c_uint8),
        ('FRM ID', c_uint8),
        (STR_CLS_ID, c_uint16),
        (STR_CMD_ID, c_uint8),
    ]

#  Outbug header structure

# list with [name, list value, ctypes in bit, multi, converterFunc, checkWriteFunc]
def reListTupleFromListctypes(input_List):
    tmpmodelList = list()
    for i in range(0, len(input_List)):
        if input_List[i][2] == 8:
            if input_List[i][3] > 1:
                tmp = (input_List[i][0], c_uint8*input_List[i][3])
            else:
                tmp = (input_List[i][0], c_uint8)
        elif input_List[i][2] == 16:
            if input_List[i][3] > 1:
                tmp = (input_List[i][0], c_uint16*input_List[i][3])
            else:
                tmp = (input_List[i][0], c_uint16)
        else:  # bit type
            tmp = (input_List[i][0], c_uint8, input_List[i][2])

        tmpmodelList.append(tmp)
    return tmpmodelList


class HeaderOutBugStruct(PrintableBigEndianStructure):
    _pack_ = 1
    _fields_ = [
        ('Start1', c_uint8),
        (STR_START2_CMD, c_uint16),
    ]
