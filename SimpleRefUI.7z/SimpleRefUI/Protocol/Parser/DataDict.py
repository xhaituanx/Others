from Parser.Wifi.FC94_Network_Control import FC94_Data_Des
from Parser.Wifi.FD12_Power_Consumption import FD12_Data_Des
from Parser.Wifi.FE02_Function_Control import FE02_Data_Des
from Parser.Wifi.FC01_General_Information import FC01_Data_Des
from Parser.Wifi.FD01_DRLC import FD01_Data_Des
from Parser.Wifi.FE16_RM_Cluster import FE16_Data_Des
from Parser.Wifi.FE14_OTN_Cluster import FE14_Data_Des

from Parser.OutBug.A7_Struct.A7_Ctrl import *
from Parser.OutBug.A5_Struct.A5_Ctrl import *
from Parser.OutBug.A6_Struct.A6_Ctrl import *

# Wifi
Cmd_ID_Des = {
    0x00: 'Read All',
    0x01: 'Read All Resp',
    0x02: 'Read',
    0x03: 'Read Resp',
    0x04: 'Write',
    0x05: 'Write Resp',
    0x06: 'Noti',
    0x07: 'Noti Resp'
}

Cluster_ID_Des = {
    0xFC01: ('General Information', FC01_Data_Des),
    0xFC94: ('Network Control', FC94_Data_Des),
    0xFC9F: ('Factory Mode', None),
    0xFD01: ('DRLC', FD01_Data_Des),
    0xFD12: ('Power Consumption', FD12_Data_Des),
    0xFE02: ('Function Control', FE02_Data_Des),
    0xFE14: ('OTN', FE14_Data_Des),
    0xFE15: ('Scube HASS', None),
    0xFE16: ('RM', FE16_Data_Des),
}
# End Wifi



# OutBug : cmdid: (description, isReadcmd, writebuffer, checkwrite, clearDataFunc)
Outbug_ID_Des = {
    0xA502: ('Enter test mode', OB_RW_TYPE_W, None, None, None),
    0xA503: ('Test mode release', OB_RW_TYPE_W, None, None, None),
    0xA504: ('Serial Number Write', OB_RW_TYPE_W, A504_WriteBuffer, A504_CheckWrite, A504_ClearData),
    0xA505: ('Serial number read', OB_RW_TYPE_R, A505_WriteBuffer, A505_CheckWrite, A505_ClearData),
    0xA506: ('OTN Update Version Read', OB_RW_TYPE_R, A506_WriteBuffer, A506_CheckWrite, A506_ClearData),
    0xA510: ('Load Relay Write', OB_RW_TYPE_W, A510_WriteBuffer, A510_CheckWrite, A510_ClearData),
    0xA511: ('Sensor value input read', OB_RW_TYPE_R, A511_WriteBuffer, A511_CheckWrite, A511_ClearData),
    0xA512: ('Other Input read', OB_RW_TYPE_R, A512_WriteBuffer, A512_CheckWrite, A512_ClearData),
    0xA513: ('Led Write', OB_RW_TYPE_W, A513_WriteBuffer, A513_CheckWrite, A513_ClearData),
    0xA514: ('SW input read', OB_RW_TYPE_R, A514_WriteBuffer, A514_CheckWrite, A514_ClearData),
    0xA515: ('Buzzer write', OB_RW_TYPE_W, A515_WriteBuffer, A515_CheckWrite, A515_ClearData),
    0xA521: ('Motor write', OB_RW_TYPE_W, A521_WriteBuffer, A521_CheckWrite, A521_ClearData),
    0xA530: ('Version Option Read', OB_RW_TYPE_R, A530_WriteBuffer, A530_CheckWrite, A530_ClearData),
    0xA531: ('Inverter Pulse Write', OB_RW_TYPE_W, A531_WriteBuffer, A531_CheckWrite, A531_ClearData),
    0xA532: ('BLDC Fan Write', OB_RW_TYPE_W, A532_WriteBuffer, A532_CheckWrite, A532_ClearData),
    0xA533: ('EEPROM Write', OB_RW_TYPE_W, A533_WriteBuffer, A533_CheckWrite, A533_ClearData),
    0xA534: ('EEPROM Read', OB_RW_TYPE_R, A534_WriteBuffer, A534_CheckWrite, A534_ClearData),
    0xA543: ('Valve Write', OB_RW_TYPE_W, A543_WriteBuffer, A543_CheckWrite, A543_ClearData),
    0xA544: ('Self-diagnosis Error Date Request Read', OB_RW_TYPE_R, A544_WriteBuffer, A544_CheckWrite, A544_ClearData),
    0xA561: ('Sensor value input Read2', OB_RW_TYPE_R, A561_WriteBuffer, A561_CheckWrite, A561_ClearData),
    0xA5FE: ('Test mode release', OB_RW_TYPE_W, None, None, None),
    0xA5FF: ('Enter test mode', OB_RW_TYPE_W, None, None, None),
    # From A6
    0xA601: ('Force Start Mode Write', OB_RW_TYPE_RW, A601_WriteBuffer, A601_CheckWrite, A601_ClearData),
    0xA602: ('Load display mode read', OB_RW_TYPE_R, A602_WriteBuffer, A602_CheckWrite, A602_ClearData),
    0xA603: ('Recently read 5 errors', OB_RW_TYPE_R, A603_WriteBuffer, A603_CheckWrite, A603_ClearData),
    0xA605: ('Service option Write', OB_RW_TYPE_W, A605_WriteBuffer, A605_CheckWrite, A605_ClearData),
    0xA606: ('Service option read', OB_RW_TYPE_R, A606_WriteBuffer, A606_CheckWrite, A606_ClearData),
    0xA607: ('Free Service Period Read', OB_RW_TYPE_R, A607_WriteBuffer, A607_CheckWrite, A607_ClearData),
    0xA608: ('Filter usage read + Main operation information', OB_RW_TYPE_R, A608_WriteBuffer, A608_CheckWrite, A608_ClearData),
    0xA610: ('LIST Read under Control', OB_RW_TYPE_R, A610_WriteBuffer, A610_CheckWrite, A610_ClearData),
    0xA611: ('Monitoring Load LIST Read', OB_RW_TYPE_R, A611_WriteBuffer, A611_CheckWrite, A611_ClearData),
    0xA612: ('COMP RPM Read', OB_RW_TYPE_R, A612_WriteBuffer, A612_CheckWrite, A612_ClearData),
    0xA613: ('Model Option LIST Read', OB_RW_TYPE_R, A613_WriteBuffer, A613_CheckWrite, A613_ClearData),
    0xA620: ('Storage of temperature/load status by time', OB_RW_TYPE_R, A620_WriteBuffer, A620_CheckWrite, A620_ClearData),
    0xA621: ('Service Option Write', OB_RW_TYPE_W, A621_WriteBuffer, A621_CheckWrite, A621_ClearData),
    0xA622: ('Service Option read', OB_RW_TYPE_R, A622_WriteBuffer, A622_CheckWrite, A622_ClearData),
    0xA623: ('Compressor Operate Information', OB_RW_TYPE_R, A623_WriteBuffer, A623_CheckWrite, A623_ClearData),
    0xA624: ('Fan Operate Information ', OB_RW_TYPE_R, A624_WriteBuffer, A624_CheckWrite, A624_ClearData),
    0xA625: ('Fan Operate Information 2', OB_RW_TYPE_R, A625_WriteBuffer, A625_CheckWrite, A625_ClearData),
    # From A7
    0xA701: ('Sensor Value Read Write1', OB_RW_TYPE_RW, A701_WriteBuffer, A701_CheckWrite, A701_ClearData),
    0xA702: ('Sensor Value Read Write2', OB_RW_TYPE_RW, A702_WriteBuffer, A702_CheckWrite, A702_ClearData),
    0xA703: ('F Notch Read Write', OB_RW_TYPE_RW, A703_WriteBuffer, A703_CheckWrite, A703_ClearData),
    0xA704: ('R Notch Read Write', OB_RW_TYPE_RW, A704_WriteBuffer, A704_CheckWrite, A704_ClearData),
    0xA708: ('Function Selection Read Write', OB_RW_TYPE_RW, A708_WriteBuffer, A708_CheckWrite, A708_ClearData),
    0xA709: ('Fast SW Write', OB_RW_TYPE_RW, A709_WriteBuffer, A709_CheckWrite, A709_ClearData),
    0xA70B: ('Door Switch Write', OB_RW_TYPE_RW, A70B_WriteBuffer, A70B_CheckWrite, A70B_ClearData),
    0xA70C: ('Defrosting information read', OB_RW_TYPE_R, A70C_WriteBuffer, A70C_CheckWrite, A70C_ClearData),
    0xA70D: ('Fan RPM Count Read', OB_RW_TYPE_R, A70D_WriteBuffer, A70D_CheckWrite, A70D_ClearData),
    0xA70E: ('Temperature Control On/Off Point Read', OB_RW_TYPE_R, A70E_WriteBuffer, A70E_CheckWrite, A70E_ClearData)
}

# End OutBug

